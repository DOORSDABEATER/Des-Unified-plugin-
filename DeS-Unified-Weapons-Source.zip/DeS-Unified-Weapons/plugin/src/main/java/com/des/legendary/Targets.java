package com.des.legendary;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.*;
import org.bukkit.scoreboard.Team;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Who an ability may affect. Never the caster, never creative/spectator players, never own pets, configurable mob classes. */
public final class Targets {
    private Targets() {}

    public static boolean hostile(LivingEntity e) { return e instanceof Enemy || e instanceof Boss; }

    public static boolean valid(LegendaryPlugin pl, Player caster, Entity e) {
        if (!(e instanceof LivingEntity le) || e.getUniqueId().equals(caster.getUniqueId()) || le.isDead() || !le.isValid()) return false;
        if (le.hasMetadata("NPC") || le.getScoreboardTags().contains(Fx.TAG)) return false;
        if (pl.cfg().list("disabled-worlds").contains(le.getWorld().getName())) return false;
        if (le instanceof Player t) {
            if (!pl.cfg().b("targets.players", true) || t.getGameMode() == GameMode.CREATIVE || t.getGameMode() == GameMode.SPECTATOR) return false;
            if (!t.getWorld().getPVP()) return false;
            Team team = caster.getScoreboard().getEntryTeam(caster.getName());
            if (team != null && !team.allowFriendlyFire() && team.hasEntry(t.getName())) return false;
            return true;
        }
        if (le instanceof ArmorStand) return pl.cfg().b("targets.armor-stands", false);
        if (le instanceof Tameable tm && tm.isTamed() && tm.getOwner() != null && tm.getOwner().getUniqueId().equals(caster.getUniqueId())) return false;
        if (hostile(le)) return pl.cfg().b("targets.hostile-mobs", true);
        return pl.cfg().b("targets.passive-mobs", false);
    }

    /** All valid targets whose hitbox centre is within r of l (3D). */
    public static List<LivingEntity> sphere(LegendaryPlugin pl, Player caster, Location l, double r) {
        List<LivingEntity> out = new ArrayList<>();
        if (l.getWorld() == null) return out;
        for (LivingEntity e : l.getWorld().getNearbyLivingEntities(l, r + 1.5)) {
            if (!valid(pl, caster, e)) continue;
            double w = e.getWidth() / 2;
            if (e.getBoundingBox().getCenter().distance(l.toVector()) <= r + w) out.add(e);
        }
        return out;
    }

    public static List<LivingEntity> byDistance(List<LivingEntity> in, Location from) {
        in.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(from)));
        return in;
    }
}

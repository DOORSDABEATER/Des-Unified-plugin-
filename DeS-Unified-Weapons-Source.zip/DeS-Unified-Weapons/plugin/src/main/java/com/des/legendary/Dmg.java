package com.des.legendary;

import org.bukkit.Bukkit;
import org.bukkit.entity.Boss;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Centralised ability damage. Every point of ability damage passes through hit():
 * validity -> per-target hit limit -> max targets -> protection event -> multipliers -> burst cap -> vanilla damage()
 * (so armor, protection enchants, resistance and absorption apply normally) -> result check -> energy/mastery/combo hooks.
 */
public final class Dmg {
    /** True while an ability is dealing damage, so melee listeners ignore it. */
    public static volatile boolean active;

    private static final class Hit { final UUID attacker; final long tick; final AbilityId id; Hit(UUID a, long t, AbilityId i) { attacker = a; tick = t; id = i; } }

    private final LegendaryPlugin pl;
    private final Map<UUID, Hit> last = new HashMap<>();
    private final Map<UUID, ArrayDeque<double[]>> bursts = new HashMap<>();   // victim -> {tick, damage}

    public Dmg(LegendaryPlugin pl) { this.pl = pl; }

    public boolean hit(Ctx c, LivingEntity t, String key, double base) {
        if (!Targets.valid(pl, c.p, t)) return false;
        UUID id = t.getUniqueId();
        Set<String> keys = c.done.computeIfAbsent(id, k -> new HashSet<>());
        if (keys.contains(key)) return false;                                   // per-target hit limit (per hit key)
        if (!c.targets.contains(id) && c.targets.size() >= c.maxTargets) return false;
        AbilityTargetEvent ev = new AbilityTargetEvent(c.p, t, c.id, false);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) return false;
        keys.add(key);

        Cfg cfg = pl.cfg();
        double dmg = base * cfg.d("damage.global-multiplier", 1.0) * c.dmgMul;
        if (t instanceof Boss) dmg *= cfg.d("damage.boss-multiplier", 1.0);
        long now = pl.casts().now();
        if (t instanceof Player) dmg = burstCap(id, dmg, now);
        if (dmg <= 0) return false;

        double before = t.getHealth() + t.getAbsorptionAmount();
        if (cfg.b("damage.reset-invulnerability-frames", true)) t.setNoDamageTicks(0);
        active = true;
        try { t.damage(dmg, c.p); } finally { active = false; }
        if (!t.isDead() && t.getHealth() + t.getAbsorptionAmount() >= before - 1.0e-3) return false;   // cancelled by a protection plugin / fully negated

        c.targets.add(id);
        last.put(id, new Hit(c.p.getUniqueId(), now, c.id));
        if (t instanceof Player) bursts.computeIfAbsent(id, k -> new ArrayDeque<>()).add(new double[]{now, Math.max(0, before - t.getHealth() - t.getAbsorptionAmount())});
        PlayerData.WD wd = pl.data().get(c.p.getUniqueId()).of(c.w);
        wd.hits++; pl.data().get(c.p.getUniqueId()).dirty = true;
        pl.energy().onHit(c, t);
        pl.mastery().onHit(c, t);
        if (!c.landed) { c.landed = true; pl.combos().landed(c); }
        return true;
    }

    /** Limits how much ability damage one player can take in a short window, so stacked combos always leave counterplay. */
    private double burstCap(UUID victim, double dmg, long now) {
        double cap = pl.cfg().d("damage.burst-cap.max-damage", 24.0);
        if (cap <= 0) return dmg;
        long window = pl.cfg().i("damage.burst-cap.window-ticks", 60);
        ArrayDeque<double[]> q = bursts.computeIfAbsent(victim, k -> new ArrayDeque<>());
        while (!q.isEmpty() && now - q.peekFirst()[0] > window) q.pollFirst();
        double sum = 0; for (double[] e : q) sum += e[1];
        return Math.min(dmg, Math.max(1.0, cap - sum));
    }

    public UUID lastAttacker(UUID victim, long now) { Hit h = last.get(victim); return (h != null && now - h.tick <= 100) ? h.attacker : null; }
    public AbilityId lastAbility(UUID victim) { Hit h = last.get(victim); return h == null ? null : h.id; }
    public void forget(UUID victim) { last.remove(victim); bursts.remove(victim); }
    public void prune(long now) {
        last.values().removeIf(h -> now - h.tick > 400);
        bursts.values().removeIf(q -> q.isEmpty() || now - q.peekLast()[0] > 400);
        pl.cc().prune(now);
    }
}

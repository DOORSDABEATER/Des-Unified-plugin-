package com.des.legendary;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;

/** Collision-aware movement helpers for dashes and teleports (solid blocks, lava/fire, void, world border). */
public final class SafeMove {
    private SafeMove() {}

    private static boolean clear(Block b) {
        Material m = b.getType();
        return b.isPassable() && m != Material.LAVA && m != Material.FIRE && m != Material.SOUL_FIRE && m != Material.CACTUS
                && m != Material.MAGMA_BLOCK && m != Material.SWEET_BERRY_BUSH && m != Material.POWDER_SNOW && m != Material.COBWEB;
    }

    /** Can a player (0.6 x 1.8) stand at l? Checks feet+head at the centre and the four corners, plus border and height limits. */
    public static boolean fits(Location l) {
        World w = l.getWorld();
        if (w == null || !w.getWorldBorder().isInside(l) || l.getY() < w.getMinHeight() + 1 || l.getY() > w.getMaxHeight() - 2) return false;
        double[][] o = {{0, 0}, {.3, .3}, {-.3, .3}, {.3, -.3}, {-.3, -.3}};
        for (double[] d : o) {
            Location p = l.clone().add(d[0], 0, d[1]);
            if (!clear(p.getBlock()) || !clear(p.clone().add(0, 1, 0).getBlock())) return false;
        }
        return true;
    }

    /** Solid, non-hazard ground (or water) within `depth` blocks below l. */
    public static boolean groundBelow(Location l, int depth) {
        Location p = l.clone();
        for (int i = 0; i <= depth; i++) {
            Block b = p.getBlock();
            if (b.getType() == Material.LAVA || b.getType() == Material.MAGMA_BLOCK || b.getType() == Material.CACTUS || b.getType() == Material.FIRE) return false;
            if (b.isLiquid() || !b.isPassable()) return true;
            p.subtract(0, 1, 0);
            if (p.getY() < l.getWorld().getMinHeight()) return false;
        }
        return false;
    }

    /** Walks from start along dir (0.5-block steps) and returns the farthest position reachable without entering a block. */
    public static Location walk(Location start, Vector dir, double max) {
        Vector d = dir.clone().normalize();
        Location last = start.clone();
        for (double t = 0.5; t <= max + 1e-6; t += 0.5) {
            Location c = start.clone().add(d.clone().multiply(t));
            if (!fits(c)) break;
            last = c;
        }
        return last;
    }

    /** Teleport destination up to `max` blocks ahead that has walkable ground; null when there is no safe spot. */
    public static Location teleportSpot(Location start, Vector dir, double max) {
        Location far = walk(start, dir, max);
        double dist = far.distance(start);
        for (double t = dist; t >= 1.0; t -= 0.5) {
            Location c = start.clone().add(dir.clone().normalize().multiply(t));
            if (fits(c) && groundBelow(c, 6)) { c.setYaw(start.getYaw()); c.setPitch(start.getPitch()); return c; }
        }
        return null;
    }

    /** Nearest standable position within r blocks of l (used when the Astral rift location got blocked meanwhile). */
    public static Location nearestFit(Location l, int r) {
        if (fits(l) && groundBelow(l, 6)) return l.clone();
        for (int dy = 0; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++)
            for (int s = -1; s <= 1; s += 2) {
                Location c = l.clone().add(dx, dy * s, dz);
                if (fits(c) && groundBelow(c, 6)) return c;
            }
        return null;
    }
}

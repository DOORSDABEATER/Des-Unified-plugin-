# Installation

## Assumed target (NOT inspected - no server files were provided)
| Item | Assumed | Where to change it |
|---|---|---|
| Minecraft / Paper | 1.21.4 | `plugin/build.gradle.kts` (`paper-api:1.21.4-R0.1-SNAPSHOT`) |
| Java | 21 | `build.gradle.kts` |
| Resource pack format | 46 (1.21.4) | `resourcepack/pack.mcmeta` (`pack_format`, `supported_formats`) |

The code uses APIs that exist from Paper 1.21.3/1.21.4 on (`Attribute.ATTACK_DAMAGE`, `Attribute.MAX_HEALTH`, `ItemMeta#setItemModel`,
`items/*.json` item model definitions, `PotionEffectType.SLOWNESS`). For a newer Paper, bump the API version and fix any renamed API;
for an older one (<1.21.2) the item-model system does not exist and the model mapping must be switched to `custom_model_data` overrides.

## Build
```
cd plugin
gradle build            # produces build/libs/Noiseform... -> NullRequiem-1.0.0.jar
```
No Gradle wrapper is bundled. Either install Gradle 8.x or push the repo to GitHub: `.github/workflows/build.yml` builds the JAR and the resource-pack ZIP on every push.

## Deploy
1. Drop `NullRequiem-1.0.0.jar` into `plugins/`, start the server once, stop it, edit `plugins/NullRequiem/config.yml`.
2. Add `NullRequiem-ResourcePack.zip` to your server resource pack. **If DeS already has a pack**, merge the `assets/nullrequiem/` folder into it
   (namespace `nullrequiem` cannot collide with other namespaces) instead of using a second pack; the only shared file is `pack.mcmeta`.
3. `/nullrequiem give ERROR` (the weapon refuses other recipients unless `force` is added).

## Optional dependencies
None. The cinematic uses spectator mode + a camera entity (Paper API only). No ProtocolLib, no client mod.

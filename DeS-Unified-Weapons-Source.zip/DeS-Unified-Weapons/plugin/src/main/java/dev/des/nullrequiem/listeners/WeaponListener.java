package dev.des.nullrequiem.listeners;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.abilities.AbilityManager;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.combat.PlayerState;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Controls (all server-side, configurable):
 *  right-click ........ cast the selected ability (hold to charge FINAL VARIABLE)
 *  F (swap hand) ...... next ability   |  Shift+F ...... 404: WORLD CORRUPTED
 *  Q (drop) ........... previous ability (the weapon can never be dropped by accident)
 *  Shift+scroll ....... cycle abilities
 *  /nullrequiem cast .. command fallback
 */
public final class WeaponListener implements Listener {
    private final NullRequiemPlugin plugin;
    public WeaponListener(NullRequiemPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!plugin.weapons().hasMarker(it)) return;
        if (!plugin.weapons().canUse(p, it)) {
            if (plugin.weapons().isWeapon(it)) p.sendActionBar(plugin.settings().msg("not-owner", "<red>This weapon belongs to another bearer."));
            e.setCancelled(true);
            return;
        }
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null && e.getClickedBlock().getType().isInteractable() && !p.isSneaking()) return;
        e.setUseItemInHand(Event.Result.DENY);
        e.setUseInteractedBlock(Event.Result.DENY);
        e.setCancelled(true);
        if (plugin.cutscene().isCaptured(p.getUniqueId())) return;
        PlayerState st = plugin.states().get(p);
        long now = System.currentTimeMillis();
        if (plugin.abilities().finalVariable().isCharging(p)) { plugin.abilities().finalVariable().hold(p); return; }
        long debounce = plugin.settings().i("controls.click-debounce-ticks", 4) * 50L;
        if (now - st.lastClickMs < debounce) return;
        st.lastClickMs = now;
        plugin.abilities().cast(p, AbilityType.ACTIVES[st.selected], false);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        ItemStack inMain = e.getOffHandItem(); // item that was in the main hand
        if (!plugin.weapons().hasMarker(inMain) && !plugin.weapons().hasMarker(e.getMainHandItem())) return;
        if (!plugin.weapons().canUse(p, inMain)) return;
        e.setCancelled(true);
        if (plugin.cutscene().isCaptured(p.getUniqueId())) return;
        PlayerState st = plugin.states().get(p);
        if (plugin.abilities().finalVariable().isCharging(p)) { plugin.abilities().cast(p, AbilityType.FINAL_VARIABLE, false); return; }
        if (p.isSneaking() && plugin.settings().b("controls.sneak-swap-ultimate", true)) plugin.abilities().cast(p, AbilityType.ULTIMATE, false);
        else plugin.abilities().select(p, 1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrop(PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack();
        if (!plugin.weapons().hasMarker(it)) return;
        if (!plugin.settings().b("controls.block-drop", true)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (plugin.weapons().canUse(p, it)) plugin.abilities().select(p, -1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        if (!p.isSneaking() || !plugin.settings().b("controls.sneak-scroll-select", true)) return;
        ItemStack it = p.getInventory().getItem(e.getPreviousSlot());
        if (!plugin.weapons().canUse(p, it)) return;
        int a = e.getPreviousSlot(), b = e.getNewSlot();
        int delta = (a == 8 && b == 0) ? 1 : (a == 0 && b == 8) ? -1 : Integer.signum(b - a);
        e.setCancelled(true);
        plugin.abilities().select(p, delta);
    }
}

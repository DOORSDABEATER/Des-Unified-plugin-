package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.UUID;

/** ABILITY 4 - scythe driven into the ground; gravitational vortex pulls, pulses damage, ends in a shockwave. */
public final class NullGravity extends AbilityBase {
    public NullGravity(NullRequiemPlugin plugin) { super(plugin, AbilityType.NULL_GRAVITY); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        ctx.maxHitsPerTarget = 5;
        final Vector fwd = Locs.flat(p.getLocation().getDirection());
        final Location c = Locs.ground(p.getLocation().add(fwd.clone().multiply(cfg("distance", 2.5))));
        final double r = cfg("radius", 7.0);
        final int dur = cfgI("duration-ticks", 80);
        final int windup = 8;
        p.swingMainHand();
        sfx().play(p.getLocation(), Snd.A4_SLAM, 1.2f, 1.0f);
        final ItemDisplay scythe = vfx().display(id, c.clone().add(0, 5, 0), "nullrequiem", new Vector3f(2.4f, 2.4f, 2.4f), new Quaternionf(), true, 1);
        final ItemDisplay core = vfx().display(id, c.clone().add(0, 1.6, 0), "void", new Vector3f(0.4f, 0.4f, 0.4f), new Quaternionf(), false, 1);
        tasks().timer(id, 0, 1, windup + dur + 2, t -> {
            if (!alive(p)) return false;
            Vfx.Audience a = vfx().at(c);
            if (t < windup) {
                if (scythe != null && scythe.isValid()) scythe.teleport(c.clone().add(0, 5 - 4.4 * (t + 1) / windup, 0).add(0, 0, 0));
                vfx().arcCrescent(a, c.clone().add(0, 5 - 4.4 * t / windup + 1.5, 0), fwd, 1.5, true, Vfx.NEON, 1.0f);
                return true;
            }
            int v = t - windup;
            if (v == 0) {
                sfx().play(c, Snd.A4_SLAM, 1.4f, 0.7f);
                vfx().block(a, c);
                if (core != null) vfx().animate(core, new Vector3f(2.2f, 2.2f, 2.2f), new Quaternionf().rotateY(3f), 12);
            }
            if (core != null && core.isValid() && v % 10 == 0) vfx().animate(core, new Vector3f(2.2f + (v / 10 % 2) * 0.4f, 2.2f, 2.2f + (v / 10 % 2) * 0.4f), new Quaternionf().rotateY(v * 0.25f).rotateX(v * 0.1f), 10);
            // spiral arms
            for (int arm = 0; arm < 3; arm++) for (int j = 0; j < 10; j++) {
                double rho = r * (1 - j / 10.0);
                double ang = v * 0.35 + arm * 2.094 + j * 0.28;
                a.dust(c.clone().add(Math.cos(ang) * rho, 0.3 + (1 - rho / r) * 1.5, Math.sin(ang) * rho), 1, 0, j % 3 == 0 ? Vfx.VOID : Vfx.NEON, 1.0f);
            }
            if (v % 4 == 0) vfx().ring(a, c.clone().add(0, 0.12, 0), r * (1 - (v % 20) / 24.0), 24, v * 0.2, Vfx.EMERALD, 1.0f);
            // pull
            if (v % 2 == 0) for (LivingEntity e : enemies(p, c, r)) {
                Vector to = c.toVector().add(new Vector(0, 0.6, 0)).subtract(e.getLocation().toVector());
                double d = to.length();
                if (d < 0.9) { e.setVelocity(new Vector(0, 0.02, 0)); continue; }
                dmg().push(p, e, to.normalize().multiply(Math.min(0.55, 0.12 + d * 0.06)), ctx.castId);
            }
            // pulses
            if (v > 0 && v % 20 == 0 && v < dur) {
                sfx().play(c, Snd.A4_PULSE, 1.0f, 0.8f + v / 100f);
                shockRing(id, c, r * 0.6, 6, true);
                for (LivingEntity e : enemies(p, c, r)) if (ctx.hit(e, cfg("pulse-damage", 3))) vfx().hitBurst(e.getLocation().add(0, 1, 0), false);
            }
            return v < dur;
        }, () -> {
            if (alive(p)) {
                sfx().play(c, Snd.A4_SHOCK, 1.5f, 1.0f);
                shockRing(id, c, r + 1, 10, true);
                vfx().sphereBurst(c.clone().add(0, 1.2, 0), 2.5);
                for (LivingEntity e : enemies(p, c, r + 1)) {
                    if (ctx.hit(e, cfg("final-damage", 6))) {
                        Vector out = e.getLocation().toVector().subtract(c.toVector()).setY(0);
                        if (out.lengthSquared() < 1e-4) out = new Vector(1, 0, 0);
                        dmg().push(p, e, out.normalize().multiply(cfg("final-knockback", 1.4)).setY(0.5), ctx.castId);
                    }
                }
            }
            tasks().release(id, scythe);
            tasks().release(id, core);
        });
        return true;
    }
}

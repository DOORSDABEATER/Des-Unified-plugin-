package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.UUID;

/** 11 - katana raised, then an enormous vertical crimson cut with ground shockwaves along its path and a final impact. */
final class HeavenSplitter extends AkaiBase {
    HeavenSplitter(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.HEAVEN_SPLITTER); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        ctx.maxHits = 2;
        final int windup = cfgI("windup-ticks", 14);
        snd(p.getLocation(), "a11_raise", 1.4f, 1.0f);
        final ItemDisplay blade = vfx().display(id, p.getLocation().add(0, 3, 0), "akai:katana", new Vector3f(3.4f, 3.4f, 3.4f), new Quaternionf(), true, 2);
        plugin.tasks().timer(id, 0, 1, windup, t -> {
            if (!alive(p)) return false;
            double f = (t + 1.0) / windup;
            if (blade != null && blade.isValid()) blade.teleport(p.getLocation().add(0, 2.6 + 2.5 * f, 0));
            Vfx.Audience a = vfx().at(p.getLocation());
            vfx().column(a, p.getLocation(), 6, 0.7, 12, AkaiFx.CRIM, 1.3f);
            a.dust(p.getLocation().add(0, 5 * f, 0), 6, 0.5, AkaiFx.GOLD, 1.1f);
            if (t % 3 == 0) p.swingMainHand();
            return true;
        }, () -> {
            if (blade != null) plugin.tasks().release(id, blade);
            if (!alive(p)) return;
            Location eye = p.getEyeLocation();
            final Vector dir = eye.getDirection().clone(); dir.setY(dir.getY() * 0.2).normalize();
            final Location start = eye.clone().add(dir.clone().multiply(2.0)).add(0, 0.6, 0);
            final Vector right = dir.clone().crossProduct(UP).normalize();
            p.swingMainHand();
            snd(p.getLocation(), "a11_split", 2.0f, 1.0f);
            double range = cfg("range", 20), speed = cfg("speed", 1.3);
            slash(ctx, start, dir, range, speed, cfg("hit-radius", 3.4), 0, cfg("damage", 16), 9.0f, right, true, "a4_impact", end -> impact(ctx, end));
            final int[] rings = {0};
            plugin.tasks().timer(id, 3, 3, (int) (range / speed / 3) + 2, t -> {
                Location g = Locs.ground(start.clone().add(dir.clone().multiply(speed * 3 * (t + 1))));
                if (rings[0]++ < 6) { shockRing(id, g, 3.0, 5); snd(g, "a11_shock", 0.6f, 1.2f); }
                return alive(p);
            }, null);
        });
        return true;
    }

    private void impact(AkaiCtx ctx, Location end) {
        Player p = ctx.player;
        Location g = Locs.ground(end);
        snd(g, "a11_shock", 2.0f, 0.8f);
        shockRing(p.getUniqueId(), g, 6.0, 9);
        AkaiFx.sphereBurst(plugin, g.clone().add(0, 1.5, 0), 3.0);
        AkaiFx.cross(plugin, g.clone().add(0, 2, 0), p.getLocation().getDirection().crossProduct(UP), 3.5);
        for (LivingEntity e : enemies(p, g, 5.5)) {
            if (ctx.hit(e, cfg("impact-damage", 6), true)) {
                Vector out = e.getLocation().toVector().subtract(g.toVector()).setY(0);
                if (out.lengthSquared() > 1e-4) plugin.damage().push(p, e, out.normalize().multiply(1.2).setY(0.5), ctx.castId);
            }
        }
    }
}

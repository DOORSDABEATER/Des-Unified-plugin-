package dev.des.nullrequiem;

import dev.des.nullrequiem.abilities.AbilityType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

/** Thin typed wrapper around config.yml. Every getter takes a default so a stale config never breaks the plugin. */
public final class Settings {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final NullRequiemPlugin plugin;

    public Settings(NullRequiemPlugin plugin) { this.plugin = plugin; }

    private FileConfiguration c() { return plugin.getConfig(); }
    public double d(String path, double def) { return c().getDouble(path, def); }
    public int i(String path, int def) { return c().getInt(path, def); }
    public boolean b(String path, boolean def) { return c().getBoolean(path, def); }
    public String s(String path, String def) { return c().getString(path, def); }
    public List<String> list(String path) { return c().getStringList(path); }
    public double ab(AbilityType t, String key, double def) { return c().getDouble("abilities." + t.key() + "." + key, def); }
    public double cooldownSeconds(AbilityType t) { return ab(t, "cooldown", t.defaultCooldown()); }
    public double cost(AbilityType t) { return ab(t, "fragment-cost", t.defaultCost()); }

    public Component mm(String s) { return MM.deserialize(s).decoration(TextDecoration.ITALIC, false); }
    public String prefix() { return s("general.prefix", "<dark_green>[<green>NULL//REQUIEM<dark_green>]</dark_green> "); }

    /** Message from config.messages.<key> (falls back to def), {placeholders} replaced from key/value pairs. */
    public Component msg(String key, String def, String... kv) {
        String raw = s("messages." + key, def);
        for (int i = 0; i + 1 < kv.length; i += 2) raw = raw.replace("{" + kv[i] + "}", kv[i + 1]);
        return mm(prefix() + raw);
    }

    public Component raw(String miniMessage) { return mm(miniMessage); }

    public boolean worldDisabled(World w) { return c().getStringList("general.disabled-worlds").contains(w.getName()); }
}

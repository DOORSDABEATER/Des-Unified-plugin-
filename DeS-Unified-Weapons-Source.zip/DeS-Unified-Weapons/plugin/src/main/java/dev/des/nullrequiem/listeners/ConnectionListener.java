package dev.des.nullrequiem.listeners;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public final class ConnectionListener implements Listener {
    private final NullRequiemPlugin plugin;
    public ConnectionListener(NullRequiemPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        if (e.getLoginResult() == AsyncPlayerPreLoginEvent.Result.ALLOWED) plugin.data().get(e.getUniqueId()); // ConcurrentHashMap, safe off-thread
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.data().get(p.getUniqueId()).name = p.getName();
        plugin.cutscene().recoverPending(p);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        plugin.abilities().abort(p);          // stops tasks, removes entities, ends any ultimate this player was casting
        plugin.cutscene().release(p, true);
        plugin.data().saveSync(id);
        plugin.data().unload(id);
        plugin.cooldowns().clear(id);
        plugin.states().remove(id);
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) { plugin.abilities().abort(e.getPlayer()); }
}

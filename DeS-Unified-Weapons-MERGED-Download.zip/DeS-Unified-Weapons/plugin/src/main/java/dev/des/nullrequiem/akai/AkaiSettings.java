package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.World;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/** akai.yml (separate from config.yml so existing weapons' config is never touched) + learned owner UUID (akai-owner.yml). */
public final class AkaiSettings {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final NullRequiemPlugin plugin;
    private final File file, ownerFile;
    private YamlConfiguration cfg;

    public AkaiSettings(NullRequiemPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "akai.yml");
        this.ownerFile = new File(plugin.getDataFolder(), "akai-owner.yml");
        if (!file.exists()) plugin.saveResource("akai.yml", false);
        reload();
    }

    public void reload() { cfg = YamlConfiguration.loadConfiguration(file); }
    public double d(String p, double def) { return cfg.getDouble(p, def); }
    public int i(String p, int def) { return cfg.getInt(p, def); }
    public boolean b(String p, boolean def) { return cfg.getBoolean(p, def); }
    public String s(String p, String def) { return cfg.getString(p, def); }
    public List<String> list(String p) { return cfg.getStringList(p); }
    public double ab(AkaiType t, String k, double def) { return cfg.getDouble("abilities." + t.key() + "." + k, def); }
    public boolean enabled(AkaiType t) { return cfg.getBoolean("abilities." + t.key() + ".enabled", true); }
    public double cost(AkaiType t) { return ab(t, "energy-cost", t.defaultCost()); }
    public double cooldown(AkaiType t) { return ab(t, "cooldown", t.defaultCooldown()); }
    public Component mm(String s) { return MM.deserialize(s).decoration(TextDecoration.ITALIC, false); }
    public String prefix() { return s("prefix", "<dark_red>[<red>AKAI NO O<dark_red>]</dark_red> "); }
    public boolean worldDisabled(World w) { return cfg.getStringList("disabled-worlds").contains(w.getName()); }

    /** Owner UUID: akai.yml owner.uuid wins; otherwise the UUID learned the first time an admin gives the weapon to owner.name. */
    public UUID ownerUuid() {
        UUID u = parse(cfg.getString("owner.uuid", ""));
        if (u != null) return u;
        if (ownerFile.exists()) return parse(YamlConfiguration.loadConfiguration(ownerFile).getString("uuid", ""));
        return null;
    }

    public void learnOwner(UUID id) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("uuid", id.toString());
        try { y.save(ownerFile); } catch (IOException e) { plugin.getLogger().warning("Could not save akai-owner.yml: " + e.getMessage()); }
    }

    private UUID parse(String s) {
        try { return s == null || s.isBlank() ? null : UUID.fromString(s.trim()); } catch (IllegalArgumentException e) { return null; }
    }
}

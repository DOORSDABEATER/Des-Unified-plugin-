package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** ABILITY 11 - high-cost dimensional fracture: pulls, debuffs, and collapses; exposed enemies take heavy damage. */
public final class AbsoluteNullification extends AbilityBase {
    public AbsoluteNullification(NullRequiemPlugin plugin) { super(plugin, AbilityType.ABSOLUTE_NULLIFICATION); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        ctx.maxHitsPerTarget = 2;
        final Location aim = aimPoint(p, cfg("range", 16));
        final Location c = Locs.ground(aim).add(0, 0.0, 0);
        final double r = cfg("radius", 10.0);
        final int dur = cfgI("duration-ticks", 80);
        final int debuffTicks = (int) (cfg("debuff-seconds", 5) * 20);
        p.swingMainHand();
        sfx().play(c, Snd.A11_OPEN, 1.5f, 1.0f);
        final ItemDisplay core = vfx().display(id, c.clone().add(0, 2.4, 0), "void", new Vector3f(0.5f, 0.5f, 0.5f), new Quaternionf(), false, 1);
        final ItemDisplay ringA = vfx().display(id, c.clone().add(0, 2.4, 0), "ring", new Vector3f(3.5f, 1f, 3.5f), new Quaternionf().rotateX(1.2f), false, 1);
        final ItemDisplay ringB = vfx().display(id, c.clone().add(0, 2.4, 0), "ring", new Vector3f(5.5f, 1f, 5.5f), new Quaternionf().rotateZ(1.2f), false, 1);
        final Set<UUID> debuffed = new HashSet<>();
        tasks().timer(id, 0, 1, dur + 2, t -> {
            if (!alive(p)) return false;
            Vfx.Audience a = vfx().at(c);
            if (t == 4 && core != null) vfx().animate(core, new Vector3f(4.2f, 4.2f, 4.2f), new Quaternionf().rotateY(2f), 16);
            if (t % 8 == 0) {
                if (ringA != null) vfx().animate(ringA, new Vector3f(3.5f, 1f, 3.5f), new Quaternionf().rotateX(1.2f).rotateY(t * 0.2f), 8);
                if (ringB != null) vfx().animate(ringB, new Vector3f(5.5f, 1f, 5.5f), new Quaternionf().rotateZ(1.2f).rotateY(-t * 0.17f), 8);
            }
            Location mid = c.clone().add(0, 2.4, 0);
            vfx().sphere(a, mid, 1.6 + Math.sin(t * 0.3) * 0.15, 18, Vfx.VOID, 1.8f);
            vfx().tiltedRing(a, mid, new Vector(1, 0.3, 0), 2.6, 18, t * 0.3, Vfx.NEON, 1.2f);
            vfx().tiltedRing(a, mid, new Vector(-0.4, 1, 0.5), 3.4, 22, -t * 0.25, Vfx.EMERALD, 1.1f);
            if (t % 3 == 0) for (int k = 0; k < 5; k++) {
                double ang = Math.random() * Math.PI * 2;
                Location edge = c.clone().add(Math.cos(ang) * r, 0.2, Math.sin(ang) * r);
                vfx().crack(a, edge, mid, 0.8, Vfx.NEON, 1.0f);
            }
            if (t % 14 == 0) sfx().play(c, Snd.A11_PULL, 0.9f, 0.9f);
            if (t % 2 == 0) for (LivingEntity e : enemies(p, c, r)) {
                Vector to = mid.toVector().subtract(e.getLocation().toVector());
                double d = to.length();
                if (d < 1.5) { e.setVelocity(new Vector(0, 0.02, 0)); }
                else dmg().push(p, e, to.normalize().multiply(Math.min(0.6, 0.15 + d * 0.05)), ctx.castId);
                if (debuffed.add(e.getUniqueId()) && !dmg().isBoss(e)) {
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, debuffTicks, 2, false, true, true));
                    e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, debuffTicks, 1, false, true, true));
                    vfx().glitch(vfx().at(e.getLocation()), e.getLocation());
                }
            }
            return t < dur;
        }, () -> {
            if (alive(p)) {
                sfx().play(c, Snd.A11_COLLAPSE, 1.8f, 1.0f);
                shockRing(id, c, r, 10, true);
                vfx().sphereBurst(c.clone().add(0, 2.2, 0), 4.0);
                for (LivingEntity e : enemies(p, c, r)) {
                    boolean exposed = plugin.fracture().isExposed(e);
                    double d = exposed ? cfg("exposed-damage", 16) : cfg("damage", 5);
                    if (ctx.hit(e, d, false)) {
                        Vector out = e.getLocation().toVector().subtract(c.toVector()).setY(0);
                        if (out.lengthSquared() > 1e-4) dmg().push(p, e, out.normalize().multiply(0.9).setY(0.4), ctx.castId);
                        vfx().hitBurst(e.getLocation().add(0, 1, 0), exposed);
                    }
                }
            }
            tasks().release(id, core); tasks().release(id, ringA); tasks().release(id, ringB);
        });
        return true;
    }
}

package dev.des.nullrequiem.collection;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.mastery.MasteryManager;
import dev.des.nullrequiem.storage.PlayerData;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Legendary-weapon collection entry for NULL//REQUIEM.
 * The existing DeS collection plugin could not be inspected, so this ships (a) a standalone, config-driven GUI and
 * (b) {@link #exportEntry(UUID)} - a plain Map other plugins can read to list the weapon in their own collection UI.
 */
public final class CollectionIntegration implements Listener {
    private static final class Holder implements InventoryHolder {
        private Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    private static final Material[] ICONS = {
        Material.AMETHYST_SHARD, Material.ENDER_EYE, Material.CLOCK, Material.ANVIL, Material.GLASS, Material.BELL,
        Material.SCULK_CATALYST, Material.PRISMARINE_SHARD, Material.SUGAR, Material.WITHER_SKELETON_SKULL, Material.OBSIDIAN, Material.NETHER_STAR
    };

    private final NullRequiemPlugin plugin;
    public CollectionIntegration(NullRequiemPlugin plugin) { this.plugin = plugin; }

    /** Data for external collection plugins. */
    public Map<String, Object> exportEntry(UUID id) {
        PlayerData d = plugin.data().get(id);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("weapon", "NULL//REQUIEM");
        m.put("title", "The Last Error in Reality");
        m.put("rarity", "MYTHICAL");
        m.put("owner", plugin.settings().s("owner.name", "ERROR"));
        m.put("owned", d.owned);
        m.put("mastery-stage", plugin.mastery().stage(d.xp > 0 ? d.xp : 0));
        m.put("mastery-xp", d.xp);
        m.put("kills", d.kills);
        m.put("exposed-kills", d.exposedKills);
        m.put("ability-casts", d.casts);
        m.put("ultimates", d.ultimates);
        return m;
    }

    public void open(Player viewer, Player target) {
        Settings s = plugin.settings();
        PlayerData d = plugin.data().get(target.getUniqueId());
        int stage = plugin.mastery().stage(d.xp);
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 45, s.mm(s.s("gui.title", "<dark_green><bold>NULL//REQUIEM") + " <dark_gray>- <green>" + target.getName()));
        h.inv = inv;
        ItemStack pane = named(Material.BLACK_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < 45; i++) inv.setItem(i, pane);

        List<String> wl = new ArrayList<>();
        wl.add("<dark_green><bold>MYTHICAL <dark_gray>- <green>Personal Legendary Weapon");
        wl.add("<gray>\"The Last Error in Reality\"");
        for (String line : s.list("gui.lore")) wl.add(line);
        wl.add("");
        wl.add("<gray>Bearer: <green>" + s.s("owner.name", "ERROR"));
        wl.add("<gray>Collected: " + (d.owned ? "<green>YES" : "<red>NOT YET"));
        wl.add("<gray>Kills: <white>" + d.kills + " <dark_gray>(exposed: " + d.exposedKills + ")");
        wl.add("<gray>Ability hits: <white>" + d.hits + "<dark_gray> / casts: <white>" + d.casts + "<dark_gray> / 404s: <white>" + d.ultimates);
        ItemStack weapon = named(Material.NETHERITE_HOE, "<gradient:#39ff14:#00a651><bold>NULL//REQUIEM</bold></gradient>", wl);
        ItemMeta wm = weapon.getItemMeta();
        NamespacedKey model = NamespacedKey.fromString(s.s("weapon.item-model", "nullrequiem:nullrequiem"));
        if (model != null) wm.setItemModel(model);
        weapon.setItemMeta(wm);
        inv.setItem(13, weapon);

        // mastery progress
        long next = plugin.mastery().nextThreshold(stage);
        List<String> ml = new ArrayList<>();
        ml.add("<gray>Stage: <green><bold>" + MasteryManager.NAMES[stage - 1]);
        ml.add("<gray>XP: <white>" + d.xp + (stage < 3 ? "<dark_gray>/<white>" + next : " <green>(MAX)"));
        ml.add(bar(stage < 3 ? d.xp / (double) next : 1.0));
        if (stage >= 3) ml.add("<dark_green>Title: <green>" + plugin.mastery().title(3));
        inv.setItem(4, named(Material.EXPERIENCE_BOTTLE, "<green><bold>MASTERY", ml));

        String[] stageDesc = {"Subtle emerald glitches, basic idle aura.", "Stronger particles and dimensional presence.", "Full emerald awakening, exclusive title."};
        for (int i = 0; i < 3; i++) {
            boolean un = stage >= i + 1;
            inv.setItem(38 + i * 2, named(un ? Material.LIME_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE,
                (un ? "<green>" : "<dark_gray>") + "STAGE " + (i + 1) + ": " + MasteryManager.NAMES[i], List.of("<gray>" + stageDesc[i], un ? "<green>Unlocked" : "<red>Locked")));
        }

        // abilities
        int[] slots = {18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29};
        for (int i = 0; i < 12; i++) {
            AbilityType t = AbilityType.ACTIVES[i];
            List<String> l = new ArrayList<>();
            String desc = s.s("gui.abilities." + t.key(), "");
            if (!desc.isEmpty()) l.add("<gray>" + desc);
            l.add("<dark_gray>Cost: <white>" + (int) s.cost(t) + " <dark_gray>| Cooldown: <white>" + (int) s.cooldownSeconds(t) + "s");
            l.add("<dark_gray>Uses: <white>" + d.uses.getOrDefault(t.key(), 0));
            int slot = i < 9 ? 18 + i : 27 + (i - 9);
            inv.setItem(slot, named(ICONS[i], "<green>" + (i + 1) + ". " + t.display(), l));
        }
        List<String> ul = new ArrayList<>();
        ul.add("<gray>" + s.s("gui.abilities.ultimate", "Cinematic AOE execution."));
        ul.add("<dark_gray>Cost: <white>100 <dark_gray>| Cooldown: <white>" + (int) s.cooldownSeconds(AbilityType.ULTIMATE) + "s");
        ul.add("<dark_gray>Cast: <white>" + d.ultimates);
        inv.setItem(31, named(ICONS[12 - 1 + 0], "<green><bold>404: WORLD CORRUPTED", ul));
        inv.setItem(40, named(Material.ENDER_PEARL, "<green>Cinematic camera: " + (d.cutsceneCamera ? "<white>ON" : "<red>OFF"), List.of("<gray>/nullrequiem camera <on|off>", "<dark_gray>Affects how YOU see the 404 cinematic.")));
        viewer.openInventory(inv);
    }

    private String bar(double f) {
        int n = (int) Math.round(Math.max(0, Math.min(1, f)) * 20);
        return "<green>" + "|".repeat(n) + "<dark_gray>" + "|".repeat(20 - n);
    }

    private ItemStack named(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        Settings s = plugin.settings();
        meta.displayName(s.mm(name));
        if (lore != null) { List<Component> l = new ArrayList<>(); for (String x : lore) l.add(s.mm(x)); meta.lore(l); }
        meta.addItemFlags(ItemFlag.values());
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler public void onClick(InventoryClickEvent e) { if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true); }
    @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true); }
}

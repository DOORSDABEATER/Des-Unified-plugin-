package com.des.legendary;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.GameMode;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Per-weapon mastery (levels 1-6): XP only from legitimate hits/kills, with AFK/dummy/same-victim farming protection. */
public final class Mastery {
    private static final String[] NAMES = {"Awakening", "Resonance", "Evolution", "Overdrive", "Ascension", "Transcendence"};
    private final LegendaryPlugin pl;
    private final Map<UUID, Map<UUID, double[]>> victimXp = new HashMap<>();   // attacker -> victim -> {windowStartMs, xp}

    public Mastery(LegendaryPlugin pl) { this.pl = pl; }

    public List<Double> thresholds() {
        List<Double> l = pl.getConfig().getDoubleList("mastery.levels");
        return l.size() == 6 ? l : List.of(0.0, 400.0, 1200.0, 2800.0, 5500.0, 10000.0);
    }
    public int level(PlayerData d, Weapon w) {
        double xp = d.of(w).xp; List<Double> t = thresholds(); int lv = 1;
        for (int i = 0; i < t.size(); i++) if (xp >= t.get(i)) lv = i + 1;
        return lv;
    }
    public String levelName(int lv) { return NAMES[Math.max(0, Math.min(5, lv - 1))]; }
    public String title(Weapon w, int lv) {
        if (lv < 6) return "";
        return pl.cfg().s("mastery.titles." + w.key, w == Weapon.NOISEFORM ? "Sonic Sovereign" : "Cosmic Sovereign");
    }

    /** Is this victim a legitimate source of energy/XP? (no dummies, armor stands, AFK players, invulnerable or passive mobs) */
    public boolean eligible(Player a, LivingEntity v) {
        if (v instanceof ArmorStand || v.isInvulnerable() || v.getScoreboardTags().contains("des_dummy")) return false;
        Component cn = v.customName();
        if (cn != null) {
            String n = PlainTextComponentSerializer.plainText().serialize(cn).toLowerCase();
            for (String s : pl.cfg().list("anti-farm.dummy-name-contains")) if (!s.isEmpty() && n.contains(s.toLowerCase())) return false;
        }
        if (v instanceof Player vp) {
            if (vp.getGameMode() != GameMode.SURVIVAL && vp.getGameMode() != GameMode.ADVENTURE) return false;
            PlayerData vd = pl.data().peek(vp.getUniqueId());
            long afkMs = pl.cfg().i("anti-farm.afk-seconds", 20) * 1000L;
            return vd == null || System.currentTimeMillis() - vd.lastMove <= afkMs;
        }
        return Targets.hostile(v) || pl.cfg().b("anti-farm.allow-passive-mobs", false);
    }

    private double capped(Player a, LivingEntity v, double xp) {
        long now = System.currentTimeMillis(), win = pl.cfg().i("anti-farm.xp-window-minutes", 60) * 60000L;
        double cap = v instanceof Player ? pl.cfg().d("anti-farm.xp-cap-per-player-victim", 60.0) : pl.cfg().d("anti-farm.xp-cap-per-mob-victim", 12.0);
        double[] e = victimXp.computeIfAbsent(a.getUniqueId(), k -> new HashMap<>()).computeIfAbsent(v.getUniqueId(), k -> new double[]{now, 0});
        if (now - e[0] > win) { e[0] = now; e[1] = 0; }
        double ok = Math.max(0, Math.min(xp, cap - e[1])); e[1] += ok; return ok;
    }

    public void onHit(Ctx c, LivingEntity t) {
        if (!eligible(c.p, t)) return;
        double xp = pl.cfg().d("mastery.xp.hit", 3.0) * (c.id.ultimate ? pl.cfg().d("mastery.xp.ultimate-multiplier", 2.0) : 1.0);
        addXp(c.p, c.w, capped(c.p, t, xp));
    }
    public void onMelee(Player p, Weapon w, LivingEntity t) {
        if (!eligible(p, t)) return;
        addXp(p, w, capped(p, t, pl.cfg().d("mastery.xp.melee-hit", 1.0)));
    }
    public void onKill(Player p, LivingEntity v, AbilityId by) {
        Weapon w = by != null ? by.weapon : pl.items().weaponOf(p.getInventory().getItemInMainHand());
        if (w == null || !eligible(p, v)) return;
        PlayerData d = pl.data().get(p.getUniqueId()); d.of(w).kills++; d.dirty = true;
        addXp(p, w, capped(p, v, v instanceof Player ? pl.cfg().d("mastery.xp.kill-player", 25.0) : pl.cfg().d("mastery.xp.kill-mob", 4.0)));
    }
    public void bonus(Player p, Weapon w, double xp) { addXp(p, w, xp); }

    public void addXp(Player p, Weapon w, double amt) {
        if (amt <= 0) return;
        PlayerData d = pl.data().get(p.getUniqueId());
        int before = level(d, w); d.of(w).xp += amt; d.dirty = true;
        int after = level(d, w);
        if (after > before) levelUp(p, w, after);
    }

    private void levelUp(Player p, Weapon w, int lv) {
        String reward = pl.cfg().s("mastery.rewards." + w.key + "." + lv, "");
        pl.sfx().to(p, "ui.levelup", 1f, 1f);
        pl.fx().burst(p.getLocation().add(0, 1, 0), w == Weapon.NOISEFORM ? Pal.PURPLE : Pal.CYAN, Pal.WHITE, 60, 1.8);
        String t = title(w, lv);
        p.showTitle(Title.title(MiniMessage.miniMessage().deserialize("<" + w.color.asHexString() + "><bold>" + w.display + " MASTERY " + lv),
                MiniMessage.miniMessage().deserialize("<gray>" + levelName(lv) + (t.isEmpty() ? "" : " - <gold>" + t)),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(2200), Duration.ofMillis(500))));
        if (!reward.isEmpty()) p.sendMessage(MiniMessage.miniMessage().deserialize("<" + w.color.asHexString() + ">" + w.display + " <gray>Level " + lv + " unlocked: <white>" + reward));
    }

    public void forget(UUID p) { victimXp.remove(p); }
}

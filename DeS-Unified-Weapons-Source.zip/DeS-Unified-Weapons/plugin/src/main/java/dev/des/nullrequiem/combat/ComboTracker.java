package dev.des.nullrequiem.combat;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.abilities.CastContext;
import dev.des.nullrequiem.sounds.Snd;
import org.bukkit.entity.Player;

/**
 * Combo chain: successful (hit-confirmed) casts of DIFFERENT abilities within the window extend a chain.
 * From the third link on, each new link pays Reality Fragments and mastery XP. Never forced - abilities work alone.
 */
public final class ComboTracker {
    private final NullRequiemPlugin plugin;
    public ComboTracker(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public void onCastHit(CastContext ctx) {
        Player p = ctx.player;
        PlayerState st = ctx.state;
        long now = System.currentTimeMillis();
        if (now > st.chainUntil) { st.chain = 0; st.chainSet.clear(); }
        if (st.chainSet.add(ctx.type)) st.chain++;
        else { st.chain = 1; st.chainSet.clear(); st.chainSet.add(ctx.type); }
        st.chainUntil = now + (long) (plugin.settings().d("combos.window-seconds", 7) * 1000);
        if (st.chain >= 3) {
            int extra = Math.min(3, st.chain - 2);
            plugin.fragments().add(p, plugin.settings().d("fragments.combo-bonus", 8) * extra);
            plugin.mastery().addXp(p, (long) (plugin.settings().d("mastery.xp.combo", 15) * extra));
            plugin.sfx().playTo(p, Snd.EXPOSED, 0.6f, 1.4f);
            p.sendActionBar(plugin.settings().raw("<dark_green>[NULL//REQUIEM] <green><bold>COMBO x" + st.chain + "</bold> <gray>+" + (int) (plugin.settings().d("fragments.combo-bonus", 8) * extra) + " fragments"));
            st.msgUntil = now + 1200;
        }
    }
}

package com.des.legendary;

import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/** Fired before an ability damages or crowd-controls an entity. Region/safe-zone plugins can cancel it. */
public final class AbilityTargetEvent extends Event implements Cancellable {
    private static final HandlerList HANDLERS = new HandlerList();
    private final Player caster; private final LivingEntity target; private final AbilityId ability; private final boolean crowdControl;
    private boolean cancelled;

    public AbilityTargetEvent(Player caster, LivingEntity target, AbilityId ability, boolean crowdControl) {
        this.caster = caster; this.target = target; this.ability = ability; this.crowdControl = crowdControl;
    }
    public Player getCaster() { return caster; }
    public LivingEntity getTarget() { return target; }
    public AbilityId getAbility() { return ability; }
    public boolean isCrowdControl() { return crowdControl; }
    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean c) { this.cancelled = c; }
    @Override public HandlerList getHandlers() { return HANDLERS; }
    public static HandlerList getHandlerList() { return HANDLERS; }
}

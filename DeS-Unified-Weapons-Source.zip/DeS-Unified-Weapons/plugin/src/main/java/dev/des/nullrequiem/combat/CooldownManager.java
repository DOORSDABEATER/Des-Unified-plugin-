package dev.des.nullrequiem.combat;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.storage.PlayerData;
import org.bukkit.entity.Player;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Central cooldowns. The ultimate cooldown is persisted in PlayerData so relogging does not reset it. */
public final class CooldownManager {
    private final NullRequiemPlugin plugin;
    private final Map<UUID, EnumMap<AbilityType, Long>> map = new HashMap<>();

    public CooldownManager(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public long remainingMs(Player p, AbilityType t) {
        long now = System.currentTimeMillis();
        if (t.isUltimate()) return Math.max(0, plugin.data().get(p.getUniqueId()).ultimateCooldownUntil - now);
        EnumMap<AbilityType, Long> m = map.get(p.getUniqueId());
        if (m == null) return 0;
        Long until = m.get(t);
        return until == null ? 0 : Math.max(0, until - now);
    }

    public void setSeconds(Player p, AbilityType t, double seconds) {
        long until = System.currentTimeMillis() + (long) (seconds * 1000);
        if (t.isUltimate()) {
            PlayerData d = plugin.data().get(p.getUniqueId());
            d.ultimateCooldownUntil = until;
            return;
        }
        map.computeIfAbsent(p.getUniqueId(), k -> new EnumMap<>(AbilityType.class)).put(t, until);
    }

    public void clear(UUID id) { map.remove(id); }

    public void reset(Player p) {
        map.remove(p.getUniqueId());
        plugin.data().get(p.getUniqueId()).ultimateCooldownUntil = 0;
    }
}

package com.des.legendary;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Runs every active ability as a "Step" from ONE global repeating task (no per-ability schedulers => no leaked tasks).
 * Finished / cancelled casts always run their cleanup and remove the entities they own.
 */
public final class CastManager {
    public interface Step { boolean tick(int age); }          // return true when the cast is finished

    private static final class Active {
        final Ctx ctx; final Step step; final Runnable end; int age; boolean done;
        Active(Ctx c, Step s, Runnable e) { ctx = c; step = s; end = e; }
    }

    private final LegendaryPlugin pl;
    private final List<Active> list = new ArrayList<>();
    private long now;
    private BukkitTask task;

    public CastManager(LegendaryPlugin pl) { this.pl = pl; }

    public void start() { task = Bukkit.getScheduler().runTaskTimer(pl, this::tick, 1L, 1L); }
    public long now() { return now; }
    public int active() { return list.size(); }

    public boolean start(Ctx c, Step s, Runnable end) {
        if (list.size() >= pl.cfg().i("limits.max-active-casts", 150)) return false;
        list.add(new Active(c, s, end));
        return true;
    }
    public int count(UUID id) { int n = 0; for (Active a : list) if (!a.done && a.ctx.p.getUniqueId().equals(id)) n++; return n; }

    private void tick() {
        now++;
        pl.fx().tick(now);
        int n = list.size();                                   // casts started during this tick begin next tick
        for (int i = 0; i < n; i++) {
            Active a = list.get(i);
            if (a.done) continue;
            Player p = a.ctx.p;
            try {
                if (!p.isOnline() || p.isDead()) { finish(a, true, false); continue; }
                if (a.ctx.requireHeld && pl.items().weaponOf(p.getInventory().getItemInMainHand()) != a.ctx.w) { finish(a, true, true); continue; }
                if (a.step.tick(a.age++)) finish(a, false, false);
            } catch (Throwable t) {
                pl.getLogger().warning("Ability " + a.ctx.id + " failed and was cancelled: " + t);
                finish(a, true, true);
            }
        }
        list.removeIf(a -> a.done);
        if (now % 600 == 0) pl.dmg().prune(now);
    }

    private void finish(Active a, boolean cancelled, boolean refund) {
        if (a.done) return;
        a.done = true; a.ctx.cancelled = cancelled;
        try { if (a.end != null) a.end.run(); } catch (Throwable t) { pl.getLogger().warning("Cleanup error in " + a.ctx.id + ": " + t); }
        a.ctx.cleanup();
        if (cancelled && refund && a.ctx.refundEnergy > 0 && a.ctx.p.isOnline() && !a.ctx.p.isDead()) pl.energy().gain(a.ctx.p, a.ctx.w, a.ctx.refundEnergy);
    }

    public void cancel(UUID player, boolean refund) {
        for (Active a : new ArrayList<>(list)) if (!a.done && a.ctx.p.getUniqueId().equals(player)) finish(a, true, refund);
        list.removeIf(a -> a.done);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (Active a : new ArrayList<>(list)) finish(a, true, false);
        list.clear();
    }
}

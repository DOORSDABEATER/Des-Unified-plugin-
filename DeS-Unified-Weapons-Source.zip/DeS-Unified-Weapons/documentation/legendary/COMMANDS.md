# Commands, permissions, controls

| Command | Permission | What it does |
|---|---|---|
| `/noiseform give [player]` · `/nebulux give [player]` | `des.legendary.give` (op) | Gives the weapon (marks it owned in the collection) |
| `/noiseform reload` · `/nebulux reload` · `/weapon reload` | `des.legendary.reload` (op) | Reloads config.yml |
| `/weapon mastery [player]` | `des.legendary.collection` (+`.others` for other players) | Mastery level, XP, casts, hits, kills |
| `/weapon collection [player]` | same | Opens the collection GUI |
| `/weapon ability <name>` | `des.legendary.use` | Casts an ability by name (needs the weapon in hand). Reliable fallback to the controls |
| `/weapon select <name\|1-6>` | `des.legendary.use` | Selects the active ability |
| `/weapon energy <set\|add> <player> <weapon> <n>` | `des.legendary.admin` (op) | Test helper for Resonance / Cosmic Energy |

Ability names: sonic-rupture, frequency-break, static-overdrive, dissonance, echo-blades, resonance-guard, final-frequency,
prismatic-cleave, starfall, gravity-well, astral-fracture, chromatic-refraction, celestial-pierce, supernova.

## Default controls (all remappable in `config.yml -> controls`)
| Action | Default trigger |
|---|---|
| Cast selected ability | Right-click (never on chests/doors/buttons) |
| Next / previous ability | Swap-hand `F` / Sneak + `F` |
| Ultimate (100 energy) | Sneak + Right-click |
| Arm/disarm Empower (50 energy) | Sneak + Left-click (air) |
Triggers: `RIGHT_CLICK, SNEAK_RIGHT_CLICK, LEFT_CLICK, SNEAK_LEFT_CLICK, SWAP_HAND, SNEAK_SWAP_HAND, NONE`.
The weapon can't be swapped to the off-hand by accident. The action bar always shows the selected ability, its cooldown, the energy meter and Overdrive / armed / recall / empowered-strike state.

## Integration
`AbilityTargetEvent` (cancellable) fires before every damage or crowd-control application: cancel it from your WorldGuard/claims/safe-zone listener to protect an area.
`disabled-worlds` in config switches the weapons off per world. Creative/spectator players, the caster, own pets, NPCs (metadata `NPC`) and team-protected players are never targeted.

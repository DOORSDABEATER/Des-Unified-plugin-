package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

abstract class AkaiBase implements AkaiAbility {
    protected static final Vector UP = new Vector(0, 1, 0);
    protected final NullRequiemPlugin plugin;
    protected final AkaiModule m;
    protected final AkaiType type;

    protected AkaiBase(NullRequiemPlugin plugin, AkaiModule m, AkaiType type) { this.plugin = plugin; this.m = m; this.type = type; }
    @Override public AkaiType type() { return type; }

    protected double cfg(String k, double def) { return m.settings().ab(type, k, def); }
    protected int cfgI(String k, int def) { return (int) Math.round(m.settings().ab(type, k, def)); }
    protected Vfx vfx() { return plugin.vfx(); }
    protected boolean alive(Player p) { return p.isOnline() && !p.isDead(); }
    protected void snd(Location l, String id, float v, float pitch) { AkaiFx.sound(plugin, l, id, v, pitch); }
    protected List<LivingEntity> enemies(Player p, Location c, double r) { return plugin.damage().enemies(p, c, r); }

    protected void actionbar(Player p, String mm) {
        p.sendActionBar(m.settings().mm(mm));
        m.state(p).msgUntil = System.currentTimeMillis() + 1500;
    }

    protected LivingEntity aimTarget(Player p, double range, double coneDeg, boolean preferDecreed) {
        Location eye = p.getEyeLocation(); Vector dir = eye.getDirection().normalize();
        double minDot = Math.cos(Math.toRadians(coneDeg)); LivingEntity best = null; double bestScore = -1;
        for (LivingEntity e : enemies(p, eye, range)) {
            Vector to = e.getLocation().add(0, e.getHeight() / 2, 0).toVector().subtract(eye.toVector());
            double dist = to.length();
            if (dist < 0.1 || dist > range) continue;
            double dot = to.clone().normalize().dot(dir);
            if (dot < minDot || !p.hasLineOfSight(e)) continue;
            double score = dot - dist / (range * 4.0) + (preferDecreed && m.marks().isDecreed(e) ? 1.0 : 0.0);
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    protected Location aimPoint(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
        if (r == null) return eye.clone().add(eye.getDirection().multiply(range));
        Location hit = r.getHitPosition().toLocation(p.getWorld());
        if (r.getHitBlockFace() != null) hit.add(r.getHitBlockFace().getDirection().multiply(0.4));
        return hit;
    }

    /** Applies configured "TYPE:amplifier" effects (e.g. SLOWNESS:1) for ticks. */
    protected void applyEffects(LivingEntity e, List<String> specs, int ticks) {
        for (String s : specs) {
            String[] sp = s.split(":");
            @SuppressWarnings("deprecation") PotionEffectType t = PotionEffectType.getByKey(NamespacedKey.minecraft(sp[0].toLowerCase()));
            if (t == null) continue;
            int amp = 0;
            try { if (sp.length > 1) amp = Integer.parseInt(sp[1]); } catch (NumberFormatException ignored) { }
            e.addPotionEffect(new PotionEffect(t, ticks, amp, false, true, true));
        }
    }

    /** Crimson slash projectile (3D display + particles). normalHint = direction the crescent plane's normal points to. */
    protected void slash(AkaiCtx ctx, Location start, Vector dirIn, double range, double speed, double radius, int pierce, double dmg, float scale,
                         Vector normalHint, boolean decree, String hitSound, Consumer<Location> onEnd) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        final Vector dir = dirIn.clone().normalize(); final Location pos = start.clone();
        final Vector hint = normalHint == null ? UP : normalHint;
        final boolean vertical = Math.abs(hint.clone().normalize().getY()) < 0.5;
        final ItemDisplay disp = vfx().display(id, pos, "akai:slash", new Vector3f(scale, scale, scale), Vfx.orient(dir, hint), true, 1);
        final Set<UUID> hit = new HashSet<>(); final int[] n = {0}; final double[] trav = {0};
        plugin.tasks().timer(id, 1, 1, (int) Math.ceil(range / speed) + 2, tick -> {
            if (!alive(p)) return false;
            pos.add(dir.clone().multiply(speed)); trav[0] += speed;
            if (!pos.getBlock().isPassable()) return false;
            if (disp != null && disp.isValid()) disp.teleport(pos);
            Vfx.Audience a = vfx().at(pos);
            if (disp == null || tick % 2 == 0) vfx().arcCrescent(a, pos, dir, scale * 0.8, vertical, AkaiFx.CRIM, AkaiFx.GOLD, 1.1f);
            a.dust(pos.clone().subtract(dir.clone().multiply(0.7)), 3, 0.25, AkaiFx.BLOOD, 1.1f);
            if (tick % 3 == 0) AkaiFx.lightning(plugin, a, pos.clone().subtract(dir.clone().multiply(2.0)), pos);
            if (dmg > 0) for (LivingEntity e : enemies(p, pos, radius)) {
                if (!hit.add(e.getUniqueId())) continue;
                if (ctx.hit(e, dmg, decree)) {
                    Location el = e.getLocation().add(0, e.getHeight() / 2, 0);
                    AkaiFx.hitBurst(plugin, el, m.marks().isDecreed(e));
                    if (hitSound != null) snd(el, hitSound, 0.9f, 1.0f);
                    n[0]++;
                    if (pierce > 0 && n[0] >= pierce) return false;
                }
            }
            return trav[0] < range;
        }, () -> { if (disp != null) plugin.tasks().release(id, disp); if (onEnd != null) onEnd.accept(pos.clone()); });
    }

    /** Expanding crimson ground ring (display + particles). */
    protected void shockRing(UUID owner, Location c, double radius, int ticks) {
        float target = (float) (radius * 2.13);
        ItemDisplay d = vfx().display(owner, c.clone().add(0, 0.12, 0), "akai:ring", new Vector3f(0.5f, 1f, 0.5f), new Quaternionf(), false, 0);
        if (d != null) plugin.tasks().later(owner, 1, () -> vfx().animate(d, new Vector3f(target, 1f, target), new Quaternionf(), ticks));
        plugin.tasks().timer(owner, 0, 1, ticks + 3, t -> {
            double r = radius * Math.min(1.0, (t + 1.0) / ticks);
            Vfx.Audience a = vfx().at(c);
            vfx().ring(a, c.clone().add(0, 0.15, 0), r, Math.max(10, (int) (r * 5)), t * 0.3, AkaiFx.CRIM, 1.3f);
            if (t % 2 == 0) vfx().ring(a, c.clone().add(0, 0.25, 0), r * 0.85, Math.max(8, (int) (r * 3)), -t * 0.2, AkaiFx.GOLD, 1.0f);
            return t < ticks;
        }, () -> { if (d != null) plugin.tasks().release(owner, d); });
    }
}

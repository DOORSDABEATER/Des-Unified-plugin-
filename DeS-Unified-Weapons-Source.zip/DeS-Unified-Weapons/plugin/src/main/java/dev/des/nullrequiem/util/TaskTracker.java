package dev.des.nullrequiem.util;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Owns every repeating task and temporary entity the plugin creates, grouped by caster.
 * Guarantees: bounded lifetime (maxTicks), cleanup on quit/death/disable, no leaks.
 */
public final class TaskTracker {
    public interface Tick { boolean run(int tick); }

    private final NullRequiemPlugin plugin;
    private final Map<UUID, Set<Integer>> tasks = new HashMap<>();
    private final Map<UUID, Set<Entity>> entities = new HashMap<>();

    public TaskTracker(NullRequiemPlugin plugin) { this.plugin = plugin; }

    /** Runs tick.run(n) every period ticks until it returns false or maxTicks runs happened. onEnd runs on normal completion only. */
    public int timer(UUID owner, long delay, long period, int maxTicks, Tick tick, Runnable onEnd) {
        final int[] n = {0};
        BukkitRunnable r = new BukkitRunnable() {
            @Override public void run() {
                boolean cont = false;
                try { cont = tick.run(n[0]++) && n[0] < maxTicks; }
                catch (Throwable t) { plugin.getLogger().log(Level.WARNING, "Effect error (cancelled)", t); }
                if (!cont) {
                    cancel();
                    Set<Integer> s = tasks.get(owner);
                    if (s != null) { s.remove(getTaskId()); if (s.isEmpty()) tasks.remove(owner); }
                    if (onEnd != null) {
                        try { onEnd.run(); } catch (Throwable t) { plugin.getLogger().log(Level.WARNING, "Effect end error", t); }
                    }
                }
            }
        };
        BukkitTask bt = r.runTaskTimer(plugin.java(), delay, Math.max(1, period));
        tasks.computeIfAbsent(owner, k -> new HashSet<>()).add(bt.getTaskId());
        return bt.getTaskId();
    }

    public int later(UUID owner, long delay, Runnable action) {
        BukkitRunnable r = new BukkitRunnable() {
            @Override public void run() {
                Set<Integer> s = tasks.get(owner);
                if (s != null) { s.remove(getTaskId()); if (s.isEmpty()) tasks.remove(owner); }
                try { action.run(); } catch (Throwable t) { plugin.getLogger().log(Level.WARNING, "Delayed effect error", t); }
            }
        };
        BukkitTask bt = r.runTaskLater(plugin.java(), Math.max(0, delay));
        tasks.computeIfAbsent(owner, k -> new HashSet<>()).add(bt.getTaskId());
        return bt.getTaskId();
    }

    public <T extends Entity> T track(UUID owner, T e) {
        if (e != null) entities.computeIfAbsent(owner, k -> new HashSet<>()).add(e);
        return e;
    }

    public void release(UUID owner, Entity e) {
        if (e == null) return;
        Set<Entity> s = entities.get(owner);
        if (s != null) { s.remove(e); if (s.isEmpty()) entities.remove(owner); }
        if (e.isValid()) e.remove();
    }

    public int liveEntities() {
        int n = 0;
        for (Iterator<Set<Entity>> it = entities.values().iterator(); it.hasNext(); ) {
            Set<Entity> s = it.next();
            s.removeIf(e -> !e.isValid());
            n += s.size();
            if (s.isEmpty()) it.remove();
        }
        return n;
    }

    public void cleanup(UUID owner) {
        Set<Integer> ids = tasks.remove(owner);
        if (ids != null) for (int id : ids) Bukkit.getScheduler().cancelTask(id);
        Set<Entity> es = entities.remove(owner);
        if (es != null) for (Entity e : es) if (e.isValid()) e.remove();
    }

    public void cleanupAll() {
        for (UUID id : new HashSet<>(tasks.keySet())) cleanup(id);
        for (UUID id : new HashSet<>(entities.keySet())) cleanup(id);
    }
}

package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** ABILITY 5 - two translucent emerald afterimages (display entities) that dash and phantom-slash from other angles, and echo ERROR's abilities. */
public final class FalseReality extends AbilityBase {
    private static final class Phantom { ItemDisplay body, scythe; Location pos; }
    private static final class Active { final List<Phantom> list = new ArrayList<>(); long lastEcho; CastContext ctx; int endTick; }
    private final Map<UUID, Active> active = new HashMap<>();

    public FalseReality(NullRequiemPlugin plugin) { super(plugin, AbilityType.FALSE_REALITY); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        if (active.containsKey(id)) return false;
        ctx.maxHitsPerTarget = cfgI("max-hits-per-target", 4);
        final int count = Math.max(1, Math.min(4, cfgI("clones", 2)));
        final int dur = cfgI("duration-ticks", 100);
        final Active act = new Active();
        act.ctx = ctx;
        Vector fwd = p.getLocation().getDirection().setY(0).normalize();
        Vector right = fwd.clone().crossProduct(new Vector(0, 1, 0)).normalize();
        for (int i = 0; i < count; i++) {
            Phantom ph = new Phantom();
            double side = (i % 2 == 0 ? 1 : -1) * (2.6 + (i / 2) * 1.5);
            ph.pos = p.getLocation().add(right.clone().multiply(side)).subtract(fwd.clone().multiply(0.8));
            Location at = ph.pos.clone().add(0, 1.0, 0);
            Quaternionf q = Vfx.yaw(Math.atan2(-fwd.getX(), -fwd.getZ()) + Math.PI);
            ph.body = vfx().display(id, at, i % 2 == 0 ? "phantom_a" : "phantom_b", new Vector3f(0.95f, 0.95f, 0.95f), q, true, 3);
            ph.scythe = vfx().display(id, at.clone().add(right.clone().multiply(side > 0 ? 0.8 : -0.8)), "nullrequiem", new Vector3f(1.0f, 1.0f, 1.0f), new Quaternionf().rotateZ(side > 0 ? -0.35f : 0.35f), false, 3);
            act.list.add(ph);
            vfx().glitch(vfx().at(at), at);
        }
        active.put(id, act);
        p.swingMainHand();
        sfx().play(p.getLocation(), Snd.A5_CLONE, 1.1f, 1.0f);
        tasks().timer(id, 1, 1, dur, t -> {
            if (!alive(p)) return false;
            Vfx.Audience a = vfx().at(p.getLocation());
            for (int i = 0; i < act.list.size(); i++) {
                Phantom ph = act.list.get(i);
                Location l = ph.pos.clone().add(0, 1.0, 0);
                if (t % 3 == 0) { a.dust(l.clone().add(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5), 2, 0.2, Vfx.NEON, 0.9f); }
                if (t % 9 == i * 3) vfx().glitch(a, l);
                // scripted phantom slashes
                int phase = t - i * 6;
                if (phase == 14 || phase == 40 || phase == 66) phantomSlash(ctx, ph, i, 5.0);
            }
            return true;
        }, () -> clear(p, true));
        return true;
    }

    private void phantomSlash(CastContext ctx, Phantom ph, int index, double dmg) {
        Player p = ctx.player;
        LivingEntity tgt = null; double best = Double.MAX_VALUE;
        for (LivingEntity e : enemies(p, ph.pos, 14)) {
            double d = e.getLocation().distanceSquared(ph.pos);
            if (d < best) { best = d; tgt = e; }
        }
        Vector dir;
        if (tgt != null) {
            dir = tgt.getLocation().add(0, tgt.getHeight() / 2, 0).toVector().subtract(ph.pos.clone().add(0, 1.2, 0).toVector());
            Location dash = tgt.getLocation().clone().subtract(dir.clone().setY(0).normalize().multiply(2.8));
            if (dash.getBlock().isPassable() && dash.clone().add(0, 1, 0).getBlock().isPassable()) ph.pos = dash;
        } else dir = p.getLocation().getDirection();
        dir.normalize();
        Location at = ph.pos.clone().add(0, 1.0, 0);
        if (ph.body != null && ph.body.isValid()) ph.body.teleport(at);
        if (ph.scythe != null && ph.scythe.isValid()) ph.scythe.teleport(at.clone().add(dir.clone().multiply(0.8)));
        vfx().glitch(vfx().at(at), at);
        sfx().play(at, Snd.A5_SLASH, 0.9f, 1.0f + index * 0.15f);
        fireSlash(ctx, at.clone().add(0, 0.3, 0).add(dir.clone().multiply(0.8)), dir, 7.0, 1.2, 1.7, 2, dmg, 2.6f, index % 2 == 1, false, Snd.A1_HIT, null);
    }

    /** Called by AbilityManager after ERROR casts something else: the phantoms imitate it with a smaller slash. */
    public void echo(Player p, AbilityType cast) {
        Active act = active.get(p.getUniqueId());
        if (act == null) return;
        long now = System.currentTimeMillis();
        if (now - act.lastEcho < 1500) return;
        act.lastEcho = now;
        final Vector dir = p.getEyeLocation().getDirection();
        for (int i = 0; i < act.list.size(); i++) {
            final Phantom ph = act.list.get(i);
            tasks().later(p.getUniqueId(), 4 + i * 3, () -> {
                if (!alive(p) || !active.containsKey(p.getUniqueId())) return;
                Location at = ph.pos.clone().add(0, 1.2, 0);
                sfx().play(at, Snd.A5_SLASH, 0.8f, 0.8f);
                fireSlash(act.ctx, at, dir, 9.0, 1.3, 1.5, 1, cfg("echo-damage", 3), 2.0f, false, false, Snd.A1_HIT, null);
            });
        }
    }

    public void clear(Player p, boolean fx) {
        Active act = active.remove(p.getUniqueId());
        if (act == null) return;
        for (Phantom ph : act.list) {
            if (fx && ph.pos != null) vfx().glitch(vfx().at(ph.pos), ph.pos.clone().add(0, 1, 0));
            tasks().release(p.getUniqueId(), ph.body);
            tasks().release(p.getUniqueId(), ph.scythe);
        }
    }

    @Override public void onAbort(Player p) { clear(p, false); }
}

package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** 12 - a gigantic crimson spectral dragon (custom display-entity model) circles Rik, dives on the aimed point and detonates. */
final class DragonAscension extends AkaiBase {
    DragonAscension(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.DRAGON_ASCENSION); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        ctx.maxHits = 2;
        final Vector fwd = Locs.flat(p.getLocation().getDirection());
        final Location start = p.getLocation().add(fwd.clone().multiply(-5)).add(0, 3.5, 0);
        final float scale = (float) cfg("scale", 3.0);
        final AkaiDragon dragon = new AkaiDragon(plugin, id, start, fwd, cfgI("segments", 14), scale);
        final int circle = cfgI("circle-ticks", 40);
        snd(p.getLocation(), "a12_summon", 1.8f, 1.0f);
        p.swingMainHand();
        final Location[] target = new Location[1];
        final int[] diveTicks = {0};
        final Location pos = start.clone();
        final double speed = cfg("dive-speed", 1.8);
        final Set<UUID> hit = new HashSet<>();
        plugin.tasks().timer(id, 1, 1, circle + 60, t -> {
            if (!alive(p) || !dragon.valid()) return false;
            Vfx.Audience a = vfx().at(pos);
            if (t < circle) {
                double ang = t * 0.19 + Math.PI;
                Location c = p.getLocation();
                double rad = 6.5, h = 4.5 + Math.sin(t * 0.12) * 1.2;
                pos.setX(c.getX() + Math.cos(ang) * rad); pos.setZ(c.getZ() + Math.sin(ang) * rad); pos.setY(c.getY() + h);
                if (t == circle / 2) snd(pos, "a12_roar", 2.0f, 1.0f);
            } else {
                if (target[0] == null) {
                    target[0] = aimPoint(p, cfg("range", 30));
                    diveTicks[0] = Math.max(6, (int) (pos.distance(target[0]) / speed));
                    snd(pos, "a12_dive", 2.0f, 1.0f);
                }
                Vector to = target[0].toVector().subtract(pos.toVector());
                double d = to.length();
                if (d <= speed * 1.2) { return false; }
                pos.add(to.normalize().multiply(speed));
                for (LivingEntity e : enemies(p, pos, 3.6)) if (hit.add(e.getUniqueId()) && ctx.hit(e, cfg("dive-damage", 6), false)) AkaiFx.hitBurst(plugin, e.getLocation().add(0, 1, 0), false);
                if (t % 2 == 0) vfx().ring(a, Locs.ground(pos), 3.0, 16, t, AkaiFx.BLOOD, 1.2f);
            }
            dragon.move(pos);
            a.dust(pos, 6, 1.2, AkaiFx.CRIM, 1.4f);
            if (t % 3 == 0) AkaiFx.lightning(plugin, a, pos.clone().add(0, 2, 0), pos.clone().subtract(0, 2, 0));
            return t < circle + diveTicks[0] + 20;
        }, () -> {
            Location end = target[0] != null ? target[0] : pos.clone();
            snd(end, "a12_explode", 2.2f, 1.0f);
            AkaiFx.sphereBurst(plugin, end, 4.5);
            shockRing(id, Locs.ground(end), cfg("explosion-radius", 7), 10);
            AkaiFx.embers(plugin, end, 60, 3.0);
            if (alive(p)) for (LivingEntity e : enemies(p, end, cfg("explosion-radius", 7))) {
                if (ctx.hit(e, cfg("explosion-damage", 18), true)) {
                    Vector out = e.getLocation().toVector().subtract(end.toVector()).setY(0);
                    if (out.lengthSquared() > 1e-4) plugin.damage().push(p, e, out.normalize().multiply(1.3).setY(0.55), ctx.castId);
                }
            }
            dragon.dissolve(true);
        });
        return true;
    }
}

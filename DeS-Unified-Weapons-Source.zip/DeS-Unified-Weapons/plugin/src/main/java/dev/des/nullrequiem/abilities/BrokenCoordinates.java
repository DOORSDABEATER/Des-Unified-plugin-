package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** ABILITY 3 - corrupted zone: enemies slowed and periodically disrupted, ERROR faster inside. */
public final class BrokenCoordinates extends AbilityBase {
    public BrokenCoordinates(NullRequiemPlugin plugin) { super(plugin, AbilityType.BROKEN_COORDINATES); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        final Location c = Locs.ground(p.getLocation());
        final double r = cfg("radius", 6.0);
        final int dur = cfgI("duration-ticks", 160);
        final int slowAmp = cfgI("slow-amplifier", 1);
        final int speedAmp = cfgI("owner-speed-amplifier", 1);
        sfx().play(c, Snd.A3_ZONE, 1.1f, 1.0f);
        p.swingMainHand();
        shockRing(id, c, r, 8, true);
        final List<ItemDisplay> shards = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            ItemDisplay d = vfx().display(id, c.clone().add(0, 1.2, 0), "shard", new Vector3f(1.7f, 1.7f, 1.7f), new Quaternionf().rotateZ(0.3f * i), false, 3);
            if (d != null) shards.add(d);
        }
        tasks().timer(id, 2, 2, dur / 2, t -> {
            if (!alive(p)) return false;
            Vfx.Audience a = vfx().at(c);
            double ph = t * 0.15;
            vfx().ring(a, c.clone().add(0, 0.12, 0), r, 28, ph, Vfx.NEON, 1.1f);
            vfx().ring(a, c.clone().add(0, 0.12, 0), r * 0.55, 16, -ph, Vfx.DEEP, 1.0f);
            for (int i = 0; i < 3; i++) {
                double ang = Math.random() * Math.PI * 2, rad = Math.sqrt(Math.random()) * r;
                Location bl = c.clone().add(Math.cos(ang) * rad, 0.2, Math.sin(ang) * rad);
                a.block(bl, 2, 0.15, Math.random() < 0.5 ? Material.EMERALD_BLOCK : Material.BLACK_CONCRETE);
            }
            if (t % 6 == 0) vfx().glitch(a, c.clone().add((Math.random() - 0.5) * r, 0.3, (Math.random() - 0.5) * r));
            for (int i = 0; i < shards.size(); i++) {
                ItemDisplay d = shards.get(i);
                if (!d.isValid()) continue;
                double ang = ph * 0.7 + i * Math.PI * 2 / shards.size();
                d.teleport(c.clone().add(Math.cos(ang) * r * 0.6, 1.2 + Math.sin(ph * 2 + i) * 0.5, Math.sin(ang) * r * 0.6));
            }
            for (LivingEntity e : enemies(p, c, r)) {
                dmg().root(p, e, 30, slowAmp, ctx.castId);
                if (t % 15 == 0) { // periodic disruption
                    dmg().push(p, e, new Vector(Math.random() - 0.5, 0.12, Math.random() - 0.5).normalize().multiply(0.4), ctx.castId);
                    e.setRotation(e.getLocation().getYaw() + (float) (Math.random() * 50 - 25), e.getLocation().getPitch());
                    vfx().glitch(vfx().at(e.getLocation()), e.getLocation());
                    sfx().play(e.getLocation(), Snd.A3_TICK, 0.7f, 1.0f);
                }
            }
            if (p.getWorld() == c.getWorld() && p.getLocation().distanceSquared(c) <= r * r)
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 30, speedAmp, false, false, true));
            return true;
        }, () -> { for (ItemDisplay d : shards) tasks().release(id, d); vfx().glitch(vfx().at(c), c); });
        return true;
    }
}

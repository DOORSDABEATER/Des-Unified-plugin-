package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** ABILITY 12 - hold right-click to charge (up to max-charge-ticks); release (or press swap-hand) fires a giant slash whose damage scales with charge. */
public final class FinalVariable extends AbilityBase {
    private static final class Charge {
        CastContext ctx; long start; long lastHold; ItemDisplay[] shards; int ticks; boolean released;
    }
    private final Map<UUID, Charge> charging = new HashMap<>();

    public FinalVariable(NullRequiemPlugin plugin) { super(plugin, AbilityType.FINAL_VARIABLE); }

    @Override public boolean selfManagedCooldown() { return true; }
    @Override public boolean canRecast(Player p) { return charging.containsKey(p.getUniqueId()); }
    public boolean isCharging(Player p) { return charging.containsKey(p.getUniqueId()); }

    public void hold(Player p) {
        Charge c = charging.get(p.getUniqueId());
        if (c != null) c.lastHold = System.currentTimeMillis();
    }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        if (charging.containsKey(id)) { release(p); return true; }
        final int maxT = cfgI("max-charge-ticks", 60), minT = cfgI("min-charge-ticks", 8);
        final long holdTimeout = plugin.settings().i("controls.hold-release-timeout-ticks", 8) * 50L;
        final Charge ch = new Charge();
        ch.ctx = ctx; ch.start = System.currentTimeMillis(); ch.lastHold = ch.start;
        ch.shards = new ItemDisplay[6];
        ctx.state.busy = true;
        charging.put(id, ch);
        for (int i = 0; i < ch.shards.length; i++)
            ch.shards[i] = vfx().display(id, p.getLocation().add(0, 1.5, 0), "shard", new Vector3f(1.7f, 1.7f, 1.7f), new Quaternionf(), true, 2);
        sfx().play(p.getLocation(), Snd.A12_CHARGE, 1.3f, 1.0f);
        p.swingMainHand();
        tasks().timer(id, 0, 1, maxT + 12, t -> {
            if (!alive(p) || ch.released) return false;
            ch.ticks = t;
            double f = Math.min(1.0, t / (double) maxT);
            Location c = p.getLocation();
            Vfx.Audience a = vfx().at(c);
            Location mid = c.clone().add(0, 1.5, 0);
            for (int i = 0; i < ch.shards.length; i++) {
                double ang = t * (0.2 + 0.25 * f) + i * Math.PI * 2 / ch.shards.length;
                double r = 1.5 + f * 1.3;
                Location sp = mid.clone().add(Math.cos(ang) * r, Math.sin(t * 0.15 + i) * 0.5, Math.sin(ang) * r);
                if (ch.shards[i] != null && ch.shards[i].isValid()) ch.shards[i].teleport(sp);
                if (t % 2 == 0) a.dust(sp, 1, 0.05, Vfx.NEON, 1.0f);
            }
            vfx().ring(a, c.clone().add(0, 0.12, 0), 1.5 + f * 4.5, 20 + (int) (f * 20), t * 0.2, Vfx.NEON, 1.2f);
            for (int k = 0; k < 2 + (int) (f * 4); k++) {
                double ang = Math.random() * Math.PI * 2, rad = Math.random() * (2 + f * 5);
                a.block(c.clone().add(Math.cos(ang) * rad, 0.15, Math.sin(ang) * rad), 1, 0.1, Math.random() < 0.5 ? Material.BLACK_CONCRETE : Material.EMERALD_BLOCK);
            }
            if (t % 5 == 0) vfx().glitch(a, mid);
            Vector dir = p.getLocation().getDirection();
            a.trans(mid.clone().add(dir.clone().multiply(0.8)).add(0, 0.8, 0), 2 + (int) (f * 5), 0.4, Vfx.NEON, Vfx.DEEP, 1.2f);
            if (t % 10 == 0) p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 14, 2, false, false, false));
            if (t % 20 == 0 && t > 0) sfx().play(c, Snd.A12_CHARGE, 0.4f, 1.0f + (float) f * 0.6f);
            boolean timedOut = System.currentTimeMillis() - ch.lastHold > holdTimeout;
            if (t >= maxT || (t >= minT && timedOut)) { release(p); return false; }
            return true;
        }, () -> { if (charging.get(id) == ch) cleanup(p, ch, true); });
        return true;
    }

    private void release(Player p) {
        final UUID id = p.getUniqueId();
        Charge ch = charging.get(id);
        if (ch == null || ch.released) return;
        ch.released = true;
        double f = Math.min(1.0, ch.ticks / (double) Math.max(1, cfgI("max-charge-ticks", 60)));
        double dmg = cfg("min-damage", 8) + (cfg("max-damage", 26) - cfg("min-damage", 8)) * f;
        double radius = 1.8 + 1.4 * f;
        float scale = (float) (3.2 + 3.3 * f);
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().clone();
        Location start = eye.clone().add(dir.clone().multiply(1.5)).subtract(0, 0.3, 0);
        sfx().play(p.getLocation(), Snd.A12_RELEASE, 1.5f, 1.2f - (float) f * 0.3f);
        p.swingMainHand();
        vfx().sphereBurst(start, 1.0 + f);
        cleanup(p, ch, false);
        fireSlash(ch.ctx, start, dir, cfg("range", 24), cfg("speed", 1.4), radius, 0, dmg, scale, false, true, Snd.A1_HIT,
            end -> tear(id, end.clone().subtract(dir.clone().multiply(0.6)), dir, 3.5f, 50));
        plugin.cooldowns().setSeconds(p, type, plugin.settings().cooldownSeconds(type));
        p.sendActionBar(plugin.settings().raw("<dark_green>[NULL//REQUIEM] <green><bold>FINAL VARIABLE</bold> <gray>released at <white>" + (int) (f * 100) + "%"));
    }

    private void cleanup(Player p, Charge ch, boolean burst) {
        charging.remove(p.getUniqueId());
        plugin.states().get(p).busy = false;
        for (ItemDisplay d : ch.shards) tasks().release(p.getUniqueId(), d);
        p.removePotionEffect(PotionEffectType.SLOWNESS);
        if (burst) vfx().glitch(vfx().at(p.getLocation()), p.getLocation());
    }

    @Override
    public void onAbort(Player p) {
        Charge ch = charging.remove(p.getUniqueId());
        if (ch != null) { ch.released = true; for (ItemDisplay d : ch.shards) tasks().release(p.getUniqueId(), d); }
    }
}

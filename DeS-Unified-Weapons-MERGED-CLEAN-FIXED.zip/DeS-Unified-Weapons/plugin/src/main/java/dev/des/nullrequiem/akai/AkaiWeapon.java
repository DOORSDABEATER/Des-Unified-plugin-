package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * AKAI NO O identity: PDC marker + owner UUID + registered serial. Name/lore are never trusted, so a renamed sword cannot
 * impersonate it, and copies/duplicates (serial not registered or seen twice) are rejected. Binding survives restarts
 * (the data lives in the item and in akai-serials.yml).
 */
public final class AkaiWeapon {
    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    private final NamespacedKey kWeapon, kOwner, kSerial;
    private final Set<String> serials = new HashSet<>();
    private final File serialFile;

    public AkaiWeapon(NullRequiemPlugin plugin, AkaiModule m) {
        this.plugin = plugin; this.m = m;
        kWeapon = new NamespacedKey(plugin.java(), "akai_weapon"); kOwner = new NamespacedKey(plugin.java(), "akai_owner"); kSerial = new NamespacedKey(plugin.java(), "akai_serial");
        serialFile = new File(plugin.getDataFolder(), "akai-serials.yml");
        if (serialFile.exists()) serials.addAll(YamlConfiguration.loadConfiguration(serialFile).getStringList("serials"));
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration(); y.set("serials", new ArrayList<>(serials));
        try { y.save(serialFile); } catch (IOException e) { plugin.getLogger().warning("akai-serials.yml: " + e.getMessage()); }
    }

    public ItemStack create(UUID owner) {
        AkaiSettings s = m.settings();
        Material mat = Material.matchMaterial(s.s("weapon.base-material", "NETHERITE_SWORD"));
        if (mat == null) mat = Material.NETHERITE_SWORD;
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(s.mm(s.s("weapon.display-name", "<gradient:#e11d2e:#7a0010><bold>AKAI NO \u014c</bold></gradient>")));
        List<Component> lore = new ArrayList<>();
        for (String l : s.list("weapon.lore")) lore.add(s.mm(l.replace("{owner}", s.s("owner.name", "RIK"))));
        meta.lore(lore);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES);
        meta.setEnchantmentGlintOverride(true);
        NamespacedKey model = NamespacedKey.fromString(s.s("weapon.item-model", "akai:katana"));
        if (model != null) meta.setItemModel(model);
        meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(new NamespacedKey(plugin.java(), "akai_atk"), s.d("weapon.attack-damage-modifier", 9.0), AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        meta.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(new NamespacedKey(plugin.java(), "akai_spd"), s.d("weapon.attack-speed-modifier", -2.2), AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String serial = UUID.randomUUID().toString();
        pdc.set(kWeapon, PersistentDataType.BYTE, (byte) 1);
        if (owner != null) pdc.set(kOwner, PersistentDataType.STRING, owner.toString());
        pdc.set(kSerial, PersistentDataType.STRING, serial);
        it.setItemMeta(meta);
        serials.add(serial); save();
        return it;
    }

    public boolean hasMarker(ItemStack it) { return it != null && it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(kWeapon, PersistentDataType.BYTE); }

    public String serialOf(ItemStack it) { return hasMarker(it) ? it.getItemMeta().getPersistentDataContainer().get(kSerial, PersistentDataType.STRING) : null; }

    public boolean isGenuine(ItemStack it) {
        if (!hasMarker(it)) return false;
        String s = serialOf(it);
        return s != null && serials.contains(s);
    }

    public UUID ownerOf(ItemStack it) {
        if (!hasMarker(it)) return null;
        try { String o = it.getItemMeta().getPersistentDataContainer().get(kOwner, PersistentDataType.STRING); return o == null ? null : UUID.fromString(o); }
        catch (IllegalArgumentException e) { return null; }
    }

    /** Is this player the configured owner (UUID based)? */
    public boolean isOwner(Player p) {
        UUID cfg = m.settings().ownerUuid();
        return cfg != null && cfg.equals(p.getUniqueId());
    }

    /** Full use: genuine item, configured owner UUID == player == item owner. Admin override only with akai.override. */
    public boolean canUse(Player p, ItemStack it) {
        if (!isGenuine(it) || !p.hasPermission("akai.use")) return false;
        if (p.hasPermission("akai.override") && m.settings().b("owner.override-enabled", false)) return true;
        UUID io = ownerOf(it);
        return isOwner(p) && io != null && io.equals(p.getUniqueId());
    }

    public boolean holdsUsable(Player p) { return canUse(p, p.getInventory().getItemInMainHand()); }

    public int removeAll(Player p) {
        int n = 0; PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) { ItemStack it = inv.getItem(i); if (hasMarker(it)) { serials.remove(serialOf(it)); inv.setItem(i, null); n++; } }
        for (int i = 0; i < p.getEnderChest().getSize(); i++) { ItemStack it = p.getEnderChest().getItem(i); if (hasMarker(it)) { serials.remove(serialOf(it)); p.getEnderChest().setItem(i, null); n++; } }
        if (n > 0) save();
        return n;
    }

    /** Removes duplicated serials, unregistered fakes and (when enabled) copies held by anyone who is not the owner. */
    public void sanitize(Player p) {
        Set<String> seen = new HashSet<>();
        PlayerInventory inv = p.getInventory();
        boolean confiscate = m.settings().b("owner.confiscate-from-non-owners", true);
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (!hasMarker(it)) continue;
            String s = serialOf(it);
            boolean fake = s == null || !serials.contains(s);
            boolean dupe = s != null && !seen.add(s);
            boolean stolen = confiscate && !isOwner(p) && !p.hasPermission("akai.admin");
            if (fake || dupe || stolen) {
                inv.setItem(i, null);
                plugin.getLogger().warning("Removed AKAI NO O item from " + p.getName() + (fake ? " (unregistered)" : dupe ? " (duplicate)" : " (not the owner)"));
            }
        }
    }
}

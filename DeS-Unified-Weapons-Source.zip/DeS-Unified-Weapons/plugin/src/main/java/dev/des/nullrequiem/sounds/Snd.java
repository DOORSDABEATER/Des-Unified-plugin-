package dev.des.nullrequiem.sounds;

/** Sound event ids; each maps to assets/nullrequiem/sounds/<id>.ogg through sounds.json. */
public final class Snd {
    private Snd() { }
    public static final String DRAW = "draw", IDLE = "idle", ATTACK_LIGHT = "attack_light", ATTACK_HEAVY = "attack_heavy",
        CRIT = "crit", KILL = "kill", FRACTURE = "fracture_apply", EXPOSED = "exposed", MASTERY = "mastery", DENY = "deny",
        A1_CAST = "a1_cast", A1_HIT = "a1_hit", A2_TELEPORT = "a2_teleport", A2_IMPACT = "a2_impact",
        A3_ZONE = "a3_zone", A3_TICK = "a3_tick", A4_SLAM = "a4_slam", A4_PULSE = "a4_pulse", A4_SHOCK = "a4_shock",
        A5_CLONE = "a5_clone", A5_SLASH = "a5_slash", A6_SLAM = "a6_slam", A6_ERUPT = "a6_erupt", A6_FINAL = "a6_final",
        A7_MARK = "a7_mark", A7_CHAIN = "a7_chain", A8_SUMMON = "a8_summon", A8_LAUNCH = "a8_launch", A8_FINAL = "a8_final",
        A9_DESYNC = "a9_desync", A9_COUNTER = "a9_counter", A10_SEAL = "a10_seal", A10_DETONATE = "a10_detonate",
        A11_OPEN = "a11_open", A11_PULL = "a11_pull", A11_COLLAPSE = "a11_collapse", A12_CHARGE = "a12_charge", A12_RELEASE = "a12_release",
        U_ACTIVATE = "u_activate", U_CIRCLE = "u_circle", U_CAPTURE = "u_capture", U_CHARGE = "u_charge", U_RIFT = "u_rift",
        U_SWING = "u_swing", U_EXPLODE = "u_explode", U_404 = "u_404";
}

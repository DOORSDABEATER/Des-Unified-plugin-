package com.des.legendary;

import org.bukkit.Color;

/** Colour palettes shared by the VFX code. */
public final class Pal {
    private Pal() {}
    public static final Color PURPLE = Color.fromRGB(150, 60, 240), VIOLET = Color.fromRGB(205, 150, 255),
            DEEP = Color.fromRGB(80, 20, 160), WHITE = Color.fromRGB(255, 255, 255), MAGENTA = Color.fromRGB(235, 90, 255),
            GOLD = Color.fromRGB(255, 220, 120), CYAN = Color.fromRGB(90, 225, 255), EMBER = Color.fromRGB(255, 90, 70);

    /** h in [0,1) -> fully saturated rainbow colour. */
    public static Color rainbow(double h) {
        h = h - Math.floor(h);
        double x = h * 6, f = x - Math.floor(x); int i = (int) x % 6;
        double q = 1 - f, t = f; double r, g, b;
        switch (i) { case 0 -> { r = 1; g = t; b = 0; } case 1 -> { r = q; g = 1; b = 0; } case 2 -> { r = 0; g = 1; b = t; }
            case 3 -> { r = 0; g = q; b = 1; } case 4 -> { r = t; g = 0; b = 1; } default -> { r = 1; g = 0; b = q; } }
        return Color.fromRGB((int) (60 + 195 * r), (int) (60 + 195 * g), (int) (60 + 195 * b));
    }
}

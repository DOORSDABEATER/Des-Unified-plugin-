package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.combat.DamageService;
import dev.des.nullrequiem.sounds.SoundManager;
import dev.des.nullrequiem.util.TaskTracker;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import org.bukkit.entity.ItemDisplay;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public abstract class AbilityBase implements Ability {
    protected final NullRequiemPlugin plugin;
    protected final AbilityType type;

    protected AbilityBase(NullRequiemPlugin plugin, AbilityType type) { this.plugin = plugin; this.type = type; }

    @Override public AbilityType type() { return type; }

    protected double cfg(String key, double def) { return plugin.settings().ab(type, key, def); }
    protected int cfgI(String key, int def) { return (int) Math.round(plugin.settings().ab(type, key, def)); }
    protected Vfx vfx() { return plugin.vfx(); }
    protected SoundManager sfx() { return plugin.sfx(); }
    protected DamageService dmg() { return plugin.damage(); }
    protected TaskTracker tasks() { return plugin.tasks(); }

    protected List<LivingEntity> enemies(Player p, Location c, double r) { return dmg().enemies(p, c, r); }

    /** Enemy closest to the crosshair inside range; prefers exposed targets when preferExposed. */
    protected LivingEntity aimTarget(Player p, double range, double coneDegrees, boolean preferExposed) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        double minDot = Math.cos(Math.toRadians(coneDegrees));
        LivingEntity best = null; double bestScore = -1;
        for (LivingEntity e : enemies(p, eye, range)) {
            Vector to = e.getLocation().add(0, e.getHeight() / 2, 0).toVector().subtract(eye.toVector());
            double dist = to.length();
            if (dist < 0.1 || dist > range) continue;
            double dot = to.clone().normalize().dot(dir);
            if (dot < minDot) continue;
            if (!p.hasLineOfSight(e)) continue;
            double score = dot - dist / (range * 4.0) + (preferExposed && plugin.fracture().isExposed(e) ? 1.0 : 0.0);
            if (score > bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    /** Where the player is aiming (block hit or max range). */
    protected Location aimPoint(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
        if (r == null) return eye.clone().add(eye.getDirection().multiply(range));
        Location hit = r.getHitPosition().toLocation(p.getWorld());
        if (r.getHitBlockFace() != null) hit.add(r.getHitBlockFace().getDirection().multiply(0.4));
        return hit;
    }

    protected boolean alive(Player p) { return p.isOnline() && !p.isDead(); }

    protected void actionbar(Player p, String mm) {
        p.sendActionBar(plugin.settings().raw(mm));
        plugin.states().get(p).msgUntil = System.currentTimeMillis() + 1500;
    }

    /**
     * Shared slash projectile (3D crescent display + particles). Moves speed blocks/tick up to range, stops on solid blocks,
     * damages each enemy once, ends after pierce hits (pierce<=0 = unlimited). dmg<=0 makes it purely visual.
     */
    protected void fireSlash(CastContext ctx, Location start, Vector dirIn, double range, double speed, double radius, int pierce,
                             double dmg, float scale, boolean vertical, boolean exposedBonus, String hitSound, Consumer<Location> onEnd) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        final Vector dir = dirIn.clone().normalize();
        final Location pos = start.clone();
        Vector right = dir.clone().crossProduct(new Vector(0, 1, 0));
        if (right.lengthSquared() < 1e-6) right = new Vector(1, 0, 0);
        right.normalize();
        Quaternionf q = Vfx.orient(dir, vertical ? right : new Vector(0, 1, 0));
        final ItemDisplay disp = vfx().display(id, pos, "slash", new Vector3f(scale, scale, scale), q, true, 1);
        final Set<UUID> hit = new HashSet<>();
        final int[] n = {0};
        final double[] trav = {0};
        final int maxTicks = (int) Math.ceil(range / speed) + 2;
        tasks().timer(id, 1, 1, maxTicks, tick -> {
            if (!alive(p)) return false;
            pos.add(dir.clone().multiply(speed));
            trav[0] += speed;
            if (!pos.getBlock().isPassable()) return false;
            if (disp != null && disp.isValid()) disp.teleport(pos);
            Vfx.Audience a = vfx().at(pos);
            if (disp == null || tick % 2 == 0) vfx().arcCrescent(a, pos, dir, scale * 0.8, vertical, Vfx.NEON, 1.1f);
            a.dust(pos.clone().subtract(dir.clone().multiply(0.7)), 3, 0.25, Vfx.EMERALD, 1.0f);
            a.ink(pos, 1, 0.2);
            if (dmg > 0) {
                for (LivingEntity e : enemies(p, pos, radius)) {
                    if (!hit.add(e.getUniqueId())) continue;
                    if (ctx.hit(e, dmg, exposedBonus)) {
                        Location el = e.getLocation().add(0, e.getHeight() / 2, 0);
                        vfx().hitBurst(el, plugin.fracture().isExposed(e));
                        if (hitSound != null) sfx().play(el, hitSound, 0.9f, 1.0f);
                        n[0]++;
                        if (pierce > 0 && n[0] >= pierce) return false;
                    }
                }
            }
            return trav[0] < range;
        }, () -> {
            if (disp != null) tasks().release(id, disp);
            if (onEnd != null) onEnd.accept(pos.clone());
        });
    }

    /** Temporary emerald dimensional tear (rift display + particles). Purely visual, bounded lifetime. */
    protected void tear(UUID owner, Location loc, Vector facing, float scale, int ticks) {
        Quaternionf q = Vfx.orient(new Vector(0, 1, 0), facing.clone().setY(0).lengthSquared() < 1e-6 ? new Vector(0, 0, 1) : facing.clone().setY(0));
        ItemDisplay d = vfx().display(owner, loc.clone().add(0, scale * 0.45, 0), "rift", new Vector3f(scale, scale, scale), q, false, 0);
        tasks().timer(owner, 0, 4, ticks / 4 + 1, t -> {
            Vfx.Audience a = vfx().at(loc);
            vfx().glitch(a, loc.clone().add(0, 0.6, 0));
            a.dust(loc.clone().add((Math.random() - 0.5) * 0.6, Math.random() * scale * 0.9, (Math.random() - 0.5) * 0.6), 3, 0.1, Vfx.NEON, 1.0f);
            a.ink(loc.clone().add(0, scale * 0.4, 0), 1, 0.3);
            return d == null || d.isValid();
        }, () -> { if (d != null) tasks().release(owner, d); });
    }

    /** Expanding ground shock ring (display) + particle ring over ticks. */
    protected void shockRing(UUID owner, Location center, double radius, int ticks, boolean particles) {
        float target = (float) (radius * 2.13);
        ItemDisplay d = vfx().display(owner, center.clone().add(0, 0.12, 0), "ring", new Vector3f(0.5f, 1f, 0.5f), new Quaternionf(), false, 0);
        if (d != null) tasks().later(owner, 1, () -> vfx().animate(d, new Vector3f(target, 1f, target), new Quaternionf(), ticks));
        tasks().timer(owner, 0, 1, ticks + 3, t -> {
            if (particles) {
                double r = radius * Math.min(1.0, (t + 1.0) / ticks);
                Vfx.Audience a = vfx().at(center);
                vfx().ring(a, center.clone().add(0, 0.15, 0), r, Math.max(10, (int) (r * 5)), t * 0.3, Vfx.NEON, 1.2f);
                if (t % 2 == 0) vfx().ring(a, center.clone().add(0, 0.25, 0), r * 0.82, Math.max(8, (int) (r * 3)), -t * 0.2, Vfx.VOID, 1.3f);
            }
            return t < ticks;
        }, () -> { if (d != null) tasks().release(owner, d); });
    }
}

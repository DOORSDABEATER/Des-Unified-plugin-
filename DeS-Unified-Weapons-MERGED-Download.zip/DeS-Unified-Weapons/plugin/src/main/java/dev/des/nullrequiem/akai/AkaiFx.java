package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

/** Crimson / black / gold effects. Only red-family particles (DUST, CRIMSON_SPORE, BLOCK of red/black/gold) - never green/purple/blue/orange. */
public final class AkaiFx {
    public static final Color CRIM = Color.fromRGB(225, 25, 45), BLOOD = Color.fromRGB(115, 0, 18), BLACK = Color.fromRGB(12, 10, 12),
        GOLD = Color.fromRGB(238, 192, 72), PALE = Color.fromRGB(255, 205, 195);
    private AkaiFx() { }

    public static void sound(NullRequiemPlugin p, Location l, String id, float vol, float pitch) {
        p.sfx().play(l, "akai:" + id, vol * (float) p.akai().settings().d("sounds.master-volume", 1.0), pitch);
    }

    public static void soundTo(NullRequiemPlugin p, Player pl, String id, float vol, float pitch) {
        p.sfx().playTo(pl, "akai:" + id, vol * (float) p.akai().settings().d("sounds.master-volume", 1.0), pitch);
    }

    public static void debris(Vfx.Audience a, Location l, int n) {
        a.block(l, n, 0.5, Material.REDSTONE_BLOCK);
        a.block(l, n / 2, 0.5, Material.BLACK_CONCRETE);
        a.block(l, Math.max(1, n / 4), 0.5, Material.GOLD_BLOCK);
    }

    public static void embers(NullRequiemPlugin p, Location l, int n, double spread) {
        Vfx.Audience a = p.vfx().at(l);
        a.dust(l, n, spread, CRIM, 1.2f);
        a.dust(l, Math.max(1, n / 3), spread, GOLD, 1.0f);
        a.particle(Particle.CRIMSON_SPORE, l, n, spread, spread, spread, 0.02);
        a.ink(l, Math.max(1, n / 4), spread * 0.5);
    }

    public static void hitBurst(NullRequiemPlugin p, Location l, boolean big) {
        Vfx.Audience a = p.vfx().at(l);
        a.dust(l, big ? 22 : 9, 0.35, CRIM, 1.2f);
        a.particle(Particle.CRIMSON_SPORE, l, big ? 10 : 4, 0.3, 0.3, 0.3, 0.02);
        if (big) { a.dust(l, 8, 0.3, GOLD, 1.0f); debris(a, l, 12); a.particle(Particle.DAMAGE_INDICATOR, l, 4, 0.3, 0.3, 0.3, 0.1); }
    }

    public static void lightning(NullRequiemPlugin p, Vfx.Audience a, Location from, Location to) {
        p.vfx().crack(a, from, to, 0.7, CRIM, 1.2f);
        if (ThreadLocalRandom.current().nextInt(3) == 0) p.vfx().crack(a, from, to, 0.5, GOLD, 0.9f);
    }

    public static void cross(NullRequiemPlugin p, Location c, Vector right, double size) {
        Vfx.Audience a = p.vfx().at(c);
        Vector r = right.clone().normalize().multiply(size), u = new Vector(0, size, 0), d1 = r.clone().add(u).multiply(0.72), d2 = r.clone().subtract(u).multiply(0.72);
        p.vfx().line(a, c.clone().subtract(r), c.clone().add(r), 0.3, CRIM, 1.6f);
        p.vfx().line(a, c.clone().subtract(u), c.clone().add(u), 0.3, CRIM, 1.6f);
        p.vfx().line(a, c.clone().subtract(d1), c.clone().add(d1), 0.3, GOLD, 1.2f);
        p.vfx().line(a, c.clone().subtract(d2), c.clone().add(d2), 0.3, GOLD, 1.2f);
        a.dust(c, 14, 0.4, PALE, 1.3f);
    }

    public static void sphereBurst(NullRequiemPlugin p, Location c, double radius) {
        Vfx.Audience a = p.vfx().at(c);
        p.vfx().sphere(a, c, radius, 40, CRIM, 1.6f);
        p.vfx().sphere(a, c, radius * 0.65, 24, PALE, 1.2f);
        p.vfx().sphere(a, c, radius * 1.4, 30, BLOOD, 1.5f);
        a.particle(Particle.CRIMSON_SPORE, c, 18, radius * 0.6, radius * 0.6, radius * 0.6, 0.03);
        a.ink(c, 10, radius * 0.5);
        debris(a, c, 16);
    }

    public static void executionBurst(NullRequiemPlugin p, Location l) {
        Vfx.Audience a = p.vfx().at(l);
        p.vfx().column(a, l.clone().subtract(0, 1, 0), 4.0, 0.6, 10, CRIM, 1.4f);
        embers(p, l, 30, 0.7);
        debris(a, l, 20);
        cross(p, l, new Vector(1, 0, 0), 1.6);
    }

    public static void decreeBurst(NullRequiemPlugin p, LivingEntity t) {
        Location l = t.getLocation().add(0, t.getHeight() / 2, 0);
        Vfx.Audience a = p.vfx().at(l);
        p.vfx().ring(a, t.getLocation().add(0, 0.1, 0), 1.6, 24, 0, CRIM, 1.5f);
        p.vfx().ring(a, t.getLocation().add(0, 0.2, 0), 1.0, 16, 1, GOLD, 1.2f);
        embers(p, l, 24, 0.6);
    }

    public static void markVisual(NullRequiemPlugin p, LivingEntity t, int stacks, int run) {
        Location c = t.getLocation().add(0, t.getHeight() / 2, 0);
        Vfx.Audience a = p.vfx().at(c);
        double h = t.getHeight(), w = Math.max(0.5, t.getWidth()), ph = run * 0.4;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (stacks == 1) a.dust(c.clone().add(r.nextGaussian() * w * 0.4, r.nextGaussian() * h * 0.3, r.nextGaussian() * w * 0.4), 2, 0, CRIM, 0.8f);
        else if (stacks == 2) p.vfx().crack(a, c.clone().add(r.nextDouble(-0.2, 0.2), h * 0.5, 0), c.clone().add(r.nextDouble(-0.3, 0.3), -h * 0.5, 0), 0.5, CRIM, 0.8f);
        else if (stacks == 3) for (int i = 0; i < 3; i++) { double ang = ph + i * 2.094; a.dust(c.clone().add(Math.cos(ang) * w, Math.sin(ph + i) * 0.3, Math.sin(ang) * w), 1, 0, CRIM, 1.0f); }
        else if (stacks == 4) { for (int i = 0; i < 5; i++) { double ang = ph * 1.3 + i * 1.2566; a.dust(c.clone().add(Math.cos(ang) * w * 1.1, Math.sin(ph + i) * h * 0.3, Math.sin(ang) * w * 1.1), 1, 0, i % 2 == 0 ? CRIM : BLACK, 1.1f); } a.particle(Particle.CRIMSON_SPORE, c, 2, w * 0.5, h * 0.3, w * 0.5, 0.01); }
        else {
            p.vfx().ring(a, t.getLocation().add(0, 0.1, 0), w + 0.5, 12, ph, CRIM, 1.2f);
            p.vfx().ring(a, t.getLocation().add(0, h + 0.3, 0), w * 0.8, 8, -ph, GOLD, 1.0f);
            a.particle(Particle.CRIMSON_SPORE, c, 2, w * 0.5, h * 0.4, w * 0.5, 0.01);
            if (run % 6 == 0) debris(a, c, 4);
        }
    }

    public static void drawBurst(NullRequiemPlugin p, Player pl) {
        Location l = pl.getLocation().add(0, 1.0, 0);
        Vfx.Audience a = p.vfx().at(l);
        p.vfx().ring(a, pl.getLocation().add(0, 0.1, 0), 1.5, 16, 0, CRIM, 1.0f);
        a.dust(l, 8, 0.6, GOLD, 1.0f);
        a.particle(Particle.CRIMSON_SPORE, l, 6, 0.6, 0.6, 0.6, 0.02);
    }

    public static void idleAura(NullRequiemPlugin p, Player pl, int stage, int run) {
        Location base = pl.getLocation().add(0, 1.0, 0);
        Vfx.Audience a = p.vfx().at(base);
        double t = run * 0.35;
        Vector dir = pl.getLocation().getDirection().setY(0).normalize();
        Location hand = base.clone().add(dir.clone().multiply(0.5)).add(0, 0.3, 0);
        ThreadLocalRandom r = ThreadLocalRandom.current();
        a.dust(hand.clone().add(r.nextGaussian() * 0.3, r.nextGaussian() * 0.5, r.nextGaussian() * 0.3), 1, 0, CRIM, 0.8f);
        if (stage >= 2) {
            a.dust(hand.clone().add(0, 0.9, 0), 2, 0.5, GOLD, 0.9f);
            p.vfx().ring(a, base.clone().add(0, -0.85, 0), 0.9 + 0.2 * Math.sin(t), 6, t, CRIM, 0.9f);
        }
        if (stage >= 3) {
            for (int i = 0; i < 3; i++) { double ang = t + i * Math.PI * 2 / 3; a.dust(base.clone().add(Math.cos(ang) * 1.3, 0.8 + Math.sin(t * 1.3 + i) * 0.5, Math.sin(ang) * 1.3), 1, 0, GOLD, 1.2f); }
            a.particle(Particle.CRIMSON_SPORE, base, 1, 0.6, 0.8, 0.6, 0.01);
            if (run % 20 == 0) debris(a, base, 4);
        }
    }
}

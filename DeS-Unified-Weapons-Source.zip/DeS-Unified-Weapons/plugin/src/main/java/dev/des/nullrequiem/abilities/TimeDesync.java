package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** ABILITY 9 - short extreme speed burst with delayed afterimages, temporary damage reduction and a one-shot counter-slash. Never invulnerable. */
public final class TimeDesync extends AbilityBase {
    private static final class Win { long until, counterUntil; boolean counterUsed; CastContext ctx; double reduction; }
    private final Map<UUID, Win> map = new HashMap<>();

    public TimeDesync(NullRequiemPlugin plugin) { super(plugin, AbilityType.TIME_DESYNC); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        ctx.maxHitsPerTarget = 1;
        final int window = cfgI("window-ticks", 60);
        final int burst = cfgI("speed-ticks", 40);
        Win w = new Win();
        long now = System.currentTimeMillis();
        w.until = now + window * 50L;
        w.counterUntil = now + (long) (cfg("counter-window-seconds", 1.5) * 1000);
        w.reduction = Math.max(0, Math.min(0.75, cfg("damage-reduction", 0.40)));
        w.ctx = ctx;
        map.put(id, w);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, burst, cfgI("speed-amplifier", 4), false, false, true));
        sfx().play(p.getLocation(), Snd.A9_DESYNC, 1.2f, 1.0f);
        vfx().glitch(vfx().at(p.getLocation()), p.getLocation());
        tasks().timer(id, 0, 2, window / 2 + 1, t -> {
            if (!alive(p)) return false;
            long n = System.currentTimeMillis();
            if (n >= w.until) return false;
            Location l = p.getLocation();
            Vfx.Audience a = vfx().at(l);
            a.dust(l.clone().add(0, 1, 0), 6, 0.4, Vfx.NEON, 1.0f);
            a.ink(l.clone().add(0, 1, 0), 1, 0.3);
            if (t * 2 < burst) {
                ItemDisplay d = vfx().display(id, l.clone().add(0, 1.0, 0), t % 2 == 0 ? "phantom_a" : "phantom_b", new Vector3f(0.95f, 0.95f, 0.95f),
                    Vfx.yaw(Math.toRadians(-l.getYaw()) + Math.PI), true, 0);
                if (d != null) {
                    tasks().later(id, 1, () -> vfx().animate(d, new Vector3f(0.05f, 0.95f, 0.05f), Vfx.yaw(Math.toRadians(-l.getYaw()) + Math.PI), 10));
                    tasks().later(id, 12, () -> tasks().release(id, d));
                }
            }
            return true;
        }, () -> { map.remove(id); if (alive(p)) vfx().glitch(vfx().at(p.getLocation()), p.getLocation()); });
        return true;
    }

    public boolean active(Player p) {
        Win w = map.get(p.getUniqueId());
        return w != null && w.until > System.currentTimeMillis();
    }

    /** Damage-reduction + counter hook (called from CombatListener for damage ERROR receives). */
    public void onHurt(Player victim, EntityDamageEvent e, LivingEntity attacker) {
        Win w = map.get(victim.getUniqueId());
        long now = System.currentTimeMillis();
        if (w == null || w.until < now) return;
        e.setDamage(e.getDamage() * (1.0 - w.reduction));
        if (attacker != null && !w.counterUsed && now <= w.counterUntil && plugin.damage().canTarget(victim, attacker)) {
            w.counterUsed = true;
            Location from = victim.getLocation().add(0, 1.2, 0);
            Vector dir = attacker.getLocation().add(0, attacker.getHeight() / 2, 0).toVector().subtract(from.toVector());
            if (dir.lengthSquared() < 1e-4) dir = victim.getLocation().getDirection();
            final Vector fd = dir.normalize();
            sfx().play(from, Snd.A9_COUNTER, 1.3f, 1.0f);
            vfx().glitch(vfx().at(from), from);
            final LivingEntity tgt = attacker;
            tasks().later(victim.getUniqueId(), 2, () -> {
                if (!alive(victim)) return;
                fireSlash(w.ctx, victim.getLocation().add(0, 1.2, 0).add(fd.clone().multiply(1.0)), fd, 4.0, 1.4, 1.2, 0, 0, 3.0f, false, false, null, null);
                if (tgt.isValid() && w.ctx.hit(tgt, cfg("counter-damage", 9), true)) {
                    Location hl = tgt.getLocation().add(0, tgt.getHeight() / 2, 0);
                    vfx().hitBurst(hl, true);
                    sfx().play(hl, Snd.A9_COUNTER, 1.0f, 1.2f);
                    victim.sendActionBar(plugin.settings().raw("<dark_green>[NULL//REQUIEM] <green><bold>COUNTER-SLASH</bold>"));
                }
            });
        }
    }

    @Override public void onAbort(Player p) { map.remove(p.getUniqueId()); }
}

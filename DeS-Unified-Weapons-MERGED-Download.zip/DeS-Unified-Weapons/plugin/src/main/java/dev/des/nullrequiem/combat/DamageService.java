package dev.des.nullrequiem.combat;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Single choke point for ALL NULL//REQUIEM damage and crowd control.
 * Applies PvP/PvE multipliers, boss resistance, Reality Fracture scaling, the per-hit health cap vs players,
 * and finally uses LivingEntity#damage so vanilla armor/protection/resistance and every protection plugin still apply.
 */
public final class DamageService {
    private record Immunity(UUID cast, long until) { }
    public record Tag(UUID attacker, long time, String source) { }

    private final NullRequiemPlugin plugin;
    private final Set<UUID> internal = new HashSet<>();
    private final Map<UUID, Immunity> cc = new HashMap<>();
    private final Map<UUID, Tag> lastHit = new HashMap<>();

    public DamageService(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public boolean isInternal(UUID victim) { return internal.contains(victim); }

    public Tag lastHit(UUID victim) { return lastHit.get(victim); }
    public void tagHit(Player src, LivingEntity t) { tagHit(src, t, "nr"); }
    public void tagHit(Player src, LivingEntity t, String source) { lastHit.put(t.getUniqueId(), new Tag(src.getUniqueId(), System.currentTimeMillis(), source)); }
    public void forget(UUID victim) { lastHit.remove(victim); cc.remove(victim); }

    public boolean isBoss(LivingEntity t) {
        Settings s = plugin.settings();
        for (String n : s.list("general.boss-types")) {
            try { if (t.getType() == EntityType.valueOf(n.toUpperCase())) return true; } catch (IllegalArgumentException ignored) { }
        }
        return maxHealth(t) >= s.d("general.boss-health-threshold", 150);
    }

    public static double maxHealth(LivingEntity t) {
        AttributeInstance a = t.getAttribute(Attribute.MAX_HEALTH);
        return a == null ? 20 : a.getValue();
    }

    public boolean canTarget(Player src, LivingEntity t) {
        Settings s = plugin.settings();
        if (t == null || t.equals(src) || t.isDead() || !t.isValid()) return false;
        if (src.getWorld() != t.getWorld()) return false;
        if (t instanceof ArmorStand && s.b("general.ignore-armor-stands", true)) return false;
        if (t.isInvulnerable()) return false;
        if (t instanceof Player tp) {
            if (!s.b("general.affect-players", true)) return false;
            GameMode gm = tp.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;
            if (!tp.getWorld().getPVP()) return false;
            Team team = src.getScoreboard().getEntryTeam(src.getName());
            if (team != null && team.hasEntry(tp.getName()) && !team.allowFriendlyFire()) return false;
        } else {
            if (!s.b("general.affect-mobs", true)) return false;
            if (t instanceof Tameable tm && tm.isTamed() && src.getUniqueId().equals(tm.getOwnerUniqueId())) return false;
        }
        return true;
    }

    public List<LivingEntity> enemies(Player src, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        if (c.getWorld() == null) return out;
        for (org.bukkit.entity.Entity e : c.getWorld().getNearbyEntities(c, r, r, r)) {
            if (e instanceof LivingEntity le && le.getLocation().add(0, le.getHeight() / 2, 0).distanceSquared(c) <= (r + le.getWidth() / 2) * (r + le.getWidth() / 2) && canTarget(src, le)) out.add(le);
        }
        return out;
    }

    /** Computes the final raw damage fed into vanilla (before armor). Exposed for HUD/tests. */
    public double compute(LivingEntity t, double raw, double mult, boolean exposedBonus) {
        Settings s = plugin.settings();
        double a = raw * mult * s.d("damage.global-multiplier", 1.0);
        a *= (t instanceof Player) ? s.d("damage.pvp-multiplier", 0.8) : s.d("damage.pve-multiplier", 1.5);
        if (isBoss(t)) a *= s.d("damage.boss-multiplier", 0.4);
        a *= 1.0 + plugin.fracture().stacks(t) * s.d("fracture.damage-bonus-per-stack", 0.06);
        if (exposedBonus && plugin.fracture().isExposed(t)) a *= s.d("damage.exposed-bonus-multiplier", 1.6);
        if (t instanceof Player) a = Math.min(a, maxHealth(t) * s.d("damage.max-health-fraction-vs-players", 0.55));
        return a;
    }

    /** Applies ability damage. Returns true only when health/absorption actually dropped (protections respected). */
    public boolean damage(Player src, LivingEntity t, double raw, double mult, boolean exposedBonus) {
        if (!canTarget(src, t)) return false;
        double amount = compute(t, raw, mult, exposedBonus);
        if (amount <= 0.01) return false;
        if (plugin.settings().b("general.bypass-iframes", true)) t.setNoDamageTicks(0);
        double before = t.getHealth() + t.getAbsorptionAmount();
        UUID id = t.getUniqueId();
        internal.add(id);
        try { t.damage(amount, src); } finally { internal.remove(id); }
        double after = t.getHealth() + t.getAbsorptionAmount();
        boolean applied = t.isDead() || after < before - 0.001;
        if (applied) {
            lastHit.put(id, new Tag(src.getUniqueId(), System.currentTimeMillis(), "nr"));
            plugin.abilities().deathsReturn().record(src, t, Math.max(0, before - after));
        }
        return applied;
    }

    /** Crowd control velocity with immunity, boss resistance and speed clamp (prevents infinite knockback loops). */
    public boolean push(Player src, LivingEntity t, Vector vel, UUID castId) {
        if (!canTarget(src, t)) return false;
        Settings s = plugin.settings();
        double m = isBoss(t) ? s.d("damage.boss-cc-multiplier", 0.0) : 1.0;
        if (m <= 0) return false;
        long now = System.currentTimeMillis();
        Immunity im = cc.get(t.getUniqueId());
        if (im != null && im.until() > now && !im.cast().equals(castId)) return false;
        Vector v = vel.clone().multiply(m);
        double max = s.d("general.max-velocity", 1.6);
        if (v.length() > max) v.normalize().multiply(max);
        if (!Double.isFinite(v.getX() + v.getY() + v.getZ())) return false;
        t.setVelocity(v);
        cc.put(t.getUniqueId(), new Immunity(castId, now + (long) (s.d("general.cc-immunity-ticks", 30) * 50)));
        if (cc.size() > 256) cc.values().removeIf(i -> i.until() < now);
        return true;
    }

    public boolean root(Player src, LivingEntity t, int ticks, int amplifier, UUID castId) {
        if (!canTarget(src, t) || isBoss(t) && plugin.settings().d("damage.boss-cc-multiplier", 0.0) <= 0) return false;
        Immunity im = cc.get(t.getUniqueId());
        long now = System.currentTimeMillis();
        if (im != null && im.until() > now && !im.cast().equals(castId)) return false;
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, amplifier, false, true, true));
        return true;
    }
    /** Applies an already fully-computed amount (used by weapons that own their multipliers). */
    public boolean damageRaw(Player src, LivingEntity t, double amount, double capFractionVsPlayers) {
        if (!canTarget(src, t)) return false;
        if (t instanceof Player) amount = Math.min(amount, maxHealth(t) * capFractionVsPlayers);
        if (amount <= 0.01) return false;
        if (plugin.settings().b("general.bypass-iframes", true)) t.setNoDamageTicks(0);
        double before = t.getHealth() + t.getAbsorptionAmount();
        UUID id = t.getUniqueId();
        internal.add(id);
        try { t.damage(amount, src); } finally { internal.remove(id); }
        double after = t.getHealth() + t.getAbsorptionAmount();
        boolean applied = t.isDead() || after < before - 0.001;
        if (applied) lastHit.put(id, new Tag(src.getUniqueId(), System.currentTimeMillis(), "akai"));
        return applied;
    }

}

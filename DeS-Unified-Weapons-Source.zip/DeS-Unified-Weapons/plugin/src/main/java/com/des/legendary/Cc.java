package com.des.legendary;

import org.bukkit.Bukkit;
import org.bukkit.entity.Boss;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Crowd-control service: resistance stacking, boss scaling, velocity caps (prevents infinite knockback / chain-stun loops). */
public final class Cc {
    private final LegendaryPlugin pl;
    private final Map<UUID, long[]> state = new ConcurrentHashMap<>();   // {lastTick, stacks}

    public Cc(LegendaryPlugin pl) { this.pl = pl; }

    /**
     * Registers one crowd-control application on t and returns its strength multiplier:
     * 1.0 fresh target, halved for every application inside the resist window, 0 when immune / protected.
     */
    public double apply(Player caster, LivingEntity t, AbilityId id) {
        if (!Targets.valid(pl, caster, t)) return 0;
        AbilityTargetEvent ev = new AbilityTargetEvent(caster, t, id, true);
        Bukkit.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) return 0;
        long now = pl.casts().now(), window = pl.cfg().i("cc.resist-window-ticks", 80);
        long[] s = state.computeIfAbsent(t.getUniqueId(), k -> new long[]{-100000, 0});
        if (now - s[0] > window) s[1] = 0;
        double m = Math.pow(pl.cfg().d("cc.resist-factor", 0.5), s[1]);
        s[0] = now; s[1] = Math.min(s[1] + 1, 6);
        if (m < pl.cfg().d("cc.immunity-threshold", 0.2)) m = 0;
        if (t instanceof Boss) m *= pl.cfg().d("cc.boss-multiplier", 0.25);
        return m;
    }

    /** Sets t's velocity to v * mult, clamped to cc.max-velocity. */
    public void velocity(LivingEntity t, Vector v, double mult) {
        if (mult <= 0 || !t.isValid()) return;
        Vector r = v.clone().multiply(mult);
        double max = pl.cfg().d("cc.max-velocity", 1.9);
        if (r.length() > max) r.normalize().multiply(max);
        t.setVelocity(r);
        t.setFallDistance(0f);
    }

    public void slow(LivingEntity t, int ticks, int amp, double mult) {
        if (mult <= 0) return;
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, Math.max(2, (int) (ticks * mult)), amp, false, false, false));
    }

    public void prune(long now) {
        Iterator<Map.Entry<UUID, long[]>> it = state.entrySet().iterator();
        while (it.hasNext()) if (now - it.next().getValue()[0] > 1200) it.remove();
    }
}

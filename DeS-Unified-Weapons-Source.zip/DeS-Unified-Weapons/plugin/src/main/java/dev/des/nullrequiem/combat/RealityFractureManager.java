package dev.des.nullrequiem.combat;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** FRACTURED EXISTENCE: up to 5 Reality Fracture stacks per target; at 5 the target is REALITY EXPOSED. */
public final class RealityFractureManager {
    private static final class Fracture {
        int stacks; long expires; UUID owner;
    }

    private final NullRequiemPlugin plugin;
    private final Map<UUID, Fracture> map = new HashMap<>();
    private BukkitTask task;
    private int run;

    public RealityFractureManager(NullRequiemPlugin plugin) { this.plugin = plugin; }

    private int maxStacks() { return plugin.settings().i("fracture.max-stacks", 5); }

    public int stacks(LivingEntity t) {
        Fracture f = map.get(t.getUniqueId());
        if (f == null) return 0;
        if (f.expires < System.currentTimeMillis()) { map.remove(t.getUniqueId()); return 0; }
        return f.stacks;
    }

    public boolean isExposed(LivingEntity t) { return stacks(t) >= maxStacks(); }

    public UUID ownerOf(LivingEntity t) { Fracture f = map.get(t.getUniqueId()); return f == null ? null : f.owner; }

    public void clear(UUID id) { map.remove(id); }

    public void apply(Player src, LivingEntity t) {
        UUID id = t.getUniqueId();
        Fracture f = map.get(id);
        if (f == null) {
            if (map.size() >= plugin.settings().i("fracture.max-tracked", 80)) return;
            f = new Fracture();
            map.put(id, f);
        }
        boolean was = f.stacks >= maxStacks();
        f.stacks = Math.min(maxStacks(), f.stacks + 1);
        f.owner = src.getUniqueId();
        f.expires = System.currentTimeMillis() + (long) (plugin.settings().d("fracture.duration-seconds", 12) * 1000);
        Location l = t.getLocation().add(0, t.getHeight() / 2, 0);
        plugin.sfx().play(l, Snd.FRACTURE, 0.7f, 0.8f + f.stacks * 0.1f);
        if (f.stacks >= maxStacks() && !was) {
            plugin.sfx().play(l, Snd.EXPOSED, 1.0f, 1.0f);
            src.sendActionBar(plugin.settings().raw("<dark_green>[NULL//REQUIEM] <green><bold>REALITY EXPOSED</bold> <gray>- " + t.getName()));
            if (t instanceof Player tp) tp.sendActionBar(plugin.settings().raw("<green><bold>REALITY EXPOSED</bold>"));
        }
    }

    public void start() {
        if (task != null) return;
        task = Bukkit.getScheduler().runTaskTimer(plugin.java(), this::tick, 20L, 5L);
    }

    public void stop() { if (task != null) task.cancel(); task = null; map.clear(); }

    private void tick() {
        run++;
        long now = System.currentTimeMillis();
        int budget = plugin.settings().i("fracture.visual-budget-per-tick", 24);
        for (Iterator<Map.Entry<UUID, Fracture>> it = map.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Fracture> en = it.next();
            Fracture f = en.getValue();
            Entity e = Bukkit.getEntity(en.getKey());
            if (f.expires < now || !(e instanceof LivingEntity le) || !le.isValid() || le.isDead()) { it.remove(); continue; }
            if (budget-- <= 0) continue;
            draw(le, f.stacks);
        }
    }

    private void draw(LivingEntity t, int stacks) {
        Location c = t.getLocation().add(0, t.getHeight() / 2, 0);
        Vfx v = plugin.vfx();
        Vfx.Audience a = v.at(c);
        double h = t.getHeight(), w = Math.max(0.5, t.getWidth());
        double ph = run * 0.4;
        java.util.concurrent.ThreadLocalRandom r = java.util.concurrent.ThreadLocalRandom.current();
        if (stacks == 1) {
            a.dust(c.clone().add(r.nextGaussian() * w * 0.4, r.nextGaussian() * h * 0.3, r.nextGaussian() * w * 0.4), 2, 0, Vfx.NEON, 0.7f);
        } else if (stacks == 2) {
            Location top = c.clone().add(r.nextDouble(-0.2, 0.2), h * 0.5, r.nextDouble(-0.2, 0.2));
            Location bot = c.clone().add(r.nextDouble(-0.3, 0.3), -h * 0.5, r.nextDouble(-0.3, 0.3));
            v.crack(a, top, bot, 0.5, Vfx.EMERALD, 0.7f);
        } else if (stacks == 3) {
            for (int i = 0; i < 3; i++) {
                double ang = ph + i * 2.094;
                a.dust(c.clone().add(Math.cos(ang) * w, Math.sin(ph + i) * 0.3, Math.sin(ang) * w), 1, 0, Vfx.NEON, 0.9f);
            }
            a.villager(c, 1, w * 0.5);
        } else if (stacks == 4) {
            for (int i = 0; i < 5; i++) {
                double ang = ph * 1.3 + i * 1.2566;
                a.dust(c.clone().add(Math.cos(ang) * w * 1.1, Math.sin(ph + i) * h * 0.3, Math.sin(ang) * w * 1.1), 1, 0, i % 2 == 0 ? Vfx.NEON : Vfx.VOID, 1.0f);
            }
            if (run % 2 == 0) v.glitch(a, c);
            a.ink(c, 1, w * 0.4);
        } else {
            v.ring(a, t.getLocation().add(0, 0.1, 0), w + 0.4, 10, ph, Vfx.NEON, 1.1f);
            v.ring(a, t.getLocation().add(0, h + 0.3, 0), w * 0.8, 8, -ph, Vfx.PALE, 0.9f);
            a.villager(c, 2, w * 0.6);
            if (run % 2 == 0) v.glitch(a, c);
            if (run % 6 == 0) a.block(c, 4, 0.4, Material.EMERALD_BLOCK);
            v.crack(a, c.clone().add(-w, h * 0.5, 0), c.clone().add(w, -h * 0.5, 0), 0.6, Vfx.NEON, 0.8f);
        }
    }
}

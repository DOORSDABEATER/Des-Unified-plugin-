package com.des.legendary;

import net.kyori.adventure.text.format.TextColor;
import java.util.ArrayList;
import java.util.List;

/** The two legendary weapons. */
public enum Weapon {
    NOISEFORM("noiseform", "NOISEFORM", "Legendary Weapon", "Resonance", "Balanced", 0xA855F7),
    NEBULUX("nebulux", "NEBULUX", "Chromatic Legendary Weapon", "Cosmic Energy", "High Skill", 0x7DD3FC);

    public final String key, display, rarity, energyName, style;
    public final TextColor color;
    private List<AbilityId> normal;

    Weapon(String key, String display, String rarity, String energyName, String style, int rgb) {
        this.key = key; this.display = display; this.rarity = rarity; this.energyName = energyName; this.style = style;
        this.color = TextColor.color(rgb);
    }

    /** The six selectable abilities, in cycle order. */
    public synchronized List<AbilityId> abilities() {
        if (normal == null) {
            normal = new ArrayList<>();
            for (AbilityId a : AbilityId.values()) if (a.weapon == this && !a.ultimate) normal.add(a);
        }
        return normal;
    }

    public AbilityId ultimate() {
        for (AbilityId a : AbilityId.values()) if (a.weapon == this && a.ultimate) return a;
        throw new IllegalStateException();
    }

    public static Weapon byKey(String s) {
        for (Weapon w : values()) if (w.key.equalsIgnoreCase(s) || w.name().equalsIgnoreCase(s)) return w;
        return null;
    }
}

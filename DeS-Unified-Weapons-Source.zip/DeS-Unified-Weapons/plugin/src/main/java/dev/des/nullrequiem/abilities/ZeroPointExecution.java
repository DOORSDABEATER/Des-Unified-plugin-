package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** ABILITY 2 - teleport behind a target (exposed first) and perform a delayed vertical execution (dodgeable). */
public final class ZeroPointExecution extends AbilityBase {
    public ZeroPointExecution(NullRequiemPlugin plugin) { super(plugin, AbilityType.ZERO_POINT_EXECUTION); }

    @Override
    public boolean execute(CastContext ctx) {
        Player p = ctx.player;
        LivingEntity target = aimTarget(p, cfg("range", 22), cfg("cone-degrees", 35), true);
        if (target == null) { actionbar(p, "<yellow>ZERO-POINT EXECUTION <gray>- no target in sight"); return false; }
        Location from = p.getLocation();
        Vector toT = Locs.flat(target.getLocation().toVector().subtract(from.toVector()));
        Location dest = null;
        double off = cfg("behind-distance", 1.9);
        Vector[] tries = {toT.clone(), toT.clone().crossProduct(new Vector(0, 1, 0)), toT.clone().crossProduct(new Vector(0, -1, 0)), toT.clone().multiply(-1)};
        for (Vector v : tries) {
            Location c = target.getLocation().clone().add(v.clone().normalize().multiply(off));
            if (Locs.standable(c) && Locs.hasFloor(c, 4)) { dest = c; break; }
        }
        if (dest == null) { actionbar(p, "<yellow>ZERO-POINT EXECUTION <gray>- no safe landing"); return false; }
        Vector face = target.getLocation().toVector().subtract(dest.toVector());
        dest.setDirection(face);
        // teleport trail + glitch at both ends
        Vfx.Audience a = vfx().at(from);
        vfx().line(a, from.clone().add(0, 1, 0), dest.clone().add(0, 1, 0), 0.35, Vfx.NEON, 1.3f);
        vfx().glitch(a, from.clone().add(0, 0.5, 0));
        vfx().glitch(vfx().at(dest), dest.clone().add(0, 0.5, 0));
        sfx().play(from, Snd.A2_TELEPORT, 1.0f, 1.0f);
        p.teleport(dest);
        p.setVelocity(new Vector(0, 0, 0));
        sfx().play(dest, Snd.A2_TELEPORT, 1.0f, 1.3f);
        p.swingMainHand();
        final LivingEntity tgt = target;
        tasks().later(p.getUniqueId(), cfgI("windup-ticks", 7), () -> {
            if (!alive(p) || !tgt.isValid() || tgt.isDead() || tgt.getLocation().distanceSquared(p.getLocation()) > 36) return;
            Location tl = tgt.getLocation();
            p.swingMainHand();
            Location top = tl.clone().add(0, 2.6, 0);
            fireSlash(ctx, top, new Vector(0, -1, 0), 3.0, 1.1, 1.4, 0, 0, (float) cfg("scale", 3.8), true, false, null, null);
            boolean exposed = plugin.fracture().isExposed(tgt);
            if (ctx.hit(tgt, cfg("damage", 12), true)) {
                Location hl = tgt.getLocation().add(0, tgt.getHeight() / 2, 0);
                sfx().play(hl, Snd.A2_IMPACT, 1.2f, exposed ? 0.8f : 1.0f);
                vfx().hitBurst(hl, true);
                vfx().crack(vfx().at(hl), tl.clone().add(0, 2.4, 0), tl.clone().add(0, 0.1, 0), 0.5, Vfx.NEON, 1.3f);
                vfx().ring(vfx().at(tl), tl.clone().add(0, 0.15, 0), 2.2, 18, 0, Vfx.NEON, 1.3f);
            }
        });
        return true;
    }
}

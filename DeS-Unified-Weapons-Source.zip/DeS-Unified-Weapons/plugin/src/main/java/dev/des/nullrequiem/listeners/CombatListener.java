package dev.des.nullrequiem.listeners;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.combat.DamageService;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.storage.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.UUID;

public final class CombatListener implements Listener {
    private final NullRequiemPlugin plugin;
    public CombatListener(NullRequiemPlugin plugin) { this.plugin = plugin; }

    private LivingEntity resolveAttacker(Entity d) {
        if (d instanceof LivingEntity le) return le;
        if (d instanceof Projectile pr && pr.getShooter() instanceof LivingEntity le) return le;
        return null;
    }

    /** Melee: PASSIVE (Fractured Existence) + fragments + feedback. Ability damage is skipped (it handles its own). */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof LivingEntity victim) || plugin.damage().isInternal(victim.getUniqueId())) return;
        if (!(e.getDamager() instanceof Player p) || e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!plugin.weapons().holdsUsable(p) || plugin.cutscene().isCaptured(p.getUniqueId())) return;
        if (!plugin.damage().canTarget(p, victim)) return;
        boolean full = p.getAttackCooldown() >= 0.9f;
        double stacks = plugin.fracture().stacks(victim);
        e.setDamage(e.getDamage() * (1.0 + stacks * plugin.settings().d("fracture.damage-bonus-per-stack", 0.06)));
        boolean crit = full && p.getFallDistance() > 0 && !p.isOnGround() && !p.isSprinting();
        if (full && plugin.settings().b("fracture.melee-applies", true)) {
            plugin.fracture().apply(p, victim);
            plugin.fragments().onMelee(p, victim);
            plugin.mastery().registerHit(p, AbilityType.RIFT_CLEAVER, victim);
            plugin.data().get(p.getUniqueId()).hits++;
        }
        var l = victim.getLocation().add(0, victim.getHeight() / 2, 0);
        plugin.vfx().hitBurst(l, crit);
        plugin.sfx().play(l, crit ? Snd.CRIT : full ? Snd.ATTACK_HEAVY : Snd.ATTACK_LIGHT, crit ? 1.1f : 0.8f, 1.0f);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMeleeMonitor(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof LivingEntity victim) || plugin.damage().isInternal(victim.getUniqueId())) return;
        if (e.getDamager() instanceof Player p && plugin.weapons().holdsUsable(p) && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
            plugin.damage().tagHit(p, victim);
            plugin.abilities().deathsReturn().record(p, victim, e.getFinalDamage());
        }
    }

    /** TIME//DESYNC reduction + counter. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p) || !plugin.abilities().timeDesync().active(p)) return;
        LivingEntity attacker = e instanceof EntityDamageByEntityEvent be ? resolveAttacker(be.getDamager()) : null;
        plugin.abilities().timeDesync().onHurt(p, e, attacker);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        LivingEntity victim = e.getEntity();
        UUID id = victim.getUniqueId();
        boolean exposed = plugin.fracture().isExposed(victim);
        DamageService.Tag tag = plugin.damage().lastHit(id);
        Player killer = victim.getKiller();
        if (killer == null && tag != null && System.currentTimeMillis() - tag.time() < 5000) killer = Bukkit.getPlayer(tag.attacker());
        else if (killer != null && !plugin.weapons().holdsUsable(killer) && (tag == null || !tag.attacker().equals(killer.getUniqueId()))) killer = null;
        if (killer != null && !killer.equals(victim)) {
            PlayerData d = plugin.data().get(killer.getUniqueId());
            d.kills++;
            if (exposed) d.exposedKills++;
            plugin.fragments().onKill(killer, exposed);
            plugin.mastery().registerKill(killer, victim, exposed);
            var l = victim.getLocation();
            plugin.vfx().killEffect(l);
            plugin.sfx().play(l, Snd.KILL, 1.2f, exposed ? 0.8f : 1.0f);
            killer.sendActionBar(plugin.settings().raw("<dark_green>[404] <green><bold>REALITY NOT FOUND.</bold> <gray>" + victim.getName()
                + (exposed ? " <dark_green>(exposed kill: fragments restored)" : "")));
            plugin.states().get(killer).msgUntil = System.currentTimeMillis() + 1800;
            if (victim instanceof Player vp && plugin.settings().b("messages-broadcast-player-kills", false))
                Bukkit.broadcast(plugin.settings().raw("<dark_green>[NULL//REQUIEM] <green>" + vp.getName() + " <gray>was deleted by <green>" + killer.getName()));
        }
        plugin.fracture().clear(id);
        plugin.damage().forget(id);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        plugin.abilities().abort(p);
        plugin.states().get(p).fragments = 0;
    }
}

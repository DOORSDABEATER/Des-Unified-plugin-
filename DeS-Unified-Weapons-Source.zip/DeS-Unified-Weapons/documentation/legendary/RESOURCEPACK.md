# Resource pack

* Namespace `des` only. Items are NETHERITE_SWORDs with the `item_model` component `des:noiseform` / `des:nebulux` (no vanilla model is overridden, so it cannot clash with your existing pack).
* `assets/des/models/item/*.json` — 378 / 474 axis-aligned cuboids per weapon, built from the same 0.5-unit grid as the painted texture (so geometry and paint always match). Blade length ~42 / ~47 model units vs ~17 for a vanilla sword.
* Held transforms reuse the vanilla `handheld` pose (same grip point and angles as a vanilla sword) with a custom scale (third person 0.8, first person 0.62). GUI / ground / item-frame transforms are computed so the sword is centred.
* `textures/item/noiseform.png` (8 frames) and `nebulux.png` (12 frames): 288 px animated atlases with `interpolate: true` (pulsing sonic channels / flowing rainbow edges, twinkling stars, crystal facets). Side faces sample a small material patch in the atlas corner.
* `textures/item/fx/*.png` + `models/item/fx/*.json` + `items/fx/*.json`: 18 flat sprites (crescents, rings, orbs, vortex, shields, star marker, rift, flares, beams) shown by the plugin through ItemDisplay entities with full-bright light.
* `sounds.json` + 44 mono OGG files (original, synthesized by `tools/build_resourcepack.py`, no licensing issues). Events are `des:<weapon>.<name>`, see `documentation/sound_events.json`; per-event volume/pitch in config `sounds.events`.
* Regenerate everything: `python3 tools/build_resourcepack.py` (numpy, scipy, pillow, matplotlib, ffmpeg with libvorbis).

## Why display entities instead of custom particles
Vanilla/Paper has no API for new particle types without client mods. The plugin therefore combines budgeted vanilla particles (coloured dust, end-rod, electric spark, portal ...) with ItemDisplay sprites (real textures, smooth client-side interpolation). No unsupported particle is claimed.

## Honest limitations
* Item models render **no true emission** without a shader pack; glow is painted (and pulses through the animation) but dark caves will dim it. Display sprites use full-bright light.
* Full-body player animation is impossible with Paper alone. Poses are approximated by: arm swings at the right moments, slowness holds, hovering/rising (Supernova), a floating raised copy of the blade (Final Frequency), a stance blade (Resonance Guard), afterimages (Overdrive) and all effects around the player. No client mod is needed or claimed.
* Models and transforms were verified with a software renderer, not in the real game client. First/third-person scale (0.62 / 0.8) may need a taste tweak: change `display()` in `tools/weapons_model.py` and rebuild.
* Pack format numbers (`min_format`/`max_format`) are set wide; override with `PACK_MIN`/`PACK_MAX` if your client warns.

## API notes (if your Paper build differs)
Names that changed across versions and are used once each: `Attribute.ATTACK_DAMAGE/ATTACK_SPEED` (Fx/Items), `PotionEffectType.SLOWNESS/NAUSEA`, `Particle.DUST/DUST_COLOR_TRANSITION/BLOCK/EXPLOSION/EXPLOSION_EMITTER/FIREWORK/SONIC_BOOM`. Adjust the single reference if the compiler flags one.

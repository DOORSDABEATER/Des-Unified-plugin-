package dev.des.nullrequiem.abilities;

import org.bukkit.entity.Player;

public interface Ability {
    AbilityType type();

    /** Starts the ability. Return false if it could not start (no cooldown/cost is charged then). */
    boolean execute(CastContext ctx);

    /** Abilities that set their own cooldown (e.g. two-stage abilities). */
    default boolean selfManagedCooldown() { return false; }

    /** True when a second activation right now is a valid follow-up (seal detonation, charge release). */
    default boolean canRecast(Player p) { return false; }

    /** Called when the caster dies, quits or changes world. */
    default void onAbort(Player p) { }
}

package dev.des.nullrequiem.akai;

import org.bukkit.entity.Player;

public interface AkaiAbility {
    AkaiType type();
    boolean execute(AkaiCtx ctx);
    default boolean selfManagedCooldown() { return false; }
    default boolean canRecast(Player p) { return false; }
    default void onAbort(Player p) { }
}

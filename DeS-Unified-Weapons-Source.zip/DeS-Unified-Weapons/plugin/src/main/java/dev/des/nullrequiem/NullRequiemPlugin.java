package dev.des.nullrequiem;

import dev.des.nullrequiem.abilities.AbilityManager;
import dev.des.nullrequiem.collection.CollectionIntegration;
import dev.des.nullrequiem.combat.*;
import dev.des.nullrequiem.commands.NullRequiemCommand;
import dev.des.nullrequiem.cutscene.CameraController;
import dev.des.nullrequiem.cutscene.CutsceneManager;
import dev.des.nullrequiem.cutscene.UltimateManager;
import dev.des.nullrequiem.listeners.CombatListener;
import dev.des.nullrequiem.listeners.ConnectionListener;
import dev.des.nullrequiem.listeners.WeaponListener;
import dev.des.nullrequiem.mastery.MasteryManager;
import dev.des.nullrequiem.sounds.SoundManager;
import dev.des.nullrequiem.storage.PlayerDataStore;
import dev.des.nullrequiem.util.TaskTracker;
import dev.des.nullrequiem.vfx.Vfx;
import dev.des.nullrequiem.weapons.HudTask;
import dev.des.nullrequiem.weapons.WeaponManager;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * NULL//REQUIEM subsystem hosted by the single DeSLegendary JavaPlugin.
 * It deliberately is not a second Bukkit plugin; all Bukkit task ownership
 * and event registration are delegated to the host plugin.
 */
public final class NullRequiemPlugin {
    private final JavaPlugin host;
    private final File dataFolder;
    private File configFile;
    private FileConfiguration config;

    private Settings settings;
    private PlayerDataStore data;
    private PlayerStateManager states;
    private CooldownManager cooldowns;
    private TaskTracker tasks;
    private WeaponManager weapons;
    private DamageService damage;
    private Vfx vfx;
    private SoundManager sfx;
    private RealityFragmentManager fragments;
    private RealityFractureManager fracture;
    private MasteryManager mastery;
    private ComboTracker combos;
    private CameraController camera;
    private CutsceneManager cutscene;
    private UltimateManager ultimate;
    private AbilityManager abilities;
    private CollectionIntegration collection;

    public NullRequiemPlugin(JavaPlugin host) {
        this.host = host;
        this.dataFolder = new File(host.getDataFolder(), "nullrequiem");
    }

    public JavaPlugin java() { return host; }
    public Logger getLogger() { return host.getLogger(); }
    public File getDataFolder() { return dataFolder; }
    public PluginCommand getCommand(String name) { return host.getCommand(name); }
    public FileConfiguration getConfig() { return config; }

    private void saveDefaultConfig() {
        // One-time migration from the former standalone plugin data folder.
        // This preserves existing scythe serials, player mastery/fragments and recovery data.
        File legacyFolder = new File(host.getDataFolder().getParentFile(), "NullRequiem");
        if (!dataFolder.exists() && legacyFolder.isDirectory()) {
            try (Stream<Path> paths = Files.walk(legacyFolder.toPath())) {
                paths.forEach(source -> {
                    try {
                        Path relative = legacyFolder.toPath().relativize(source);
                        Path target = dataFolder.toPath().resolve(relative);
                        if (Files.isDirectory(source)) Files.createDirectories(target);
                        else {
                            Files.createDirectories(target.getParent());
                            Files.copy(source, target);
                        }
                    } catch (IOException ex) {
                        throw new java.io.UncheckedIOException(ex);
                    }
                });
                getLogger().info("Migrated existing NULL//REQUIEM data into the unified DeS plugin folder.");
            } catch (IOException | java.io.UncheckedIOException ex) {
                getLogger().log(Level.SEVERE, "Could not migrate old NULL//REQUIEM data; original folder was left untouched.", ex);
                throw new IllegalStateException("NULL//REQUIEM data migration failed", ex);
            }
        }
        if (!dataFolder.exists() && !dataFolder.mkdirs())
            getLogger().warning("Could not create NULL//REQUIEM data folder: " + dataFolder);
        configFile = new File(dataFolder, "config.yml");
        if (!configFile.exists()) {
            try (InputStream in = host.getResource("nullrequiem.yml")) {
                if (in == null) throw new IOException("nullrequiem.yml is missing from the plugin JAR");
                Files.copy(in, configFile.toPath());
            } catch (IOException ex) {
                throw new IllegalStateException("Could not create NULL//REQUIEM config", ex);
            }
        }
        reloadConfig();
    }

    public void reloadConfig() {
        if (configFile == null) configFile = new File(dataFolder, "config.yml");
        config = YamlConfiguration.loadConfiguration(configFile);
        try (InputStream in = host.getResource("nullrequiem.yml")) {
            if (in != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(in, StandardCharsets.UTF_8));
                config.setDefaults(defaults);
            }
        } catch (IOException ex) {
            getLogger().log(Level.WARNING, "Could not load NULL//REQUIEM config defaults", ex);
        }
    }

    public void enable() {
        saveDefaultConfig();
        settings = new Settings(this);
        data = new PlayerDataStore(this);
        states = new PlayerStateManager();
        cooldowns = new CooldownManager(this);
        tasks = new TaskTracker(this);
        weapons = new WeaponManager(this);
        damage = new DamageService(this);
        vfx = new Vfx(this);
        sfx = new SoundManager(this);
        fragments = new RealityFragmentManager(this);
        fracture = new RealityFractureManager(this);
        mastery = new MasteryManager(this);
        combos = new ComboTracker(this);
        camera = new CameraController(this);
        cutscene = new CutsceneManager(this);
        ultimate = new UltimateManager(this);
        abilities = new AbilityManager(this);
        collection = new CollectionIntegration(this);

        Bukkit.getPluginManager().registerEvents(new ConnectionListener(this), host);
        Bukkit.getPluginManager().registerEvents(new WeaponListener(this), host);
        Bukkit.getPluginManager().registerEvents(new CombatListener(this), host);
        Bukkit.getPluginManager().registerEvents(collection, host);
        Bukkit.getPluginManager().registerEvents(cutscene, host);

        NullRequiemCommand cmd = new NullRequiemCommand(this);
        PluginCommand pc = getCommand("nullrequiem");
        if (pc != null) { pc.setExecutor(cmd); pc.setTabCompleter(cmd); }
        else getLogger().severe("Command 'nullrequiem' is missing from the unified plugin.yml");

        new HudTask(this).runTaskTimer(host, 20L, 5L);
        fracture.start();
        long save = Math.max(60, settings.i("general.autosave-seconds", 300)) * 20L;
        Bukkit.getScheduler().runTaskTimer(host, () -> data.saveAllAsync(), save, save);

        for (Player p : Bukkit.getOnlinePlayers()) {
            data.get(p.getUniqueId());
            cutscene.recoverPending(p);
        }
        getLogger().info("NULL//REQUIEM subsystem enabled inside DeSLegendary.");
    }

    public void disable() {
        if (ultimate != null) ultimate.abortAll();
        if (cutscene != null) cutscene.restoreAll("shutdown");
        if (tasks != null) tasks.cleanupAll();
        if (fracture != null) fracture.stop();
        if (data != null) data.saveAllSync();
    }

    public void reloadAll() { reloadConfig(); }

    public Settings settings() { return settings; }
    public PlayerDataStore data() { return data; }
    public PlayerStateManager states() { return states; }
    public CooldownManager cooldowns() { return cooldowns; }
    public TaskTracker tasks() { return tasks; }
    public WeaponManager weapons() { return weapons; }
    public DamageService damage() { return damage; }
    public Vfx vfx() { return vfx; }
    public SoundManager sfx() { return sfx; }
    public RealityFragmentManager fragments() { return fragments; }
    public RealityFractureManager fracture() { return fracture; }
    public MasteryManager mastery() { return mastery; }
    public ComboTracker combos() { return combos; }
    public CameraController camera() { return camera; }
    public CutsceneManager cutscene() { return cutscene; }
    public UltimateManager ultimate() { return ultimate; }
    public AbilityManager abilities() { return abilities; }
    public CollectionIntegration collection() { return collection; }
}

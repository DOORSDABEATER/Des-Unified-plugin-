package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.combat.PlayerState;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.storage.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.EnumMap;
import java.util.Map;

/** Validates, charges and dispatches abilities. All checks are server-side. */
public final class AbilityManager {
    public enum Result { OK, NOT_HOLDING, COOLDOWN, NO_FRAGMENTS, BUSY, DISABLED, FAILED }

    private final NullRequiemPlugin plugin;
    private final Map<AbilityType, Ability> map = new EnumMap<>(AbilityType.class);
    private final DeathsReturn deathsReturn;
    private final FalseReality falseReality;
    private final FinalVariable finalVariable;
    private final TimeDesync timeDesync;

    public AbilityManager(NullRequiemPlugin plugin) {
        this.plugin = plugin;
        deathsReturn = new DeathsReturn(plugin);
        falseReality = new FalseReality(plugin);
        finalVariable = new FinalVariable(plugin);
        timeDesync = new TimeDesync(plugin);
        reg(new RiftCleaver(plugin));
        reg(new ZeroPointExecution(plugin));
        reg(new BrokenCoordinates(plugin));
        reg(new NullGravity(plugin));
        reg(falseReality);
        reg(new WorldBreak(plugin));
        reg(new CorruptionCascade(plugin));
        reg(new FractureStorm(plugin));
        reg(timeDesync);
        reg(deathsReturn);
        reg(new AbsoluteNullification(plugin));
        reg(finalVariable);
        reg(new UltimateAbility(plugin));
    }

    private void reg(Ability a) { map.put(a.type(), a); }
    public Ability get(AbilityType t) { return map.get(t); }
    public DeathsReturn deathsReturn() { return deathsReturn; }
    public FalseReality falseReality() { return falseReality; }
    public FinalVariable finalVariable() { return finalVariable; }
    public TimeDesync timeDesync() { return timeDesync; }

    public Result cast(Player p, AbilityType t, boolean forced) {
        if (!forced && !plugin.weapons().holdsUsable(p)) return Result.NOT_HOLDING;
        if (plugin.settings().worldDisabled(p.getWorld())) {
            p.sendMessage(plugin.settings().msg("world-disabled", "<red>NULL//REQUIEM cannot be used in this world."));
            return Result.DISABLED;
        }
        if (plugin.cutscene().isCaptured(p.getUniqueId()) || p.isDead()) return Result.BUSY;
        PlayerState st = plugin.states().get(p);
        Ability ab = map.get(t);
        boolean recast = ab.canRecast(p);
        if (st.busy && !recast) return Result.BUSY;
        long cd = plugin.cooldowns().remainingMs(p, t);
        if (!forced && !recast && cd > 0) {
            feedback(p, "<red>" + t.display() + " <gray>cooldown: <white>" + String.format("%.1fs", cd / 1000.0));
            plugin.sfx().playTo(p, Snd.DENY, 0.6f, 1.0f);
            return Result.COOLDOWN;
        }
        double cost = recast ? 0 : plugin.settings().cost(t);
        if (!forced && st.fragments + 1e-6 < cost) {
            feedback(p, "<yellow>" + t.display() + " <gray>needs <white>" + (int) cost + " <gray>Reality Fragments (<white>" + (int) st.fragments + "<gray>)");
            plugin.sfx().playTo(p, Snd.DENY, 0.6f, 0.8f);
            return Result.NO_FRAGMENTS;
        }
        CastContext ctx = new CastContext(plugin, p, st, t);
        boolean ok;
        try { ok = ab.execute(ctx); }
        catch (Throwable ex) { plugin.getLogger().log(java.util.logging.Level.SEVERE, "Ability " + t + " failed", ex); ok = false; }
        if (!ok) return Result.FAILED;
        if (!forced) {
            if (cost > 0) plugin.fragments().spend(p, cost);
            if (!ab.selfManagedCooldown()) plugin.cooldowns().setSeconds(p, t, plugin.settings().cooldownSeconds(t));
        }
        PlayerData d = plugin.data().get(p.getUniqueId());
        d.casts++;
        d.uses.merge(t.key(), 1, Integer::sum);
        if (t != AbilityType.FALSE_REALITY) falseReality.echo(p, t);
        return Result.OK;
    }

    private void feedback(Player p, String mm) {
        p.sendActionBar(plugin.settings().raw(mm));
        plugin.states().get(p).msgUntil = System.currentTimeMillis() + 1200;
    }

    public void select(Player p, int delta) {
        PlayerState st = plugin.states().get(p);
        st.selected = Math.floorMod(st.selected + delta, AbilityType.ACTIVES.length);
        announceSelection(p, st);
    }

    public void selectIndex(Player p, int index) {
        PlayerState st = plugin.states().get(p);
        st.selected = Math.floorMod(index, AbilityType.ACTIVES.length);
        announceSelection(p, st);
    }

    private void announceSelection(Player p, PlayerState st) {
        AbilityType t = AbilityType.ACTIVES[st.selected];
        feedback(p, "<dark_green>[<green>" + (st.selected + 1) + "/12<dark_green>] <green><bold>" + t.display() + "</bold> <gray>cost <white>" + (int) plugin.settings().cost(t));
        plugin.sfx().playTo(p, Snd.A3_TICK, 0.5f, 1.0f + st.selected * 0.04f);
    }

    /** Aborts every running effect of a caster (death, quit, world change). */
    public void abort(Player p) {
        for (Ability a : map.values()) a.onAbort(p);
        plugin.tasks().cleanup(p.getUniqueId());
        plugin.states().get(p).busy = false;
        plugin.ultimate().abort(p.getUniqueId(), "caster-abort");
    }

    public Vector horizontal(Player p) { return p.getLocation().getDirection().setY(0).normalize(); }
}

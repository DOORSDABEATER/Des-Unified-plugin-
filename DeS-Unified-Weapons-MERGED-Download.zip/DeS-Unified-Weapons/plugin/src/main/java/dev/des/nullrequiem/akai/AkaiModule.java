package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** AKAI NO O module of the unified DeS weapons plugin (shares TaskTracker, DamageService, Vfx, SoundManager, CutsceneManager, CameraController). */
public final class AkaiModule {
    private final NullRequiemPlugin plugin;
    private AkaiSettings settings; private AkaiStore store; private AkaiWeapon weapon; private AkaiMarks marks; private AkaiEnergy energy;
    private AkaiMastery mastery; private AkaiManager manager; private AkaiUltimate ultimate;
    private final Map<UUID, AkaiState> states = new HashMap<>();
    private final Map<UUID, EnumMap<AkaiType, Long>> cooldowns = new HashMap<>();

    public AkaiModule(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public void enable() {
        settings = new AkaiSettings(plugin);
        store = new AkaiStore(plugin);
        weapon = new AkaiWeapon(plugin, this);
        marks = new AkaiMarks(plugin, this);
        energy = new AkaiEnergy(plugin, this);
        mastery = new AkaiMastery(plugin, this);
        ultimate = new AkaiUltimate(plugin, this);
        manager = new AkaiManager(plugin, this);
        Bukkit.getPluginManager().registerEvents(new AkaiListener(plugin, this), plugin.java());
        AkaiCommand cmd = new AkaiCommand(plugin, this);
        PluginCommand pc = plugin.getCommand("akai");
        if (pc != null) { pc.setExecutor(cmd); pc.setTabCompleter(cmd); }
        new AkaiHud(plugin, this).runTaskTimer(plugin.java(), 20L, 5L);
        marks.start();
        long save = Math.max(60, settings.i("autosave-seconds", 300)) * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin.java(), () -> store.saveAllAsync(), save, save);
        for (Player p : Bukkit.getOnlinePlayers()) store.get(p.getUniqueId());
        plugin.getLogger().info("AKAI NO O module online - the throne serves the blade.");
    }

    public void disable() {
        if (ultimate != null) ultimate.abortAll();
        if (marks != null) marks.stop();
        if (store != null) store.saveAllSync();
    }

    public AkaiSettings settings() { return settings; }
    public AkaiStore store() { return store; }
    public AkaiWeapon weapon() { return weapon; }
    public AkaiMarks marks() { return marks; }
    public AkaiEnergy energy() { return energy; }
    public AkaiMastery mastery() { return mastery; }
    public AkaiManager manager() { return manager; }
    public AkaiUltimate ultimate() { return ultimate; }

    public AkaiState state(Player p) { return states.computeIfAbsent(p.getUniqueId(), k -> new AkaiState()); }
    public AkaiState state(UUID id) { return states.computeIfAbsent(id, k -> new AkaiState()); }
    public void removeState(UUID id) { states.remove(id); cooldowns.remove(id); }

    public long cooldownMs(Player p, AkaiType t) {
        long now = System.currentTimeMillis();
        if (t.isUltimate()) return Math.max(0, store.get(p.getUniqueId()).ultimateCooldownUntil - now);
        EnumMap<AkaiType, Long> m = cooldowns.get(p.getUniqueId());
        Long u = m == null ? null : m.get(t);
        return u == null ? 0 : Math.max(0, u - now);
    }

    public void setCooldown(Player p, AkaiType t, double seconds) {
        long until = System.currentTimeMillis() + (long) (seconds * 1000);
        if (t.isUltimate()) { store.get(p.getUniqueId()).ultimateCooldownUntil = until; return; }
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new EnumMap<>(AkaiType.class)).put(t, until);
    }

    public void resetCooldowns(Player p) { cooldowns.remove(p.getUniqueId()); store.get(p.getUniqueId()).ultimateCooldownUntil = 0; }
}

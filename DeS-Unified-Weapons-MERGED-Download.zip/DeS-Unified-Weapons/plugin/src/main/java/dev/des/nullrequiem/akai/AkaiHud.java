package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

/** Single global task: energy HUD, draw sound, idle aura (by mastery stage), anti-duplication sweep. */
final class AkaiHud extends BukkitRunnable {
    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    private int run;

    AkaiHud(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    @Override public void run() {
        run++;
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.cutscene().isCaptured(p.getUniqueId())) continue;
            AkaiState st = m.state(p);
            ItemStack main = p.getInventory().getItemInMainHand();
            if (run % 20 == 0) m.weapon().sanitize(p);
            boolean holding = m.weapon().canUse(p, main);
            if (!holding) { st.wasHolding = false; continue; }
            AkaiData d = m.store().get(p.getUniqueId());
            d.name = p.getName();
            if (!d.owned) { d.owned = true; }
            if (!st.wasHolding) { st.wasHolding = true; AkaiFx.sound(plugin, p.getLocation(), "draw", 1.2f, 1.0f); AkaiFx.drawBurst(plugin, p); }
            if (st.lastActiveLoc == null || st.lastActiveLoc.getWorld() != p.getWorld() || st.lastActiveLoc.distanceSquared(p.getLocation()) > 9) { st.lastActiveLoc = p.getLocation().clone(); st.lastActiveMs = now; }
            st.prune(now);
            int stage = m.mastery().stage(d);
            if (m.settings().b("vfx.idle-aura", true) && run % 2 == 0) AkaiFx.idleAura(plugin, p, stage, run);
            if (stage >= 2 && run % 160 == 0) AkaiFx.sound(plugin, p.getLocation(), "idle", 0.35f, 1.0f);
            if (now >= st.msgUntil) p.sendActionBar(hud(p, st, d));
        }
    }

    private net.kyori.adventure.text.Component hud(Player p, AkaiState st, AkaiData d) {
        AkaiType t = AkaiType.ACTIVES[st.selected];
        long cd = m.cooldownMs(p, t);
        double cost = m.settings().cost(t);
        String status = cd > 0 ? "<red>" + String.format("%.1fs", cd / 1000.0) : d.energy < cost ? "<yellow>NEEDS " + (int) cost : "<green>READY";
        int n = (int) Math.round(Math.max(0, Math.min(1, d.energy / m.energy().max())) * 10);
        String bar = "<red>" + "\u25ae".repeat(n) + "<dark_gray>" + "\u25ae".repeat(10 - n);
        long ucd = m.cooldownMs(p, AkaiType.ULTIMATE);
        String ult = ucd > 0 ? "<red>THRONE " + (ucd / 1000) + "s" : d.energy >= m.settings().cost(AkaiType.ULTIMATE) ? "<gold><bold>THRONE READY" : "<dark_red>THRONE";
        return m.settings().mm("<dark_red><bold>AKAI NO \u014c</bold> <dark_gray>| " + bar + " <white>" + (int) d.energy + "<gray>/" + (int) m.energy().max()
            + " <dark_gray>| <red>" + (st.selected + 1) + ". " + t.display() + " " + status + " <dark_gray>| " + ult);
    }
}

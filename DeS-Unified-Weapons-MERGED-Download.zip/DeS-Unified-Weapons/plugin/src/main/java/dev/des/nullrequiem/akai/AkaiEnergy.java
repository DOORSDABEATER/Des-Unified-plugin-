package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

/** IMPERIAL ENERGY 0-100: server-authoritative, persisted, capped generation per cast, repeat-target damping. */
public final class AkaiEnergy {
    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    public AkaiEnergy(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    public double max() { return m.settings().d("energy.max", 100); }
    public double get(Player p) { return m.store().get(p.getUniqueId()).energy; }
    public void set(Player p, double v) { m.store().get(p.getUniqueId()).energy = Math.max(0, Math.min(max(), v)); }
    public void add(Player p, double a) { if (a > 0) set(p, get(p) + a); }

    public boolean spend(Player p, double a) {
        if (a <= 0) return true;
        if (get(p) + 1e-6 < a) return false;
        set(p, get(p) - a);
        return true;
    }

    public void onHit(AkaiCtx ctx, LivingEntity t) {
        AkaiSettings s = m.settings();
        double g = ctx.distinct() <= 1 ? s.d("energy.per-hit", 4) : s.d("energy.extra-target", 2);
        if (!(t instanceof Player) && !(t instanceof Monster)) g *= s.d("energy.passive-mob-multiplier", 0.4);
        long now = System.currentTimeMillis();
        Long last = ctx.state.energyRepeat.get(t.getUniqueId());
        if (last != null && now - last < s.d("energy.repeat-window-seconds", 8) * 1000) g *= s.d("energy.repeat-multiplier", 0.3);
        ctx.state.energyRepeat.put(t.getUniqueId(), now);
        g = Math.min(g, s.d("energy.max-per-cast", 12) - ctx.gained);
        if (g <= 0) return;
        ctx.gained += g;
        add(ctx.player, g);
    }

    public void onMelee(Player p, LivingEntity t) {
        AkaiSettings s = m.settings(); AkaiState st = m.state(p);
        double g = s.d("energy.melee-hit", 2);
        if (!(t instanceof Player) && !(t instanceof Monster)) g *= s.d("energy.passive-mob-multiplier", 0.4);
        long now = System.currentTimeMillis();
        Long last = st.energyRepeat.get(t.getUniqueId());
        if (last != null && now - last < s.d("energy.repeat-window-seconds", 8) * 1000) g *= s.d("energy.repeat-multiplier", 0.3);
        st.energyRepeat.put(t.getUniqueId(), now);
        add(p, g);
    }

    public void onKill(Player p, boolean decreed) { add(p, decreed ? m.settings().d("energy.decree-kill", 25) : m.settings().d("energy.kill", 10)); }

    /** Combo: hit-confirmed casts of different abilities inside the window chain; from the 3rd link each pays energy. */
    public void onCastHit(AkaiCtx ctx) {
        AkaiState st = ctx.state; long now = System.currentTimeMillis();
        if (now > st.chainUntil) { st.chain = 0; st.chainSet.clear(); }
        if (st.chainSet.add(ctx.type)) st.chain++; else { st.chain = 1; st.chainSet.clear(); st.chainSet.add(ctx.type); }
        st.chainUntil = now + (long) (m.settings().d("combos.window-seconds", 7) * 1000);
        if (st.chain >= 3) {
            int extra = Math.min(3, st.chain - 2);
            double e = m.settings().d("energy.combo-bonus", 8) * extra;
            add(ctx.player, e);
            m.mastery().addXp(ctx.player, (long) (m.settings().d("mastery.xp.combo", 15) * extra));
            ctx.player.sendActionBar(m.settings().mm("<dark_red>[AKAI NO \u014c] <red><bold>IMPERIAL COMBO x" + st.chain + "</bold> <gray>+" + (int) e + " energy"));
            st.msgUntil = now + 1200;
        }
    }
}

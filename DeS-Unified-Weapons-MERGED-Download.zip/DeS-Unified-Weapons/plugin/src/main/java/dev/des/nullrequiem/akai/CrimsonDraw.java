package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** 01 - instant draw, enormous horizontal crimson slash with lightning trail. */
final class CrimsonDraw extends AkaiBase {
    CrimsonDraw(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.CRIMSON_DRAW); }

    @Override public boolean execute(AkaiCtx ctx) {
        Player p = ctx.player;
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().clone(); dir.setY(dir.getY() * 0.35).normalize();
        Location start = eye.clone().add(dir.clone().multiply(1.4)).subtract(0, 0.35, 0);
        p.swingMainHand();
        snd(p.getLocation(), "a1_draw", 1.2f, 1.0f);
        AkaiFx.drawBurst(plugin, p);
        slash(ctx, start, dir, cfg("range", 16), cfg("speed", 1.5), cfg("hit-radius", 2.0), cfgI("pierce", 6), cfg("damage", 8), (float) cfg("scale", 3.6), UP, false, "a1_hit",
            end -> { AkaiFx.cross(plugin, end, dir.clone().crossProduct(UP), 1.4); snd(end, "a1_hit", 0.8f, 0.7f); });
        return true;
    }
}

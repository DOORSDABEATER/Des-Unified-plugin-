# AKAI NO Ō - THE CRIMSON SOVEREIGN (RIK's katana)
Integrated as the `dev.des.nullrequiem.akai` module of the unified plugin (shares TaskTracker, DamageService, Vfx, SoundManager,
CutsceneManager, CameraController) and the shared resource pack (namespace `akai`). No second plugin, no second pack.
**Integration note:** the real DeS unified project was never provided, so this was integrated into the unified plugin built in this session
(NULL//REQUIEM + shared infrastructure). NOISEFORM and NEBULUX do not exist in it. To port into your real project: copy the `akai` package,
`akai.yml`, `assets/akai/`, the `akai` command + permissions from `plugin.yml`, and the small shared patches listed in TESTING section below.

## Owner binding
- Bound by **UUID**: `akai.yml owner.uuid`. If empty, the first `/akai give RIK` stores that player's UUID in `akai-owner.yml`; after that only that UUID can ever be issued the weapon.
- Identity = PersistentDataContainer marker + owner UUID + registered serial (`akai-serials.yml`). Renamed swords, copies, unregistered serials and duplicated stacks are rejected/removed.
- Non-owners cannot use it, pick it up, or move it in inventories; copies in non-owner inventories are removed (`owner.confiscate-from-non-owners`). The katana cannot be dropped, so it cannot be traded by dropping. Binding lives in the item + files, so it survives restarts.
- Admin override only if `owner.override-enabled: true` AND the player has `akai.override`.

## Controls
Right-click cast selected | F next | Q previous | Shift+F THRONE OF BLOOD | Shift+scroll cycle | `/akai cast <n>` fallback.

## Passive - SOVEREIGN'S AUTHORITY
Every real hit adds a Sovereign Mark (max 5, 12 s, +5 %/stack). At 5: **ROYAL DECREE** - crimson sigil display above the target, ring + glyph aura, "decree" abilities deal x1.5, kills restore 25 energy (10 normally).

## Imperial Energy 0-100 (persisted per player)
Gain: +4 per ability hit (+2 extra targets, max 12/cast), +2 melee, +8 per combo link from the 3rd (hit-confirmed chain of different abilities within 7 s), +10 kill, +25 decreed kill. Repeat hits on the same target within 8 s pay 30 %. HUD shows energy bar, selected ability, cost/READY/cooldown, throne state. Energy is lost on death (configurable).

## Abilities (energy cost / cooldown)
| # | Ability | Cost/CD | Summary |
|---|---|---|---|
| 01 | CRIMSON DRAW | 0/5s | Instant draw, enormous horizontal slash, lightning trail, pierces 6 |
| 02 | DRAGONSTEP | 10/12s | 8-block dash (collision/floor/border safe), katana afterimages, damages crossed enemies, diagonal finishing strike |
| 03 | BLOOD MARK | 10/14s | Sigil above target, +25 % damage from Rik for 12 s, execution burst on defeat |
| 04 | IMPERIAL CROSS | 20/20s | Horizontal + vertical slash, cross-shaped impact, bonus vs ROYAL DECREE |
| 05 | SCARLET TEMPEST | 20/18s | 7 rotating-plane slashes (individual detection) + heavy final |
| 06 | DRAGON'S ROAR | 25/24s | Dragon model chain surges 18 blocks, area damage, detonation |
| 07 | KING'S DOMAIN | 30/40s | 10-block sigil battlefield 10 s, floating glyphs, configurable enemy debuffs / owner buffs, dramatic collapse |
| 08 | THOUSAND CUTS | 30/28s | 3 synchronized waves of 4 phantom slashes, then one concentrated strike |
| 09 | CRIMSON REVERSAL | 15/14s (6s on fail) | 1.2 s stance, -60 % damage on first eligible hit + explosive counter, energy refund; never invulnerable |
| 10 | SOVEREIGN'S JUDGEMENT | 40/30s | Tracking execution sigil that locks 0.7 s before impact (dodgeable), 22 dmg, +decree effect (Slowness) |
| 11 | HEAVEN SPLITTER | 40/36s | Raised katana, giant vertical cut, ground shockwaves along the path, final impact |
| 12 | DRAGON ASCENSION | 50/60s | 14-segment custom dragon circles Rik, dives on the aim point, detonation, dissolves into embers |
| U | THRONE OF BLOOD | 100/240s | 5-phase cinematic below |

## THRONE OF BLOOD
1 **Imperial Awakening (2.5 s)** katana rises, circle + sky embers + royal glyphs, title/chat warning, countdown, anyone can leave. 2 **Crimson Domain** only enemies inside `radius` (14) are captured (players via shared camera or FREEZE fallback; mobs optional; bosses damaged but never frozen); they get ROYAL DECREE marks. 3 **Dragon Emperor** colossal 16-segment dragon coils behind Rik, giant blade grows, camera focuses on Rik. 4 **Final Decree** damage applied exactly at impact tick (110/160) with execution visuals, dragon dives with the slash, explosion. 5 **Sovereign Remains** dragon -> embers, domain collapses, everyone released and restored. Safety: quit/death/world-change/shutdown handlers + `pending-restore.yml` crash recovery (shared CutsceneManager). Players outside the radius are never captured.

## Mastery (all objectives required per stage - configurable)
ROYAL HEIR (start) -> CRIMSON EMPEROR (1500 xp, 250 hits, 12 kills) -> ABSOLUTE SOVEREIGN (6000 xp, 1200 hits, 60 kills, 3 thrones, 8 decreed kills). Rewards: richer idle aura (gold embers, orbiting sparks), -5 %/-10 % cooldowns, final-stage broadcast. XP anti-farm: AFK check, dummies/AI-less mobs/armor stands excluded, per-target and same-victim cooldowns, hourly cap. Progress in `/akai mastery`.

## Commands (`/akai`, alias `/crimson`)
`give <player>` `remove <player>` `reload` (admin) | `stats [player]` `mastery [player]` `energy [player]` (owner or admin) | `reset <player>` `test <ability>` `ultimate <player>` (admin) | `cast <n|name>` `select <n>` `camera <on|off>` (owner).
Console works for give/remove/reload/reset/ultimate/stats <player>/energy <player>.

## Permissions
`akai.use` (default true; still needs owner binding), `akai.admin` (op), `akai.override` (false), `akai.immune` (never captured by the throne).

## Files
`plugins/NullRequiem/akai.yml` (all balance values), `akai-owner.yml`, `akai-serials.yml`, `akai-data/<uuid>.yml`. Pack: `assets/akai/` (8 models, 8-frame animated atlas, 48 synthesized sounds, lang). Nothing under `assets/nullrequiem/` was touched.

## Shared-infrastructure patches made for this module
`DamageService.damageRaw()` + `Tag.source`, `SoundManager`/`Vfx` accept `namespace:id`, `Vfx.arcCrescent` colour overload, plugin.yml command/permissions, plugin enable/disable hook. NULL//REQUIEM kill credit now ignores AKAI-tagged damage.

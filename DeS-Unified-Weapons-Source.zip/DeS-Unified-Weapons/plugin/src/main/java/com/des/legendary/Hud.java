package com.des.legendary;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

/** Action-bar feedback (selected ability, cooldown, energy) and the weapon auras / overdrive visuals. One task for all players. */
public final class Hud {
    private final LegendaryPlugin pl;
    private BukkitTask task;
    private int n;
    public Hud(LegendaryPlugin pl) { this.pl = pl; }

    public void start() { task = Bukkit.getScheduler().runTaskTimer(pl, this::tick, 10L, 4L); }
    public void stop() { if (task != null) task.cancel(); }

    private void tick() {
        n++;
        for (Player p : Bukkit.getOnlinePlayers()) {
            Weapon w = pl.items().weaponOf(p.getInventory().getItemInMainHand());
            if (w == null) continue;
            if (n % 2 == 0) render(p, w);
            aura(p, w);
        }
    }

    public void render(Player p, Weapon w) {
        PlayerData d = pl.data().get(p.getUniqueId()); PlayerData.WD x = d.of(w);
        int sel = Math.max(0, Math.min(x.selected, w.abilities().size() - 1));
        AbilityId a = w.abilities().get(sel);
        String c = w.color.asHexString();
        long now = System.currentTimeMillis();
        Long cd = d.cooldowns.get(a.key());
        String state = (cd != null && cd > now) ? "<red>" + String.format("%.1fs", (cd - now) / 1000.0) : "<green>READY";
        Long ucd = d.cooldowns.get(w.ultimate().key());
        String ult = x.energy >= 100 ? ((ucd != null && ucd > now) ? "<red>ULT " + String.format("%.0fs", (ucd - now) / 1000.0) : "<gold>\u2605 ULT READY") : "";
        int filled = (int) Math.round(x.energy / 10.0);
        String bar = "<" + c + ">" + "\u2588".repeat(Math.max(0, filled)) + "<dark_gray>" + "\u2588".repeat(Math.max(0, 10 - filled));
        String flags = (d.armed ? " <gold>\u2605ARMED" : "") + (x.energy >= 100 ? " <light_purple>" + (w == Weapon.NOISEFORM ? "OVERDRIVE" : "ASCENDED") : "")
                + (d.bonusUntil >= pl.casts().now() ? " <yellow>\u26A1STRIKE" : "") + (d.fracture != null && d.fracture.endTick >= pl.casts().now() ? " <aqua>\u21BA RECALL" : "");
        p.sendActionBar(MiniMessage.miniMessage().deserialize("<" + c + "><bold>" + a.display + " <gray>[" + (sel + 1) + "/" + w.abilities().size() + "] " + state
                + " <dark_gray>| " + bar + " <white>" + (int) x.energy + flags + (ult.isEmpty() ? "" : " <dark_gray>| " + ult)));
    }

    private void aura(Player p, Weapon w) {
        PlayerData d = pl.data().get(p.getUniqueId());
        int lv = pl.mastery().level(d, w);
        boolean over = d.of(w).energy >= 100;
        if (!over && lv < 5) return;
        long t = pl.casts().now();
        Location base = p.getLocation().add(0, 1.0, 0);
        double ang = t * 0.28;
        if (over) {   // overdrive / ascension: energy orbiting the blade hand
            for (int i = 0; i < 3; i++) {
                double a = ang + i * 2.094, r = 0.95;
                Location l = base.clone().add(Math.cos(a) * r, Math.sin(t * 0.15 + i) * 0.5, Math.sin(a) * r);
                if (w == Weapon.NOISEFORM) pl.fx().dust2(l, Pal.PURPLE, Pal.WHITE, 1.2f, 1, 0.02);
                else pl.fx().dust(l, Pal.rainbow(t * 0.03 + i / 3.0), 1.3f, 1, 0.02);
            }
        }
        if (lv >= 5 && (n % 3 == 0)) {   // mastery 5 aura, mastery 6 adds golden sparkles
            Location l = base.clone().add(Math.cos(-ang) * 0.7, -0.4 + (t % 40) * 0.03, Math.sin(-ang) * 0.7);
            if (w == Weapon.NOISEFORM) pl.fx().part(Particle.ELECTRIC_SPARK, l, 1, 0.05, 0.02); else pl.fx().part(Particle.END_ROD, l, 1, 0.05, 0.01);
            if (lv >= 6) pl.fx().dust(l.clone().add(0, 0.5, 0), Pal.GOLD, 0.9f, 1, 0.15);
        }
    }
}

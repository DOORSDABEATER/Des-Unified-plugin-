package com.des.legendary;

import org.bukkit.Location;
import org.bukkit.entity.Display;
import org.bukkit.entity.LivingEntity;

import java.util.*;
import java.util.function.Consumer;

/** Persistent + runtime state of one player. */
public final class PlayerData {
    public static final class WD {          // persistent per-weapon data
        public boolean owned;
        public double xp, energy;
        public int uses, hits, kills, selected;
        public final Map<String, Integer> abilityUses = new HashMap<>();
    }
    public static final class Guard {       // active Resonance Guard / Chromatic Refraction
        public Weapon w; public double reduction; public long endTick, perfectEnd; public boolean counterUsed;
        public double absorbEnergy; public Consumer<LivingEntity> perfect;
    }
    public static final class Fracture {    // Astral Fracture return window
        public Location origin; public long endTick; public Display rift; public int tier;
    }

    public final UUID id;
    public final EnumMap<Weapon, WD> w = new EnumMap<>(Weapon.class);
    public final Map<String, Long> cooldowns = new HashMap<>();   // ability key -> expiry (epoch ms); persisted so relogging cannot reset them
    // ---- runtime only ----
    public volatile long lastMove = System.currentTimeMillis();
    public long bonusUntil; public double bonusDmg; public boolean armed;
    public Guard guard; public Fracture fracture;
    public final ArrayDeque<long[]> seq = new ArrayDeque<>();     // combo tracker: {abilityOrdinal, tick}
    public long lastComboTick = -1000, lastHudTick, lastTrigger;
    public volatile boolean dirty;

    public PlayerData(UUID id) { this.id = id; for (Weapon x : Weapon.values()) w.put(x, new WD()); }
    public WD of(Weapon x) { return w.get(x); }
}

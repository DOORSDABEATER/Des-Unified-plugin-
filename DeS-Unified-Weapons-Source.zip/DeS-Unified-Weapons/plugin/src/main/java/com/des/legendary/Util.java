package com.des.legendary;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Small shared helpers for the ability classes. */
final class Util {
    private Util() {}

    /** Where the player is aiming (entities first, then blocks), snapped to the floor. Never null. */
    static Location aimPoint(LegendaryPlugin pl, Player p, double range) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();
        RayTraceResult rt = p.getWorld().rayTrace(eye, dir, range, FluidCollisionMode.NEVER, true, 0.5, e -> Targets.valid(pl, p, e));
        Location t = rt != null ? rt.getHitPosition().toLocation(p.getWorld()) : eye.clone().add(dir.clone().multiply(range));
        return ground(t);
    }

    /** Snap down to the floor (max 8 blocks) or up out of a block. Bounded loops. */
    static Location ground(Location t) {
        World w = t.getWorld();
        Location g = t.clone();
        for (int i = 0; i < 16 && g.getBlock().isPassable() && g.getY() > w.getMinHeight() + 1; i++) g.subtract(0, 0.5, 0);
        for (int i = 0; i < 40 && !g.getBlock().isPassable() && g.getY() < w.getMaxHeight() - 2; i++) g.add(0, 0.25, 0);
        return g;
    }

    static Vector flatDir(Player p) {
        Vector v = p.getLocation().getDirection().setY(0);
        return v.lengthSquared() < 1e-6 ? new Vector(0, 0, 1) : v.normalize();
    }
}

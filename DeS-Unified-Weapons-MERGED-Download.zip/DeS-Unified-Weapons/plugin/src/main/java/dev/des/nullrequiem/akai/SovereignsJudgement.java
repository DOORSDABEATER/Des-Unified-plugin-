package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.UUID;

/** 10 - execution sigil that tracks the target, then locks (telegraph/dodge window) before a powerful single-target slash. */
final class SovereignsJudgement extends AkaiBase {
    SovereignsJudgement(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.SOVEREIGNS_JUDGEMENT); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        final LivingEntity target = aimTarget(p, cfg("range", 28), cfg("cone-degrees", 25), true);
        if (target == null) { actionbar(p, "<red>SOVEREIGN'S JUDGEMENT <gray>- no target in sight"); return false; }
        ctx.maxHits = 1;
        final int charge = cfgI("charge-ticks", 34), lock = cfgI("lock-before-ticks", 14);
        final Location spot = Locs.ground(target.getLocation());
        final ItemDisplay sigil = vfx().display(id, spot.clone().add(0, 0.1, 0), "akai:sigil", new Vector3f(2.4f, 1f, 2.4f), new Quaternionf(), false, 2);
        final ItemDisplay blade = vfx().display(id, spot.clone().add(0, 9, 0), "akai:katana", new Vector3f(3.2f, 3.2f, 3.2f), Vfx.orient(new Vector(0, -1, 0), new Vector(1, 0, 0)), true, 2);
        p.swingMainHand();
        snd(spot, "a10_charge", 1.5f, 1.0f);
        actionbar(p, "<red>SOVEREIGN'S JUDGEMENT <gray>- the sigil will lock in " + (charge - lock) / 20.0 + "s");
        plugin.tasks().timer(id, 0, 1, charge + 1, t -> {
            if (!alive(p)) return false;
            if (t < charge - lock && target.isValid() && !target.isDead()) {
                Location g = Locs.ground(target.getLocation());
                spot.setX(g.getX()); spot.setY(g.getY()); spot.setZ(g.getZ());
            }
            boolean locked = t >= charge - lock;
            if (sigil != null && sigil.isValid()) { sigil.teleport(spot.clone().add(0, 0.1, 0)); if (t % 6 == 0) vfx().animate(sigil, new Vector3f(2.4f, 1f, 2.4f), new Quaternionf().rotateY(t * 0.2f), 6); }
            double f = t / (double) charge;
            if (blade != null && blade.isValid()) blade.teleport(spot.clone().add(0, 9 - 5 * f, 0));
            Vfx.Audience a = vfx().at(spot);
            vfx().ring(a, spot.clone().add(0, 0.15, 0), 2.3, 24, t * 0.3, locked ? AkaiFx.GOLD : AkaiFx.CRIM, 1.4f);
            vfx().column(a, spot, 3 + f * 6, 0.5 + f * 0.4, 8, AkaiFx.CRIM, 1.2f);
            a.dust(spot.clone().add(0, 4 + f * 2, 0), 4, 0.6, AkaiFx.PALE, 1.2f);
            return t < charge;
        }, () -> {
            if (blade != null) plugin.tasks().release(id, blade);
            if (sigil != null) plugin.tasks().release(id, sigil);
            if (!alive(p)) return;
            snd(spot, "a10_slash", 1.8f, 1.0f);
            for (LivingEntity e : enemies(p, spot.clone().add(0, 1, 0), 2.4)) if (m.marks().isDecreed(e)) plugin.tasks().later(id, 6, () -> plugin.damage().root(p, e, 60, 3, ctx.castId));
            Vector right = p.getLocation().getDirection().crossProduct(UP).normalize();
            slash(ctx, spot.clone().add(0, 5, 0), new Vector(0, -1, 0), 6.0, 1.7, 2.4, 0, cfg("damage", 22), 4.8f, right, true, "a10_slash",
                end -> { AkaiFx.executionBurst(plugin, end.clone().add(0, 1, 0)); AkaiFx.cross(plugin, end.clone().add(0, 1.2, 0), right, 2.6); shockRing(id, spot, 5, 8); });
        });
        return true;
    }
}

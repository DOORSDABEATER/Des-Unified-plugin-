package com.des.legendary;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/** /noiseform, /nebulux (give, reload) and /weapon (mastery, collection, ability, select, energy, reload). */
public final class Commands implements CommandExecutor, TabCompleter {
    private final LegendaryPlugin pl;
    public Commands(LegendaryPlugin pl) { this.pl = pl; }

    private void say(CommandSender s, String mini) { s.sendMessage(MiniMessage.miniMessage().deserialize(mini)); }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase();
        if (n.equals("noiseform")) return weaponCmd(s, Weapon.NOISEFORM, a);
        if (n.equals("nebulux")) return weaponCmd(s, Weapon.NEBULUX, a);
        return main(s, a);
    }

    private boolean weaponCmd(CommandSender s, Weapon w, String[] a) {
        if (a.length == 0) { say(s, "<gray>/" + w.key + " <give [player]|reload>"); return true; }
        switch (a[0].toLowerCase()) {
            case "give" -> {
                if (!s.hasPermission("des.legendary.give")) { say(s, "<red>No permission."); return true; }
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player p ? p : null);
                if (t == null) { say(s, "<red>Player not found."); return true; }
                ItemStack it = pl.items().weapon(w);
                for (ItemStack left : t.getInventory().addItem(it).values()) t.getWorld().dropItemNaturally(t.getLocation(), left);
                PlayerData d = pl.data().get(t.getUniqueId()); d.of(w).owned = true; d.dirty = true;
                say(s, "<green>Gave <" + w.color.asHexString() + ">" + w.display + "<green> to " + t.getName());
                if (t != s) say(t, "<" + w.color.asHexString() + "><bold>" + w.display + "<reset><gray> has been added to your inventory.");
            }
            case "reload" -> {
                if (!s.hasPermission("des.legendary.reload")) { say(s, "<red>No permission."); return true; }
                pl.reloadAll(); say(s, "<green>DeS Legendary configuration reloaded.");
            }
            default -> say(s, "<gray>/" + w.key + " <give [player]|reload>");
        }
        return true;
    }

    private boolean main(CommandSender s, String[] a) {
        if (a.length == 0) { say(s, "<gray>/weapon <mastery [player]|collection [player]|ability <name>|select <name|1-6>|energy <set|add> <player> <weapon> <n>|reload>"); return true; }
        switch (a[0].toLowerCase()) {
            case "mastery", "collection" -> {
                Player t = a.length > 1 ? Bukkit.getPlayerExact(a[1]) : (s instanceof Player p ? p : null);
                if (t == null) { say(s, "<red>Player not found."); return true; }
                boolean other = !(s instanceof Player p2) || !p2.getUniqueId().equals(t.getUniqueId());
                if (other && !s.hasPermission("des.legendary.others")) { say(s, "<red>No permission."); return true; }
                if (!s.hasPermission("des.legendary.collection")) { say(s, "<red>No permission."); return true; }
                if (a[0].equalsIgnoreCase("collection")) {
                    if (!(s instanceof Player v)) { say(s, "<red>Players only."); return true; }
                    pl.gui().open(v, t);
                } else mastery(s, t);
            }
            case "ability" -> {
                if (!(s instanceof Player p)) { say(s, "<red>Players only."); return true; }
                if (a.length < 2) { say(s, "<gray>/weapon ability <name>"); return true; }
                AbilityId id = AbilityId.byKey(a[1]);
                if (id == null) { say(s, "<red>Unknown ability."); return true; }
                pl.abilities().cast(p, id.weapon, id);
            }
            case "select" -> {
                if (!(s instanceof Player p)) { say(s, "<red>Players only."); return true; }
                Weapon w = pl.items().weaponOf(p.getInventory().getItemInMainHand());
                if (w == null || a.length < 2) { say(s, "<red>Hold a legendary weapon: /weapon select <name|1-6>"); return true; }
                int idx = -1;
                try { idx = Integer.parseInt(a[1]) - 1; } catch (NumberFormatException ex) { AbilityId id = AbilityId.byKey(a[1]); if (id != null) idx = w.abilities().indexOf(id); }
                if (idx < 0 || idx >= w.abilities().size()) { say(s, "<red>Unknown ability for " + w.display); return true; }
                PlayerData d = pl.data().get(p.getUniqueId()); d.of(w).selected = idx; d.dirty = true;
                pl.hud().render(p, w);
            }
            case "energy" -> {
                if (!s.hasPermission("des.legendary.admin")) { say(s, "<red>No permission."); return true; }
                if (a.length < 5) { say(s, "<gray>/weapon energy <set|add> <player> <noiseform|nebulux> <amount>"); return true; }
                Player t = Bukkit.getPlayerExact(a[2]); Weapon w = Weapon.byKey(a[3]);
                if (t == null || w == null) { say(s, "<red>Player or weapon not found."); return true; }
                double v; try { v = Double.parseDouble(a[4]); } catch (NumberFormatException ex) { say(s, "<red>Invalid number."); return true; }
                PlayerData d = pl.data().get(t.getUniqueId());
                if (a[1].equalsIgnoreCase("set")) { d.of(w).energy = Math.max(0, Math.min(100, v)); d.dirty = true; } else pl.energy().gain(t, w, v);
                say(s, "<green>" + t.getName() + " " + w.energyName + ": <white>" + (int) d.of(w).energy);
            }
            case "reload" -> {
                if (!s.hasPermission("des.legendary.reload")) { say(s, "<red>No permission."); return true; }
                pl.reloadAll(); say(s, "<green>DeS Legendary configuration reloaded.");
            }
            default -> say(s, "<red>Unknown sub-command.");
        }
        return true;
    }

    private void mastery(CommandSender s, Player t) {
        PlayerData d = pl.data().get(t.getUniqueId());
        say(s, "<gold><bold>" + t.getName() + " - Weapon Mastery");
        for (Weapon w : Weapon.values()) {
            PlayerData.WD x = d.of(w); int lv = pl.mastery().level(d, w); List<Double> th = pl.mastery().thresholds();
            double cur = th.get(lv - 1), next = lv >= 6 ? cur : th.get(lv);
            String c = w.color.asHexString();
            say(s, "<" + c + "><bold>" + w.display + " <white>L" + lv + " " + pl.mastery().levelName(lv) + (lv >= 6 ? " <gold>[" + pl.mastery().title(w, lv) + "]" : "")
                    + " " + CollectionGui.bar(lv >= 6 ? 1 : (x.xp - cur) / Math.max(1, next - cur), 20, c, "dark_gray") + " <gray>" + (lv >= 6 ? "MAX" : (int) x.xp + "/" + (int) next));
            say(s, "<gray>  casts <white>" + x.uses + " <gray>hits <white>" + x.hits + " <gray>kills <white>" + x.kills + " <gray>owned <white>" + (x.owned ? "yes" : "no"));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        String n = cmd.getName().toLowerCase();
        if (n.equals("noiseform") || n.equals("nebulux")) {
            if (a.length == 1) out.addAll(List.of("give", "reload"));
            else if (a.length == 2 && a[0].equalsIgnoreCase("give")) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else {
            if (a.length == 1) out.addAll(List.of("mastery", "collection", "ability", "select", "energy", "reload"));
            else if (a.length == 2 && (a[0].equalsIgnoreCase("ability") || a[0].equalsIgnoreCase("select"))) for (AbilityId id : AbilityId.values()) out.add(id.key());
            else if (a.length == 2 && (a[0].equalsIgnoreCase("mastery") || a[0].equalsIgnoreCase("collection"))) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
            else if (a[0].equalsIgnoreCase("energy")) {
                if (a.length == 2) out.addAll(List.of("set", "add")); else if (a.length == 3) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName())); else if (a.length == 4) out.addAll(List.of("noiseform", "nebulux"));
            }
        }
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase();
        return out.stream().filter(x -> x.toLowerCase().startsWith(last)).collect(Collectors.toList());
    }
}

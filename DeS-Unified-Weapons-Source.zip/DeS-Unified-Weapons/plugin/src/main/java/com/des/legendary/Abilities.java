package com.des.legendary;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.EnumMap;

/** Ability activation pipeline: permission/world/hold checks, cooldowns, energy spending, empower, handler dispatch, rollback on failure. */
public final class Abilities {
    public interface Handler { void cast(Ctx c); }

    private final LegendaryPlugin pl;
    private final EnumMap<AbilityId, Handler> reg = new EnumMap<>(AbilityId.class);

    public Abilities(LegendaryPlugin pl) { this.pl = pl; Noiseform.register(pl, reg); Nebulux.register(pl, reg); }

    private void bar(Player p, String mini) { p.sendActionBar(MiniMessage.miniMessage().deserialize(mini)); }

    public void cycle(Player p, Weapon w, int dir) {
        PlayerData d = pl.data().get(p.getUniqueId()); PlayerData.WD x = d.of(w);
        int n = w.abilities().size();
        x.selected = ((x.selected + dir) % n + n) % n; d.dirty = true;
        pl.sfx().to(p, "ui.select", 0.6f, 0.8f + 0.08f * x.selected);
        pl.hud().render(p, w);
    }

    public void castSelected(Player p, Weapon w) {
        PlayerData.WD x = pl.data().get(p.getUniqueId()).of(w);
        cast(p, w, w.abilities().get(Math.max(0, Math.min(x.selected, w.abilities().size() - 1))));
    }

    public void toggleEmpower(Player p, Weapon w) {
        PlayerData d = pl.data().get(p.getUniqueId());
        double cost = pl.cfg().d("energy.empower-cost", 50.0);
        if (d.of(w).energy < cost) { pl.sfx().to(p, "ui.deny", 0.7f, 1f); bar(p, "<red>Need " + (int) cost + " " + w.energyName + " to empower"); return; }
        d.armed = !d.armed;
        pl.sfx().to(p, "ui.select", 0.8f, d.armed ? 1.5f : 0.7f);
        bar(p, d.armed ? "<gold><bold>EMPOWER ARMED <gray>- next ability costs " + (int) cost : "<gray>Empower disarmed");
    }

    public void cast(Player p, Weapon w, AbilityId id) {
        if (!p.hasPermission("des.legendary.use")) return;
        PlayerData d = pl.data().get(p.getUniqueId()); PlayerData.WD x = d.of(w);
        if (pl.cfg().list("disabled-worlds").contains(p.getWorld().getName())) { bar(p, "<red>Legendary abilities are disabled in this world"); return; }
        if (pl.items().weaponOf(p.getInventory().getItemInMainHand()) != w) { bar(p, "<red>Hold " + w.display + " to use its abilities"); return; }
        if (id == AbilityId.ASTRAL_FRACTURE && d.fracture != null && pl.casts().now() <= d.fracture.endTick) { Nebulux.recall(pl, p, d); return; }

        long nowMs = System.currentTimeMillis();
        Long cd = d.cooldowns.get(id.key());
        if (cd != null && cd > nowMs) { pl.sfx().to(p, "ui.deny", 0.7f, 1f); bar(p, "<red>" + id.display + " <gray>cooldown: <white>" + String.format("%.1f", (cd - nowMs) / 1000.0) + "s"); return; }
        if (pl.casts().count(p.getUniqueId()) >= pl.cfg().i("limits.max-casts-per-player", 4)) { pl.sfx().to(p, "ui.deny", 0.7f, 1f); bar(p, "<red>Too many active effects"); return; }
        Handler h = reg.get(id);
        if (h == null) return;

        // ---- energy: exactly one spending action per activation (ultimate = 100, empowered ability = 50)
        double spent = 0; boolean empower = false;
        if (id.ultimate) {
            double cost = pl.cfg().d("energy.ultimate-cost", 100.0);
            if (x.energy < cost) { pl.sfx().to(p, "ui.deny", 0.7f, 1f); bar(p, "<red>" + id.display + " needs " + (int) cost + " " + w.energyName + " <gray>(" + (int) x.energy + ")"); return; }
            spent = cost;
        } else {
            double ec = pl.cfg().d("energy.empower-cost", 50.0);
            boolean want = d.armed || (pl.cfg().b("energy.auto-empower-at-full", true) && x.energy >= pl.energy().max());
            if (want && x.energy >= ec) { empower = true; spent = ec; d.armed = false; }
        }
        x.energy -= spent;

        Ctx c = new Ctx(pl, p, w, id, empower, pl.mastery().level(d, w));
        c.dmgMul = empower ? pl.cfg().d("energy.empower-damage-multiplier." + w.key, w == Weapon.NOISEFORM ? 1.25 : 1.10) : 1.0;
        c.maxTargets = (int) pl.cfg().x(id, "max-targets", pl.cfg().i("damage.max-targets", 8));
        c.refundEnergy = id.ultimate ? spent : 0;
        d.cooldowns.put(id.key(), nowMs + (long) (pl.cfg().cd(id) * 1000.0 * pl.cfg().d("cooldown-multiplier", 1.0)));

        try { h.cast(c); } catch (Throwable t) { pl.getLogger().warning("Ability " + id + " threw: " + t); c.fail("Ability error"); }
        if (c.failed) {                                            // roll everything back
            d.cooldowns.remove(id.key()); x.energy += spent; c.cleanup();
            pl.sfx().to(p, "ui.deny", 0.7f, 1f); bar(p, "<red>" + (c.failMsg.isEmpty() ? "Cannot cast " + id.display : c.failMsg));
            return;
        }
        x.uses++; x.abilityUses.merge(id.key(), 1, Integer::sum); d.dirty = true;
        if (empower) pl.sfx().to(p, "ui.empower", 0.9f, 1f);
        bar(p, "<" + w.color.asHexString() + "><bold>" + (empower ? "\u2605 EMPOWERED " : "\u2726 ") + id.display.toUpperCase());
    }
}

package com.des.legendary;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Flat-file YAML persistence (one small file per player). Disk writes happen off the main thread. */
public final class DataStore {
    private final LegendaryPlugin pl;
    private final File dir;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();

    public DataStore(LegendaryPlugin pl) {
        this.pl = pl; this.dir = new File(pl.getDataFolder(), "playerdata"); dir.mkdirs();
    }

    public PlayerData get(UUID id) { return cache.computeIfAbsent(id, this::load); }
    public PlayerData peek(UUID id) { return cache.get(id); }
    public void preload(UUID id) { cache.computeIfAbsent(id, this::load); }   // safe from the async pre-login thread

    private PlayerData load(UUID id) {
        PlayerData d = new PlayerData(id);
        File f = new File(dir, id + ".yml");
        if (!f.exists()) return d;
        try {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            for (Weapon w : Weapon.values()) {
                ConfigurationSection s = y.getConfigurationSection("weapons." + w.key);
                if (s == null) continue;
                PlayerData.WD x = d.of(w);
                x.owned = s.getBoolean("owned"); x.xp = s.getDouble("xp"); x.energy = s.getDouble("energy");
                x.uses = s.getInt("uses"); x.hits = s.getInt("hits"); x.kills = s.getInt("kills"); x.selected = s.getInt("selected");
                ConfigurationSection au = s.getConfigurationSection("ability-uses");
                if (au != null) for (String k : au.getKeys(false)) x.abilityUses.put(k, au.getInt(k));
            }
            ConfigurationSection cd = y.getConfigurationSection("cooldowns");
            if (cd != null) for (String k : cd.getKeys(false)) d.cooldowns.put(k, cd.getLong(k));
        } catch (Exception e) { pl.getLogger().warning("Could not read player data " + id + ": " + e.getMessage()); }
        return d;
    }

    private String serialize(PlayerData d) {
        YamlConfiguration y = new YamlConfiguration();
        for (Weapon w : Weapon.values()) {
            PlayerData.WD x = d.of(w); String p = "weapons." + w.key + ".";
            y.set(p + "owned", x.owned); y.set(p + "xp", x.xp); y.set(p + "energy", x.energy);
            y.set(p + "uses", x.uses); y.set(p + "hits", x.hits); y.set(p + "kills", x.kills); y.set(p + "selected", x.selected);
            for (Map.Entry<String, Integer> e : x.abilityUses.entrySet()) y.set(p + "ability-uses." + e.getKey(), e.getValue());
        }
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> e : d.cooldowns.entrySet()) if (e.getValue() > now) y.set("cooldowns." + e.getKey(), e.getValue());
        return y.saveToString();
    }

    private void write(UUID id, String data, boolean async) {
        File f = new File(dir, id + ".yml");
        Runnable r = () -> {
            try { Files.writeString(f.toPath(), data, StandardCharsets.UTF_8); }
            catch (Exception e) { pl.getLogger().warning("Could not save player data " + id + ": " + e.getMessage()); }
        };
        if (async && pl.isEnabled()) Bukkit.getScheduler().runTaskAsynchronously(pl, r); else r.run();
    }

    public void save(PlayerData d, boolean async) { d.dirty = false; write(d.id, serialize(d), async); }
    public void saveDirty() { for (PlayerData d : cache.values()) if (d.dirty) save(d, true); }
    public void saveAllNow() { for (PlayerData d : cache.values()) save(d, false); }
    public void unload(UUID id) { PlayerData d = cache.remove(id); if (d != null) save(d, true); }
}

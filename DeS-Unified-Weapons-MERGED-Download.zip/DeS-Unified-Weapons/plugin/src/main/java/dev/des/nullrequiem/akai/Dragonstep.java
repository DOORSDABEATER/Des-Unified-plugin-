package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** 02 - extremely fast short dash with katana afterimages, damages what it crosses, ends in a diagonal strike. */
final class Dragonstep extends AkaiBase {
    Dragonstep(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.DRAGONSTEP); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        final Location start = p.getLocation().clone();
        final Vector dir = p.getEyeLocation().getDirection().clone();
        dir.setY(Math.max(-0.3, Math.min(0.3, dir.getY()))).normalize();
        double max = cfg("distance", 8);
        Location last = start.clone();
        for (double d = 0.5; d <= max + 1e-6; d += 0.5) {
            Location c = start.clone().add(dir.clone().multiply(d));
            if (!Locs.standable(c)) break;      // blocks, lava, world border, void
            last = c;
        }
        while (last.distanceSquared(start) > 1.0 && !Locs.hasFloor(last, 5)) last.subtract(dir.clone().multiply(0.5));
        if (last.distanceSquared(start) < 1.0) { actionbar(p, "<red>DRAGONSTEP <gray>- no room to dash"); return false; }
        final Location end = last.clone();
        final Vector path = end.toVector().subtract(start.toVector());
        ctx.maxHits = 2;
        snd(start, "a2_step", 1.1f, 1.0f);
        Quaternionf q = Vfx.orient(dir, UP);
        for (int k = 0; k < 3; k++) { // crimson katana afterimages
            Location at = start.clone().add(path.clone().multiply(k / 3.0)).add(0, 1.2, 0);
            ItemDisplay d = vfx().display(id, at, "akai:katana", new Vector3f(1.5f, 1.5f, 1.5f), q, true, 0);
            if (d != null) {
                plugin.tasks().later(id, 2, () -> vfx().animate(d, new Vector3f(0.1f, 0.1f, 0.1f), q, 10));
                plugin.tasks().later(id, 14, () -> plugin.tasks().release(id, d));
            }
        }
        final int ticks = Math.max(2, cfgI("dash-ticks", 3));
        final Set<UUID> crossed = new HashSet<>();
        plugin.tasks().timer(id, 0, 1, ticks + 1, t -> {
            if (!alive(p)) return false;
            double f = (t + 1.0) / ticks;
            Location pt = start.clone().add(path.clone().multiply(f));
            pt.setYaw(p.getLocation().getYaw()); pt.setPitch(p.getLocation().getPitch());
            Location prev = p.getLocation().add(0, 1, 0);
            p.teleport(pt);
            p.setVelocity(new Vector(0, 0, 0));
            Vfx.Audience a = vfx().at(pt);
            AkaiFx.lightning(plugin, a, prev, pt.clone().add(0, 1, 0));
            vfx().column(a, pt, 1.8, 0.4, 5, AkaiFx.CRIM, 1.2f);
            a.dust(pt.clone().add(0, 1, 0), 6, 0.3, AkaiFx.GOLD, 1.0f);
            for (LivingEntity e : enemies(p, pt.clone().add(0, 1, 0), 1.8)) {
                if (!crossed.add(e.getUniqueId())) continue;
                if (ctx.hit(e, cfg("damage", 5), false)) AkaiFx.hitBurst(plugin, e.getLocation().add(0, 1, 0), false);
            }
            return t + 1 < ticks;
        }, () -> {
            if (!alive(p)) return;
            Vector right = dir.clone().crossProduct(UP).normalize();
            Vector hint = UP.clone().multiply(Math.cos(Math.PI / 4)).add(right.multiply(Math.sin(Math.PI / 4)));
            p.swingMainHand();
            snd(end, "a2_strike", 1.2f, 1.0f);
            slash(ctx, end.clone().add(0, 1.3, 0).add(dir.clone().multiply(1.2)), dir, 5.0, 1.4, 2.0, 0, cfg("strike-damage", 7), 3.2f, hint, false, "a2_strike", e -> AkaiFx.cross(plugin, e, dir.clone().crossProduct(UP), 1.0));
        });
        return true;
    }
}

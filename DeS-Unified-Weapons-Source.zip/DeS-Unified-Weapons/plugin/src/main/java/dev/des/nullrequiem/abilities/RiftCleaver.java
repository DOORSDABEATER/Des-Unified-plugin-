package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** ABILITY 1 - gigantic emerald crescent slash that pierces, fractures and leaves a dimensional tear. */
public final class RiftCleaver extends AbilityBase {
    public RiftCleaver(NullRequiemPlugin plugin) { super(plugin, AbilityType.RIFT_CLEAVER); }

    @Override
    public boolean execute(CastContext ctx) {
        Player p = ctx.player;
        ctx.maxHitsPerTarget = 1;
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().clone();
        dir.setY(dir.getY() * 0.35).normalize();
        Location start = eye.clone().add(dir.clone().multiply(1.3)).subtract(0, 0.35, 0);
        p.swingMainHand();
        sfx().play(p.getLocation(), Snd.A1_CAST, 1.1f, 1.0f);
        vfx().glitch(vfx().at(start), start);
        fireSlash(ctx, start, dir, cfg("range", 14), cfg("speed", 1.1), cfg("hit-radius", 1.9), cfgI("pierce", 5),
            cfg("damage", 7), (float) cfg("scale", 3.4), false, false, Snd.A1_HIT,
            end -> {
                tear(p.getUniqueId(), end.clone().subtract(dir.clone().multiply(0.6)), dir, 3.0f, 50);
                sfx().play(end, Snd.A1_HIT, 0.8f, 0.7f);
                for (var e : enemies(p, end, 2.6)) dmg().root(p, e, 25, 0, ctx.castId);
            });
        return true;
    }
}

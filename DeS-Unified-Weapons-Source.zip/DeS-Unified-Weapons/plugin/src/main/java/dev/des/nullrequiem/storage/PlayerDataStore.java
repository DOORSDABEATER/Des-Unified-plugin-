package dev.des.nullrequiem.storage;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/** YAML persistence. Snapshots are taken on the calling (main) thread, file IO may run async. */
public final class PlayerDataStore {
    private final NullRequiemPlugin plugin;
    private final File dir;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();

    public PlayerDataStore(NullRequiemPlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "playerdata");
        if (!dir.exists() && !dir.mkdirs()) plugin.getLogger().warning("Could not create playerdata directory");
    }

    public PlayerData get(UUID id) { return cache.computeIfAbsent(id, this::load); }
    public boolean isLoaded(UUID id) { return cache.containsKey(id); }

    private File file(UUID id) { return new File(dir, id + ".yml"); }

    private PlayerData load(UUID id) {
        PlayerData d = new PlayerData(id);
        File f = file(id);
        if (!f.exists()) return d;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        d.name = y.getString("name", "");
        d.owned = y.getBoolean("owned");
        d.obtainedAt = y.getLong("obtained-at");
        d.xp = y.getLong("xp");
        d.kills = y.getInt("kills");
        d.exposedKills = y.getInt("exposed-kills");
        d.hits = y.getInt("hits");
        d.casts = y.getInt("casts");
        d.ultimates = y.getInt("ultimates");
        d.ultimateCooldownUntil = y.getLong("ultimate-cooldown-until");
        d.cutsceneCamera = y.getBoolean("cutscene-camera", true);
        ConfigurationSection u = y.getConfigurationSection("uses");
        if (u != null) for (String k : u.getKeys(false)) d.uses.put(k, u.getInt(k));
        return d;
    }

    private YamlConfiguration snapshot(PlayerData d) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("name", d.name);
        y.set("owned", d.owned);
        y.set("obtained-at", d.obtainedAt);
        y.set("xp", d.xp);
        y.set("kills", d.kills);
        y.set("exposed-kills", d.exposedKills);
        y.set("hits", d.hits);
        y.set("casts", d.casts);
        y.set("ultimates", d.ultimates);
        y.set("ultimate-cooldown-until", d.ultimateCooldownUntil);
        y.set("cutscene-camera", d.cutsceneCamera);
        for (Map.Entry<String, Integer> e : d.uses.entrySet()) y.set("uses." + e.getKey(), e.getValue());
        return y;
    }

    public void saveSync(UUID id) {
        PlayerData d = cache.get(id);
        if (d == null) return;
        try { snapshot(d).save(file(id)); } catch (IOException ex) { plugin.getLogger().log(Level.WARNING, "save failed for " + id, ex); }
    }

    public void saveAllAsync() {
        for (PlayerData d : cache.values()) {
            YamlConfiguration y = snapshot(d);
            File f = file(d.uuid);
            Bukkit.getScheduler().runTaskAsynchronously(plugin.java(), () -> {
                try { y.save(f); } catch (IOException ex) { plugin.getLogger().log(Level.WARNING, "autosave failed for " + f.getName(), ex); }
            });
        }
    }

    public void saveAllSync() { for (UUID id : cache.keySet()) saveSync(id); }

    public void unload(UUID id) { cache.remove(id); }

    public void reset(UUID id) {
        cache.put(id, new PlayerData(id));
        saveSync(id);
    }
}

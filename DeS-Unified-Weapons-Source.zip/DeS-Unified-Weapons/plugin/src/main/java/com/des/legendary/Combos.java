package com.des.legendary;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;

import java.util.List;

/** Detects the four signature combos. They are bonuses only - no ability requires a combo to be used. */
public final class Combos {
    private record Combo(String name, Weapon w, AbilityId[] seq) {}
    private static final List<Combo> ALL = List.of(
            new Combo("Sonic Execution", Weapon.NOISEFORM, new AbilityId[]{AbilityId.STATIC_OVERDRIVE, AbilityId.SONIC_RUPTURE, AbilityId.FREQUENCY_BREAK}),
            new Combo("Echo Trap", Weapon.NOISEFORM, new AbilityId[]{AbilityId.DISSONANCE, AbilityId.ECHO_BLADES, AbilityId.FINAL_FREQUENCY}),
            new Combo("Celestial Execution", Weapon.NEBULUX, new AbilityId[]{AbilityId.GRAVITY_WELL, AbilityId.STARFALL, AbilityId.CELESTIAL_PIERCE}),
            new Combo("Dimensional Punishment", Weapon.NEBULUX, new AbilityId[]{AbilityId.ASTRAL_FRACTURE, AbilityId.CHROMATIC_REFRACTION, AbilityId.PRISMATIC_CLEAVE}));

    private final LegendaryPlugin pl;
    public Combos(LegendaryPlugin pl) { this.pl = pl; }

    /** Called when an ability cast lands its first hit. */
    public void landed(Ctx c) {
        PlayerData d = pl.data().get(c.p.getUniqueId());
        long now = pl.casts().now();
        long window = (long) ((pl.cfg().d("combos.window-seconds", 8.0) + (c.tier >= 4 ? 2.0 : 0.0)) * 20);   // mastery 4: +2s combo window
        while (!d.seq.isEmpty() && now - d.seq.peekFirst()[1] > window) d.seq.pollFirst();
        d.seq.addLast(new long[]{c.id.ordinal(), now});
        while (d.seq.size() > 4) d.seq.pollFirst();
        for (Combo cb : ALL) {
            if (cb.w != c.w || d.seq.size() < cb.seq.length) continue;
            Long[] arr = d.seq.stream().map(x -> x[0]).toArray(Long[]::new);
            boolean ok = true;
            for (int i = 0; i < cb.seq.length; i++) if (arr[arr.length - cb.seq.length + i] != cb.seq[i].ordinal()) { ok = false; break; }
            if (!ok) continue;
            d.seq.clear();
            if (now - d.lastComboTick < pl.cfg().i("combos.award-cooldown-ticks", 160)) return;
            d.lastComboTick = now;
            reward(c.p, c.w, cb);
            return;
        }
    }

    private void reward(Player p, Weapon w, Combo cb) {
        pl.energy().gain(p, w, pl.cfg().d("combos.energy", 10.0));
        pl.mastery().bonus(p, w, pl.cfg().d("combos.xp", 15.0));
        pl.sfx().to(p, "ui.combo", 1f, 1f);
        pl.fx().burst(p.getLocation().add(0, 1.2, 0), Pal.GOLD, Pal.WHITE, 30, 1.2);
        p.sendActionBar(MiniMessage.miniMessage().deserialize("<gold><bold>COMBO <white>" + cb.name.toUpperCase() + " <gray>(+" + (int) pl.cfg().d("combos.energy", 10.0) + " " + w.energyName + ")"));
    }
}

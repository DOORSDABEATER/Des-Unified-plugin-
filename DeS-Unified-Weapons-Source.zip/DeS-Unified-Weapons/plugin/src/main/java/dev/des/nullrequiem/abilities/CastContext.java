package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.combat.PlayerState;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** One ability activation. Tracks per-target hit limits and fragment generation for this cast. */
public final class CastContext {
    public final NullRequiemPlugin plugin;
    public final Player player;
    public final PlayerState state;
    public final AbilityType type;
    public final UUID castId = UUID.randomUUID();
    public double gained;
    public int maxHitsPerTarget = 1;
    private final Map<UUID, Integer> hits = new HashMap<>();
    private boolean first;

    public CastContext(NullRequiemPlugin plugin, Player player, PlayerState state, AbilityType type) {
        this.plugin = plugin; this.player = player; this.state = state; this.type = type;
    }

    public double cfg(String key, double def) { return plugin.settings().ab(type, key, def); }
    public int distinctHits() { return hits.size(); }
    public int hitCount(UUID id) { return hits.getOrDefault(id, 0); }
    public boolean hasHit(UUID id) { return hits.containsKey(id); }

    /** Applies damage through the central service; enforces the per-target hit limit; grants fracture/fragments/mastery. */
    public boolean hit(LivingEntity target, double raw, boolean exposedBonus) { return hit(target, raw, exposedBonus, 1.0); }

    public boolean hit(LivingEntity target, double raw, boolean exposedBonus, double mult) {
        int c = hits.getOrDefault(target.getUniqueId(), 0);
        if (c >= maxHitsPerTarget) return false;
        if (!plugin.damage().damage(player, target, raw, mult, exposedBonus)) return false;
        hits.put(target.getUniqueId(), c + 1);
        if (c == 0) {
            plugin.fracture().apply(player, target);
            plugin.fragments().onHit(this, target);
        }
        plugin.mastery().registerHit(player, type, target);
        plugin.data().get(player.getUniqueId()).hits++;
        if (!first) { first = true; plugin.combos().onCastHit(this); }
        return true;
    }

    public boolean hit(LivingEntity target, double raw) { return hit(target, raw, false); }
}

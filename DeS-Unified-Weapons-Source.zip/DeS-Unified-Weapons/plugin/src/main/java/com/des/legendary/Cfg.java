package com.des.legendary;

import org.bukkit.configuration.file.FileConfiguration;

/** Thin typed wrapper over config.yml. Every read has an in-code default, so a missing key never breaks anything. */
public final class Cfg {
    private final LegendaryPlugin pl;
    public Cfg(LegendaryPlugin pl) { this.pl = pl; }
    private FileConfiguration c() { return pl.getConfig(); }

    public double d(String p, double def) { return c().getDouble(p, def); }
    public int i(String p, int def) { return c().getInt(p, def); }
    public boolean b(String p, boolean def) { return c().getBoolean(p, def); }
    public String s(String p, String def) { return c().getString(p, def); }
    public java.util.List<String> list(String p) { return c().getStringList(p); }

    public String path(AbilityId id, String k) { return "weapons." + id.weapon.key + ".abilities." + id.key() + "." + k; }
    public double x(AbilityId id, String k, double def) { return d(path(id, k), def); }
    public double dmg(AbilityId id) { return x(id, "damage", id.dmg); }
    public double cd(AbilityId id) { return x(id, "cooldown", id.cd); }
    public int ticks(AbilityId id, String k, double defSeconds) { return (int) Math.round(x(id, k, defSeconds) * 20.0); }
}

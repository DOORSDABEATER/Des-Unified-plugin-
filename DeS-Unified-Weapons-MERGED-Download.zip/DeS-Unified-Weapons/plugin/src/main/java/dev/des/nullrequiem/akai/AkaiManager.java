package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.entity.Player;

import java.util.EnumMap;
import java.util.Map;

/** Validation, cost, cooldown and dispatch for AKAI abilities (all server-side). */
public final class AkaiManager {
    public enum Result { OK, NOT_HOLDING, DISABLED, COOLDOWN, NO_ENERGY, BUSY, FAILED }

    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    private final Map<AkaiType, AkaiAbility> map = new EnumMap<>(AkaiType.class);
    private final CrimsonReversal reversal;

    public AkaiManager(NullRequiemPlugin plugin, AkaiModule m) {
        this.plugin = plugin; this.m = m;
        reversal = new CrimsonReversal(plugin, m);
        reg(new CrimsonDraw(plugin, m)); reg(new Dragonstep(plugin, m)); reg(new BloodMark(plugin, m)); reg(new ImperialCross(plugin, m));
        reg(new ScarletTempest(plugin, m)); reg(new DragonsRoar(plugin, m)); reg(new KingsDomain(plugin, m)); reg(new ThousandCuts(plugin, m));
        reg(reversal); reg(new SovereignsJudgement(plugin, m)); reg(new HeavenSplitter(plugin, m)); reg(new DragonAscension(plugin, m));
        reg(new AkaiAbility() {
            @Override public AkaiType type() { return AkaiType.ULTIMATE; }
            @Override public boolean execute(AkaiCtx ctx) { return m.ultimate().start(ctx); }
        });
    }

    private void reg(AkaiAbility a) { map.put(a.type(), a); }
    public CrimsonReversal reversal() { return reversal; }

    public Result cast(Player p, AkaiType t, boolean forced) {
        AkaiSettings s = m.settings();
        if (!forced && !m.weapon().holdsUsable(p)) return Result.NOT_HOLDING;
        if (!s.enabled(t)) { feedback(p, "<red>" + t.display() + " <gray>is disabled"); return Result.DISABLED; }
        if (s.worldDisabled(p.getWorld())) { feedback(p, "<red>AKAI NO \u014c cannot be used in this world."); return Result.DISABLED; }
        if (plugin.cutscene().isCaptured(p.getUniqueId()) || p.isDead()) return Result.BUSY;
        AkaiState st = m.state(p);
        AkaiAbility ab = map.get(t);
        if (st.busy) return Result.BUSY;
        long cd = m.cooldownMs(p, t);
        if (!forced && cd > 0) {
            feedback(p, "<red>" + t.display() + " <gray>cooldown: <white>" + String.format("%.1fs", cd / 1000.0));
            AkaiFx.soundTo(plugin, p, "deny", 0.6f, 1.0f);
            return Result.COOLDOWN;
        }
        double cost = s.cost(t);
        if (!forced && m.energy().get(p) + 1e-6 < cost) {
            feedback(p, "<yellow>" + t.display() + " <gray>needs <white>" + (int) cost + " <gray>Imperial Energy (<white>" + (int) m.energy().get(p) + "<gray>)");
            AkaiFx.soundTo(plugin, p, "deny", 0.6f, 0.8f);
            return Result.NO_ENERGY;
        }
        AkaiCtx ctx = new AkaiCtx(plugin, m, p, st, t);
        boolean ok;
        try { ok = ab.execute(ctx); }
        catch (Throwable ex) { plugin.getLogger().log(java.util.logging.Level.SEVERE, "AKAI ability " + t + " failed", ex); ok = false; }
        if (!ok) return Result.FAILED;
        if (!forced) {
            if (cost > 0) m.energy().spend(p, cost);
            if (!ab.selfManagedCooldown()) m.setCooldown(p, t, s.cooldown(t) * m.mastery().cooldownFactor(p));
        }
        AkaiData d = m.store().get(p.getUniqueId());
        d.casts++;
        d.uses.merge(t.key(), 1, Integer::sum);
        return Result.OK;
    }

    private void feedback(Player p, String mm) {
        p.sendActionBar(m.settings().mm(mm));
        m.state(p).msgUntil = System.currentTimeMillis() + 1200;
    }

    public void select(Player p, int delta) { selectIndex(p, m.state(p).selected + delta); }

    public void selectIndex(Player p, int idx) {
        AkaiState st = m.state(p);
        st.selected = Math.floorMod(idx, AkaiType.ACTIVES.length);
        AkaiType t = AkaiType.ACTIVES[st.selected];
        feedback(p, "<dark_red>[<red>" + (st.selected + 1) + "/12<dark_red>] <red><bold>" + t.display() + "</bold> <gray>cost <white>" + (int) m.settings().cost(t));
        AkaiFx.soundTo(plugin, p, "mark", 0.4f, 1.0f + st.selected * 0.04f);
    }

    /** Death / quit / world change: stop everything this player has running. */
    public void abort(Player p) {
        plugin.tasks().cleanup(p.getUniqueId());
        AkaiState st = m.state(p);
        st.busy = false; st.stanceUntil = 0; st.stanceResolved = true;
        m.ultimate().abort(p.getUniqueId());
    }
}

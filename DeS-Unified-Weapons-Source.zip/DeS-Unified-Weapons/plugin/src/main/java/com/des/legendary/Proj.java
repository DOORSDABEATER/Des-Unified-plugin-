package com.des.legendary;

import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.function.Consumer;

/** Shared projectile stepping: block ray-cast + swept entity checks so fast projectiles never tunnel. */
public final class Proj {
    private Proj() {}

    /** Moves pos by dir*speed. Calls onEntity for every valid entity swept (radius). Returns true if a block stopped it (pos = impact point). */
    public static boolean advance(LegendaryPlugin pl, Ctx c, Location pos, Vector dir, double speed, double radius, Consumer<LivingEntity> onEntity) {
        RayTraceResult rt = pos.getWorld().rayTraceBlocks(pos, dir, speed, FluidCollisionMode.NEVER, true);
        double dist = rt != null ? pos.toVector().distance(rt.getHitPosition()) : speed;
        int steps = Math.max(1, (int) Math.ceil(dist / 0.7));
        for (int i = 1; i <= steps; i++) {
            Location q = pos.clone().add(dir.clone().multiply(dist * i / steps));
            for (LivingEntity e : Targets.sphere(pl, c.p, q, radius)) onEntity.accept(e);
        }
        pos.add(dir.clone().multiply(dist));
        return rt != null;
    }
}

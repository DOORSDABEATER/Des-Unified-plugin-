package dev.des.nullrequiem.weapons;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.combat.PlayerState;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.storage.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

/** One global task (every 5 ticks): action bar HUD, draw sound, idle aura, duplicate sanitising. */
public final class HudTask extends BukkitRunnable {
    private final NullRequiemPlugin plugin;
    private int run;

    public HudTask(NullRequiemPlugin plugin) { this.plugin = plugin; }

    @Override
    public void run() {
        run++;
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.cutscene().isCaptured(p.getUniqueId())) continue;
            PlayerState st = plugin.states().get(p);
            ItemStack main = p.getInventory().getItemInMainHand();
            boolean holding = plugin.weapons().canUse(p, main);
            if (run % 20 == 0 && plugin.weapons().hasMarker(main)) plugin.weapons().sanitize(p);
            if (!holding) { st.wasHolding = false; continue; }
            PlayerData d = plugin.data().get(p.getUniqueId());
            d.name = p.getName();
            if (!d.owned) { d.owned = true; d.obtainedAt = now; }
            if (!st.wasHolding) {
                st.wasHolding = true;
                plugin.sfx().play(p.getLocation(), Snd.DRAW, 1.1f, 1.0f);
                plugin.vfx().drawBurst(p);
            }
            if (st.lastActiveLoc == null || st.lastActiveLoc.getWorld() != p.getWorld() || st.lastActiveLoc.distanceSquared(p.getLocation()) > 9) {
                st.lastActiveLoc = p.getLocation().clone(); st.lastActiveMs = now;
            }
            st.prune(now);
            int stage = plugin.mastery().stage(p);
            if (plugin.settings().b("vfx.idle-aura", true) && run % 2 == 0) plugin.vfx().idleAura(p, stage, run);
            if (stage >= 2 && run % 160 == 0) plugin.sfx().play(p.getLocation(), Snd.IDLE, 0.35f, 1.0f);
            if (now >= st.msgUntil) p.sendActionBar(hud(p, st, stage));
        }
    }

    private net.kyori.adventure.text.Component hud(Player p, PlayerState st, int stage) {
        AbilityType t = AbilityType.ACTIVES[st.selected];
        long cd = plugin.cooldowns().remainingMs(p, t);
        double cost = plugin.settings().cost(t);
        String status;
        if (cd > 0) status = "<red>" + String.format("%.1fs", cd / 1000.0);
        else if (st.fragments < cost) status = "<yellow>NEEDS " + (int) cost;
        else status = "<green>READY";
        String ult;
        long ucd = plugin.cooldowns().remainingMs(p, AbilityType.ULTIMATE);
        if (ucd > 0) ult = "<red>404 " + (ucd / 1000) + "s";
        else if (st.fragments >= plugin.settings().cost(AbilityType.ULTIMATE)) ult = "<green><bold>404 READY";
        else ult = "<dark_green>404";
        String s = "<dark_green><bold>NULL//REQUIEM</bold> <dark_gray>| <green>REALITY: <white>" + (int) st.fragments + "<gray>/100"
            + " <dark_gray>| <green>" + (st.selected + 1) + ". " + t.display() + " " + status + " <dark_gray>| " + ult;
        return plugin.settings().raw(s);
    }
}

package com.des.legendary;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.*;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

/** All gameplay listeners: configurable controls, guard/refraction damage handling, melee bonus, kill credit, data lifecycle and cleanup. */
public final class Controls implements Listener {
    private static final Map<String, String> DEFAULTS = Map.of(
            "cast", "RIGHT_CLICK", "cycle-next", "SWAP_HAND", "cycle-previous", "SNEAK_SWAP_HAND",
            "ultimate", "SNEAK_RIGHT_CLICK", "empower-toggle", "SNEAK_LEFT_CLICK");
    private static final String[] ACTIONS = {"cast", "cycle-next", "cycle-previous", "ultimate", "empower-toggle"};

    private final LegendaryPlugin pl;
    public Controls(LegendaryPlugin pl) { this.pl = pl; }

    // ------------------------------------------------------------ controls
    /** Maps a physical trigger (RIGHT_CLICK, SNEAK_SWAP_HAND ...) to the configured action. Returns true when handled. */
    private boolean fire(Player p, Weapon w, String trig) {
        String act = null;
        for (String k : ACTIONS) if (trig.equalsIgnoreCase(pl.cfg().s("controls." + k, DEFAULTS.get(k)))) { act = k; break; }
        if (act == null) return false;
        PlayerData d = pl.data().get(p.getUniqueId());
        long now = pl.casts().now();
        if (now - d.lastTrigger < 3) return true;                    // swallow the duplicate interact events Minecraft fires
        d.lastTrigger = now;
        switch (act) {
            case "cast" -> pl.abilities().castSelected(p, w);
            case "cycle-next" -> pl.abilities().cycle(p, w, 1);
            case "cycle-previous" -> pl.abilities().cycle(p, w, -1);
            case "ultimate" -> pl.abilities().cast(p, w, w.ultimate());
            case "empower-toggle" -> pl.abilities().toggleEmpower(p, w);
            default -> { return false; }
        }
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        Weapon w = pl.items().weaponOf(p.getInventory().getItemInMainHand());
        if (w == null) return;
        Action a = e.getAction();
        String trig;
        if (a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK) {
            if (a == Action.RIGHT_CLICK_BLOCK && !p.isSneaking() && e.getClickedBlock() != null && e.getClickedBlock().getType().isInteractable()) return;   // never hijack chests/doors/buttons
            trig = p.isSneaking() ? "SNEAK_RIGHT_CLICK" : "RIGHT_CLICK";
        } else if (a == Action.LEFT_CLICK_AIR) trig = p.isSneaking() ? "SNEAK_LEFT_CLICK" : "LEFT_CLICK";
        else return;
        if (fire(p, w, trig)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Weapon w = pl.items().weaponOf(e.getOffHandItem()), w2 = pl.items().weaponOf(e.getMainHandItem());
        if (w == null && w2 == null) return;
        e.setCancelled(true);                                         // the weapon never leaves the main hand by accident
        if (w != null) fire(e.getPlayer(), w, e.getPlayer().isSneaking() ? "SNEAK_SWAP_HAND" : "SWAP_HAND");
    }

    // ------------------------------------------------------------ guard / refraction / melee bonus
    private static LivingEntity attacker(EntityDamageEvent e) {
        if (e instanceof EntityDamageByEntityEvent be) {
            Entity dm = be.getDamager();
            if (dm instanceof Projectile pr && pr.getShooter() instanceof LivingEntity ls) return ls;
            if (dm instanceof LivingEntity le) return le;
        }
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        PlayerData d = pl.data().peek(p.getUniqueId());
        if (d == null || d.guard == null) return;
        PlayerData.Guard g = d.guard; long now = pl.casts().now();
        if (now > g.endTick) { d.guard = null; return; }
        double before = e.getDamage();
        if (before <= 0) return;
        e.setDamage(before * (1.0 - g.reduction));                    // 40% (Resonance Guard) / 35% (Chromatic Refraction)
        double absorbed = before * g.reduction;
        pl.sfx().play(p.getLocation(), g.w == Weapon.NOISEFORM ? "noiseform.guard_hit" : "nebulux.refraction_hit", 0.8f, 1f);
        pl.fx().sphere(p.getLocation().add(0, 1, 0), 1.6, 16, g.w == Weapon.NOISEFORM ? Pal.PURPLE : Pal.CYAN, Pal.WHITE, 1.2f);
        if (g.w == Weapon.NOISEFORM) pl.energy().absorb(p, g, absorbed);
        else if (!g.counterUsed && now <= g.perfectEnd && g.perfect != null) {   // timing reward: only hits inside the first second counter
            LivingEntity att = attacker(e);
            if (att != null) { g.counterUsed = true; g.perfect.accept(att); }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (Dmg.active || e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity t)) return;
        Weapon w = pl.items().weaponOf(p.getInventory().getItemInMainHand());
        if (w == null) return;
        PlayerData d = pl.data().get(p.getUniqueId());
        if (w == Weapon.NOISEFORM && d.bonusUntil >= pl.casts().now()) {                  // Static Overdrive: next sword hit within 3s
            d.bonusUntil = 0;
            e.setDamage(e.getDamage() + d.bonusDmg);
            pl.sfx().play(t.getLocation(), "noiseform.rupture_hit", 1f, 0.8f);
            pl.fx().burst(t.getBoundingBox().getCenter().toLocation(t.getWorld()), Pal.PURPLE, Pal.WHITE, 30, 1.2);
            if (pl.mastery().eligible(p, t)) pl.energy().gain(p, w, pl.cfg().d("energy.empowered-strike", 6.0));
        }
        pl.mastery().onMelee(p, w, t);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent e) {
        LivingEntity v = e.getEntity();
        java.util.UUID att = pl.dmg().lastAttacker(v.getUniqueId(), pl.casts().now());
        Player killer = att != null ? Bukkit.getPlayer(att) : v.getKiller();
        if (killer != null && !killer.getUniqueId().equals(v.getUniqueId())) pl.mastery().onKill(killer, v, att != null ? pl.dmg().lastAbility(v.getUniqueId()) : null);
        pl.dmg().forget(v.getUniqueId());
    }

    // ------------------------------------------------------------ lifecycle / cleanup
    @EventHandler public void onPreLogin(AsyncPlayerPreLoginEvent e) { pl.data().preload(e.getUniqueId()); }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        PlayerData d = pl.data().get(p.getUniqueId());
        d.lastMove = System.currentTimeMillis();
        markOwned(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        pl.casts().cancel(p.getUniqueId(), true);
        PlayerData d = pl.data().peek(p.getUniqueId());
        if (d != null) { d.guard = null; d.fracture = null; d.armed = false; d.bonusUntil = 0; d.seq.clear(); }
        p.setGravity(true);
        pl.energy().forget(p.getUniqueId()); pl.mastery().forget(p.getUniqueId()); pl.dmg().forget(p.getUniqueId());
        pl.data().unload(p.getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        pl.casts().cancel(p.getUniqueId(), false);
        PlayerData d = pl.data().peek(p.getUniqueId());
        if (d != null) { d.guard = null; d.fracture = null; d.armed = false; d.bonusUntil = 0; d.seq.clear(); }
        p.setGravity(true);
    }

    @EventHandler
    public void onWorld(PlayerChangedWorldEvent e) {
        pl.casts().cancel(e.getPlayer().getUniqueId(), true);
        PlayerData d = pl.data().peek(e.getPlayer().getUniqueId());
        if (d != null) { d.guard = null; d.fracture = null; }
        e.getPlayer().setGravity(true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && pl.items().weaponOf(e.getItem().getItemStack()) != null) Bukkit.getScheduler().runTask(pl, () -> markOwned(p));
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedPosition()) return;
        PlayerData d = pl.data().peek(e.getPlayer().getUniqueId());
        if (d != null) d.lastMove = System.currentTimeMillis();
    }

    /** Safety net: display entities are non-persistent, but purge any tagged leftovers (crash recovery) when chunks load. */
    @EventHandler
    public void onEntities(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) if (en.getScoreboardTags().contains(Fx.TAG)) en.remove();
    }

    public void markOwned(Player p) {
        PlayerData d = pl.data().get(p.getUniqueId());
        for (ItemStack it : p.getInventory().getContents()) {
            Weapon w = pl.items().weaponOf(it);
            if (w != null && !d.of(w).owned) { d.of(w).owned = true; d.dirty = true; }
        }
    }
}

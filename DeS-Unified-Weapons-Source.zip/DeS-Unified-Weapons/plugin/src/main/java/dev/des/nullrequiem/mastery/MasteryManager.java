package dev.des.nullrequiem.mastery;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.combat.PlayerState;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.storage.PlayerData;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.List;

/**
 * Mastery: STAGE I UNSTABLE / II CORRUPTED / III ABSOLUTE ERROR. Rewards are cosmetic (visuals, title) - no raw power.
 * XP is only granted for real hits and is protected against AFK farming, dummy farming and same-target farming.
 */
public final class MasteryManager {
    public static final String[] NAMES = {"UNSTABLE", "CORRUPTED", "ABSOLUTE ERROR"};
    private final NullRequiemPlugin plugin;

    public MasteryManager(NullRequiemPlugin plugin) { this.plugin = plugin; }

    private long[] thresholds() {
        List<Integer> l = plugin.getConfig().getIntegerList("mastery.stage-xp");
        if (l.size() < 3) return new long[]{0, 1500, 6000};
        return new long[]{l.get(0), l.get(1), l.get(2)};
    }

    public int stageFor(long xp) {
        long[] t = thresholds();
        int s = 1;
        for (int i = 1; i < t.length; i++) if (xp >= t[i]) s = i + 1;
        return s;
    }

    public int stage(Player p) { return stageFor(plugin.data().get(p.getUniqueId()).xp); }
    public int stage(long xp) { return stageFor(xp); }
    public String stageName(int stage) { return NAMES[Math.max(1, Math.min(3, stage)) - 1]; }
    public String title(int stage) { return stage >= 3 ? plugin.settings().s("mastery.title", "The Last Error in Reality") : ""; }

    public long nextThreshold(int stage) {
        long[] t = thresholds();
        return stage >= 3 ? t[2] : t[stage];
    }

    public void addXp(Player p, long amount) {
        if (amount <= 0) return;
        PlayerData d = plugin.data().get(p.getUniqueId());
        int before = stageFor(d.xp);
        d.xp += amount;
        int after = stageFor(d.xp);
        if (after > before) announce(p, after);
    }

    public void setXp(Player p, long xp) {
        PlayerData d = plugin.data().get(p.getUniqueId());
        int before = stageFor(d.xp);
        d.xp = Math.max(0, xp);
        int after = stageFor(d.xp);
        if (after > before) announce(p, after);
    }

    private void announce(Player p, int stage) {
        Settings s = plugin.settings();
        p.showTitle(Title.title(s.raw("<green><bold>STAGE " + roman(stage) + "</bold>"), s.raw("<dark_green>" + stageName(stage)),
            Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2200), Duration.ofMillis(600))));
        p.sendMessage(s.msg("mastery-up", "<green>MASTERY ADVANCED: <white>STAGE {stage} - {name}", "stage", roman(stage), "name", stageName(stage)));
        plugin.sfx().playTo(p, Snd.MASTERY, 1.0f, 1.0f);
        plugin.vfx().killEffect(p.getLocation());
        if (stage >= 3 && s.b("mastery.broadcast-final-stage", true)) {
            Bukkit.broadcast(s.raw("<dark_green>[NULL//REQUIEM] <green>" + p.getName() + " <gray>has reached <green><bold>ABSOLUTE ERROR</bold><gray>. <dark_green>" + title(3)));
        }
    }

    private String roman(int s) { return s == 1 ? "I" : s == 2 ? "II" : "III"; }

    /** True when the target can never grant mastery XP (dummies, AI-less mobs, armor stands, tagged targets). */
    private boolean isDummy(LivingEntity t) {
        if (t instanceof ArmorStand) return true;
        if (t.getScoreboardTags().contains("nullrequiem_dummy") || t.getScoreboardTags().contains("dummy")) return true;
        if (t instanceof Mob m && !m.hasAI()) return true;
        if (t.customName() != null) {
            String n = PlainTextComponentSerializer.plainText().serialize(t.customName()).toLowerCase();
            for (String k : plugin.settings().list("mastery.dummy-name-contains")) if (!k.isEmpty() && n.contains(k.toLowerCase())) return true;
        }
        return false;
    }

    public void registerHit(Player p, AbilityType type, LivingEntity target) {
        Settings s = plugin.settings();
        if (isDummy(target)) return;
        PlayerState st = plugin.states().get(p);
        long now = System.currentTimeMillis();
        if (now - st.lastActiveMs > s.d("mastery.afk-seconds", 90) * 1000) return;
        boolean pl = target instanceof Player;
        long cd = (long) ((pl ? s.d("mastery.xp.player-target-cooldown-seconds", 45) : s.d("mastery.xp.mob-target-cooldown-seconds", 8)) * 1000);
        Long last = st.xpRepeat.get(target.getUniqueId());
        if (last != null && now - last < cd) return;
        st.xpRepeat.put(target.getUniqueId(), now);
        if (now - st.xpWindowStart > 3_600_000L) { st.xpWindowStart = now; st.xpWindow = 0; }
        int cap = s.i("mastery.xp.hourly-cap", 700);
        double xp = pl ? s.d("mastery.xp.player-hit", 12) : target instanceof Monster ? s.d("mastery.xp.monster-hit", 4) : s.d("mastery.xp.other-hit", 1);
        if (type.isUltimate()) xp *= 2;
        int give = (int) Math.min(xp, Math.max(0, cap - st.xpWindow));
        if (give <= 0) return;
        st.xpWindow += give;
        addXp(p, give);
    }

    public void registerKill(Player p, LivingEntity victim, boolean exposed) {
        Settings s = plugin.settings();
        if (isDummy(victim)) return;
        PlayerState st = plugin.states().get(p);
        long now = System.currentTimeMillis();
        Long last = st.killRepeat.get(victim.getUniqueId());
        st.killRepeat.put(victim.getUniqueId(), now);
        if (last != null && now - last < s.d("mastery.xp.same-victim-kill-cooldown-seconds", 600) * 1000) return;
        if (now - st.lastActiveMs > s.d("mastery.afk-seconds", 90) * 1000) return;
        addXp(p, (long) (victim instanceof Player ? s.d("mastery.xp.player-kill", 40) : s.d("mastery.xp.mob-kill", 5)) + (exposed ? 10 : 0));
    }
}

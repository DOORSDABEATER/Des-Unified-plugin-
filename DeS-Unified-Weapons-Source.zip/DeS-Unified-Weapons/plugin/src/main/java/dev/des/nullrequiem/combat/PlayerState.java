package dev.des.nullrequiem.combat;

import org.bukkit.Location;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import dev.des.nullrequiem.abilities.AbilityType;

/** Transient (not persisted) per-player combat state. */
public final class PlayerState {
    public int selected = 0;
    public double fragments;
    public boolean busy;
    public boolean wasHolding;
    public long lastClickMs;
    public long msgUntil;
    public Location lastActiveLoc;
    public long lastActiveMs = System.currentTimeMillis();
    public final Map<UUID, Long> fragRepeat = new HashMap<>();
    public final Map<UUID, Long> xpRepeat = new HashMap<>();
    public long xpWindowStart;
    public int xpWindow;
    public int chain;
    public long chainUntil;
    public final Set<AbilityType> chainSet = new HashSet<>();
    public long lastKillMs;
    public final Map<UUID, Long> killRepeat = new HashMap<>();

    public void prune(long now) {
        if (fragRepeat.size() > 64) fragRepeat.values().removeIf(t -> now - t > 60_000);
        if (xpRepeat.size() > 64) xpRepeat.values().removeIf(t -> now - t > 120_000);
        if (killRepeat.size() > 64) killRepeat.values().removeIf(t -> now - t > 600_000);
    }
}

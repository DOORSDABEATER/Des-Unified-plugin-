package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** 04 - two intersecting enormous slashes (horizontal + vertical); cross-shaped impact; bonus vs ROYAL DECREE. */
final class ImperialCross extends AkaiBase {
    ImperialCross(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.IMPERIAL_CROSS); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player;
        ctx.maxHits = 2;
        p.swingMainHand();
        snd(p.getLocation(), "a4_cross", 1.2f, 1.0f);
        plugin.tasks().timer(p.getUniqueId(), 0, 1, cfgI("windup-ticks", 8), t -> {
            Location top = p.getLocation().add(0, 2.2, 0);
            Vfx.Audience a = vfx().at(top);
            vfx().tiltedRing(a, top, new Vector(0, 1, 0), 0.9, 10, t * 0.5, AkaiFx.CRIM, 1.1f);
            a.dust(top, 3, 0.3, AkaiFx.GOLD, 1.0f);
            return alive(p);
        }, () -> {
            if (!alive(p)) return;
            Location eye = p.getEyeLocation();
            Vector dir = eye.getDirection().clone(); dir.setY(dir.getY() * 0.3).normalize();
            Location start = eye.clone().add(dir.clone().multiply(1.6)).subtract(0, 0.2, 0);
            Vector right = dir.clone().crossProduct(UP).normalize();
            double dmg = cfg("damage", 9);
            slash(ctx, start, dir, cfg("range", 14), 1.3, 2.4, 0, dmg, 4.2f, UP, true, "a4_impact", null);
            slash(ctx, start, dir, cfg("range", 14), 1.3, 2.4, 0, dmg, 4.2f, right, true, "a4_impact", end -> {
                AkaiFx.cross(plugin, end, right, 3.5);
                AkaiFx.sphereBurst(plugin, end, 1.5);
                snd(end, "a4_impact", 1.4f, 1.0f);
            });
        });
        return true;
    }
}

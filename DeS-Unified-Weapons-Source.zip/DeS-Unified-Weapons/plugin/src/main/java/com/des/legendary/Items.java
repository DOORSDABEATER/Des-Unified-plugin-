package com.des.legendary;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

/** Creates / identifies the weapons. They are NETHERITE_SWORDs carrying the custom item_model "des:noiseform" / "des:nebulux". */
public final class Items {
    private final LegendaryPlugin pl;
    public final NamespacedKey KEY;
    private final Map<String, ItemStack> fxCache = new HashMap<>();
    private final EnumMap<Weapon, ItemStack> display = new EnumMap<>(Weapon.class);

    public Items(LegendaryPlugin pl) { this.pl = pl; this.KEY = new NamespacedKey(pl, "legendary_weapon"); }

    public void clearCaches() { fxCache.clear(); display.clear(); }

    private static Component plain(String mini) { return MiniMessage.miniMessage().deserialize(mini).decoration(TextDecoration.ITALIC, false); }

    public ItemStack weapon(Weapon w) {
        ItemStack it = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta m = it.getItemMeta();
        m.setItemModel(NamespacedKey.fromString("des:" + w.key));
        m.displayName(Component.text(w.display, w.color, TextDecoration.BOLD).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(w.rarity, NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Combat style: " + w.style, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        for (String line : pl.getConfig().getStringList("weapons." + w.key + ".lore")) lore.add(plain(line));
        lore.add(Component.empty());
        for (AbilityId a : w.abilities()) lore.add(Component.text("\u25B8 " + a.display, w.color).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("\u2605 " + w.ultimate().display + " (ultimate)", NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(plain("<gray>Swap-hand: next ability  |  Right-click: cast"));
        lore.add(plain("<gray>Sneak + Right-click: ultimate (100 " + w.energyName + ")"));
        m.lore(lore);
        m.setUnbreakable(true);
        m.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        double melee = pl.cfg().d("weapons." + w.key + ".melee-damage", 9.0), speed = pl.cfg().d("weapons." + w.key + ".attack-speed", w == Weapon.NOISEFORM ? 1.6 : 1.4);
        m.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(new NamespacedKey(pl, "melee_" + w.key), melee - 1.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        m.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(new NamespacedKey(pl, "speed_" + w.key), speed - 4.0, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        m.getPersistentDataContainer().set(KEY, PersistentDataType.STRING, w.key);
        it.setItemMeta(m);
        return it;
    }

    /** Cached stack used by the floating sword displays (Echo Blades etc.). */
    public ItemStack displayStack(Weapon w) { return display.computeIfAbsent(w, this::weapon); }

    public Weapon weaponOf(ItemStack s) {
        if (s == null || s.getType() != Material.NETHERITE_SWORD || !s.hasItemMeta()) return null;
        String v = s.getItemMeta().getPersistentDataContainer().get(KEY, PersistentDataType.STRING);
        return v == null ? null : Weapon.byKey(v);
    }

    /** Flat FX sprite item (item_model des:fx/<name>). */
    public ItemStack fx(String name) {
        return fxCache.computeIfAbsent(name, n -> {
            ItemStack it = new ItemStack(Material.PAPER);
            ItemMeta m = it.getItemMeta();
            m.setItemModel(NamespacedKey.fromString("des:fx/" + n));
            it.setItemMeta(m);
            return it;
        });
    }
}

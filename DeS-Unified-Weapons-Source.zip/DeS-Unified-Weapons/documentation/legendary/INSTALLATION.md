# Installation

## 0. Check two numbers (Stage 1 compatibility)
Edit `plugin/gradle.properties` to match your server (`/version`): `javaVersion` (Minecraft 26.x needs a very recent Java)
and `paperVersion` (Paper API build, e.g. `26.2.build.+`). The plugin uses only stable Paper API: display entities
(1.19.4+), `item_model` (1.21.2+), `ItemMeta#setItemModel`. `plugin.yml` uses `api-version: '1.21'` so it loads on newer servers.

## 1. Build the JAR (pick one)
* **No local tools:** create a GitHub repo, upload this whole folder, open *Actions -> Build plugin -> Run*. Download artifact `DeS-Legendary-jar`.
* **Local:** install a JDK matching `javaVersion` + Gradle, then `cd plugin && gradle build` -> `plugin/build/libs/DeS-Legendary-1.0.0.jar`.
If the compiler reports a Paper API name that does not exist on your exact build, the fix is a one-word rename (see RESOURCEPACK.md "API notes").

## 2. Install
1. Put the JAR in `plugins/`, start the server once, stop it.
2. Edit `plugins/DeSLegendary/config.yml` if you want (all damage / cooldowns / limits are there), `/noiseform reload` applies changes.
3. Host `DeS-Legendary-ResourcePack.zip` (any direct-download URL) and set it in `server.properties`:
   `resource-pack=<url>`, `resource-pack-sha1=<sha1 of the zip>` (`sha1sum DeS-Legendary-ResourcePack.zip`), `require-resource-pack=true`.
   The pack only adds the `des` namespace, so it can sit alongside your existing pack (put it ABOVE your current pack if you merge them as separate packs, or copy `assets/des` into your pack).
4. If the client says the pack is for another version, rebuild it with the numbers shown, e.g.
   `PACK_MIN=<n> PACK_MAX=<n> python3 tools/build_resourcepack.py` (or copy the `pack` block from your existing working `pack.mcmeta`).

## 3. Give yourself the weapons
`/noiseform give` and `/nebulux give` (permission `des.legendary.give`, op by default). Hold one: swap-hand (F) cycles abilities, right-click casts, sneak+right-click = ultimate.

## Upgrading / uninstalling
Player data lives in `plugins/DeSLegendary/playerdata/<uuid>.yml`. Remove the JAR to uninstall; display entities are non-persistent and tagged `des_fx`, so nothing is left in the world.

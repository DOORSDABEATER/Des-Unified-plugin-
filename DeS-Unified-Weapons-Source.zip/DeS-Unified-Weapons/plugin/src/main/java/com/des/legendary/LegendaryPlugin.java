package com.des.legendary;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.plugin.java.JavaPlugin;

/** DeS Legendary - NOISEFORM & NEBULUX. Wires every subsystem together. */
public final class LegendaryPlugin extends JavaPlugin {
    private Cfg cfg; private Items items; private Sfx sfx; private Fx fx; private CastManager casts; private Dmg dmg; private Cc cc;
    private Energy energy; private Mastery mastery; private Combos combos; private DataStore data; private Abilities abilities; private Hud hud;
    private CollectionGui gui; private Controls controls; private NullRequiemPlugin nullRequiem;

    public Cfg cfg() { return cfg; } public Items items() { return items; } public Sfx sfx() { return sfx; } public Fx fx() { return fx; }
    public CastManager casts() { return casts; } public Dmg dmg() { return dmg; } public Cc cc() { return cc; } public Energy energy() { return energy; }
    public Mastery mastery() { return mastery; } public Combos combos() { return combos; } public DataStore data() { return data; }
    public Abilities abilities() { return abilities; } public Hud hud() { return hud; } public CollectionGui gui() { return gui; }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        cfg = new Cfg(this); items = new Items(this); sfx = new Sfx(this); casts = new CastManager(this); fx = new Fx(this);
        dmg = new Dmg(this); cc = new Cc(this); energy = new Energy(this); mastery = new Mastery(this); combos = new Combos(this);
        data = new DataStore(this); abilities = new Abilities(this); hud = new Hud(this); gui = new CollectionGui(this); controls = new Controls(this);
        Bukkit.getPluginManager().registerEvents(controls, this);
        Bukkit.getPluginManager().registerEvents(gui, this);
        Commands cmds = new Commands(this);
        for (String c : new String[]{"noiseform", "nebulux", "weapon"}) {
            PluginCommand pc = getCommand(c);
            if (pc != null) { pc.setExecutor(cmds); pc.setTabCompleter(cmds); }
        }
        casts.start(); hud.start();
        nullRequiem = new NullRequiemPlugin(this);
        nullRequiem.enable();
        Bukkit.getScheduler().runTaskTimer(this, () -> data.saveDirty(), 6000L, 6000L);      // autosave (disk I/O is async)
        for (var w : Bukkit.getWorlds()) for (Entity e : w.getEntities()) if (e.getScoreboardTags().contains(Fx.TAG)) e.remove();   // leftovers from a crash
        for (var p : Bukkit.getOnlinePlayers()) { data.get(p.getUniqueId()); controls.markOwned(p); }
        getLogger().info("NOISEFORM & NEBULUX enabled. Resource pack namespace: des");
    }

    @Override
    public void onDisable() {
        if (nullRequiem != null) nullRequiem.disable();
        if (hud != null) hud.stop();
        if (casts != null) casts.shutdown();
        if (fx != null) fx.shutdown();
        for (var p : Bukkit.getOnlinePlayers()) p.setGravity(true);
        if (data != null) data.saveAllNow();
    }

    public void reloadAll() { reloadConfig(); fx.reload(); items.clearCaches(); if (nullRequiem != null) nullRequiem.reloadAll(); }
    public NullRequiemPlugin nullRequiem() { return nullRequiem; }
}

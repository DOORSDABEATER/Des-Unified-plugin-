package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** 03 - crimson sigil above the target; Rik's later damage vs it is amplified; defeat gives an execution burst. */
final class BloodMark extends AkaiBase {
    BloodMark(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.BLOOD_MARK); }

    @Override public boolean execute(AkaiCtx ctx) {
        Player p = ctx.player;
        LivingEntity t = aimTarget(p, cfg("range", 26), cfg("cone-degrees", 25), false);
        if (t == null) { actionbar(p, "<red>BLOOD MARK <gray>- no target in sight"); return false; }
        p.swingMainHand();
        m.marks().bloodMark(p, t);
        snd(t.getLocation(), "a3_mark", 1.2f, 1.0f);
        AkaiFx.executionBurst(plugin, t.getLocation().add(0, t.getHeight() + 0.5, 0));
        p.sendMessage(m.settings().mm(m.settings().prefix() + "<red>BLOOD MARK <gray>placed on <white>" + t.getName() + "<gray> (+" + (int) (cfg("damage-bonus", 0.25) * 100) + "% damage)"));
        return true;
    }
}

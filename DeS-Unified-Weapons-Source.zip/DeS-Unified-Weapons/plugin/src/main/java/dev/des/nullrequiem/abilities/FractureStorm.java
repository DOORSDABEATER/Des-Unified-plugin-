package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** ABILITY 8 - blade fragments orbit ERROR, launch at different targets, leftovers converge into one final strike. */
public final class FractureStorm extends AbilityBase {
    public FractureStorm(NullRequiemPlugin plugin) { super(plugin, AbilityType.FRACTURE_STORM); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        ctx.maxHitsPerTarget = 2;
        final int n = Math.max(2, Math.min(10, cfgI("fragments", 6)));
        final int summon = cfgI("summon-ticks", 16), stagger = cfgI("launch-stagger-ticks", 3);
        final double speed = cfg("speed", 1.5), shardDmg = cfg("fragment-damage", 4);
        final List<LivingEntity> targets = new ArrayList<>(enemies(p, p.getLocation(), cfg("target-range", 18)));
        targets.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
        final int k = Math.min(targets.size(), n);
        final ItemDisplay[] disp = new ItemDisplay[n];
        final Location[] pos = new Location[n];
        final int[] state = new int[n]; // 0 orbit, 1 flying, 2 done, 3 converging
        for (int i = 0; i < n; i++) {
            pos[i] = p.getLocation().add(0, 1.6, 0);
            disp[i] = vfx().display(id, pos[i], "shard", new Vector3f(1.8f, 1.8f, 1.8f), new Quaternionf(), true, 2);
        }
        p.swingMainHand();
        sfx().play(p.getLocation(), Snd.A8_SUMMON, 1.1f, 1.0f);
        final Location[] finalPoint = {null};
        final int[] convergeStart = {-1};
        tasks().timer(id, 0, 1, summon + n * stagger + 80, t -> {
            if (!alive(p)) return false;
            Location center = p.getLocation().add(0, 1.6, 0);
            Vfx.Audience a = vfx().at(center);
            boolean allSettled = true;
            for (int i = 0; i < n; i++) {
                if (state[i] == 2) continue;
                allSettled &= state[i] != 0 || i >= k && t >= summon + k * stagger;
                if (state[i] == 0) {
                    double r = Math.min(2.4, 0.6 + t * 0.12);
                    double ang = t * 0.28 + i * Math.PI * 2 / n;
                    pos[i] = center.clone().add(Math.cos(ang) * r, Math.sin(t * 0.2 + i) * 0.45, Math.sin(ang) * r);
                    if (t % 3 == 0) a.dust(pos[i], 1, 0.05, Vfx.NEON, 1.0f);
                    if (i < k && t == summon + i * stagger) { state[i] = 1; sfx().play(pos[i], Snd.A8_LAUNCH, 0.9f, 1.0f + i * 0.08f); }
                } else if (state[i] == 1) {
                    LivingEntity tg = targets.get(i);
                    if (!tg.isValid() || tg.isDead()) { state[i] = 2; remove(id, disp[i]); continue; }
                    Location aim = tg.getLocation().add(0, tg.getHeight() / 2, 0);
                    Vector v = aim.toVector().subtract(pos[i].toVector());
                    double d = v.length();
                    if (d <= 1.1) {
                        if (ctx.hit(tg, shardDmg, false)) { vfx().hitBurst(aim, plugin.fracture().isExposed(tg)); sfx().play(aim, Snd.A1_HIT, 0.8f, 1.2f); }
                        state[i] = 2; remove(id, disp[i]);
                        continue;
                    }
                    pos[i].add(v.normalize().multiply(Math.min(speed, d)));
                    a.dust(pos[i], 2, 0.1, Vfx.EMERALD, 1.1f);
                    vfx().line(a, pos[i].clone().subtract(v.clone().multiply(0.8)), pos[i], 0.3, Vfx.NEON, 0.9f);
                    if (disp[i] != null && disp[i].isValid()) {
                        disp[i].teleport(pos[i]);
                        vfx().animate(disp[i], new Vector3f(1.8f, 1.8f, 1.8f), Vfx.orient(v, new Vector(0, 1, 0)), 1);
                    }
                } else if (state[i] == 3) {
                    double f = Math.min(1.0, (t - convergeStart[0]) / 8.0);
                    Location from = pos[i];
                    pos[i] = from.clone().add(finalPoint[0].clone().subtract(from).toVector().multiply(0.35));
                    a.dust(pos[i], 2, 0.1, Vfx.PALE, 1.1f);
                    if (f >= 1.0) { state[i] = 2; remove(id, disp[i]); }
                }
                if (state[i] != 1 && state[i] != 2 && disp[i] != null && disp[i].isValid()) disp[i].teleport(pos[i]);
            }
            // start converging leftovers once every launched fragment finished
            if (convergeStart[0] < 0 && t >= summon + Math.max(0, k - 1) * stagger + 2) {
                boolean flying = false;
                for (int i = 0; i < n; i++) if (state[i] == 1) flying = true;
                if (!flying) {
                    convergeStart[0] = t;
                    finalPoint[0] = k > 0 && targets.get(0).isValid() ? targets.get(0).getLocation().add(0, 1, 0) : aimPoint(p, 20);
                    for (int i = 0; i < n; i++) if (state[i] == 0) state[i] = 3;
                    sfx().play(finalPoint[0], Snd.A8_SUMMON, 1.0f, 0.6f);
                }
            }
            if (convergeStart[0] >= 0 && t >= convergeStart[0] + 8) { finalStrike(ctx, finalPoint[0]); return false; }
            return true;
        }, () -> { for (ItemDisplay d : disp) tasks().release(id, d); });
        return true;
    }

    private void remove(UUID id, ItemDisplay d) { if (d != null) tasks().release(id, d); }

    private void finalStrike(CastContext ctx, Location at) {
        Player p = ctx.player;
        sfx().play(at, Snd.A8_FINAL, 1.4f, 1.0f);
        vfx().sphereBurst(at, 1.8);
        shockRing(p.getUniqueId(), at.clone().subtract(0, 0.9, 0), 4, 6, true);
        vfx().crack(vfx().at(at), at.clone().add(0, 4, 0), at, 0.6, Vfx.NEON, 1.5f);
        for (LivingEntity e : enemies(p, at, cfg("final-radius", 3.2))) {
            if (ctx.hit(e, cfg("final-damage", 8), true)) {
                Vector out = e.getLocation().toVector().subtract(at.toVector()).setY(0);
                if (out.lengthSquared() > 1e-4) dmg().push(p, e, out.normalize().multiply(0.7).setY(0.3), ctx.castId);
            }
        }
    }
}

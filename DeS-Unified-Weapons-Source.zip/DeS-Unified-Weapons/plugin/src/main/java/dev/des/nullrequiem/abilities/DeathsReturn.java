package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** ABILITY 10 - corrupted seal stores a share of the damage ERROR deals to the marked enemy; recast to detonate. */
public final class DeathsReturn extends AbilityBase {
    private static final class Seal {
        UUID target; double stored; long expires; Location last; ItemDisplay disp; CastContext ctx;
    }
    private final Map<UUID, Seal> seals = new HashMap<>();

    public DeathsReturn(NullRequiemPlugin plugin) { super(plugin, AbilityType.DEATHS_RETURN); }

    @Override public boolean selfManagedCooldown() { return true; }

    @Override
    public boolean canRecast(Player p) {
        Seal s = seals.get(p.getUniqueId());
        return s != null && s.expires > System.currentTimeMillis();
    }

    @Override
    public boolean execute(CastContext ctx) {
        Player p = ctx.player;
        if (canRecast(p)) { detonate(p); return true; }
        LivingEntity t = aimTarget(p, cfg("range", 26), cfg("cone-degrees", 25), true);
        if (t == null) { actionbar(p, "<yellow>DEATH'S RETURN <gray>- no target in sight"); return false; }
        ctx.maxHitsPerTarget = 2;
        final UUID id = p.getUniqueId();
        final Seal s = new Seal();
        s.target = t.getUniqueId();
        s.expires = System.currentTimeMillis() + (long) (cfg("duration-seconds", 15) * 1000);
        s.last = t.getLocation();
        s.ctx = ctx;
        s.disp = vfx().display(id, t.getLocation().add(0, 0.15, 0), "circle", new Vector3f(1.0f, 1.0f, 1.0f), new Quaternionf(), false, 2);
        seals.put(id, s);
        plugin.cooldowns().setSeconds(p, type, cfg("mark-cooldown", 1.0));
        p.swingMainHand();
        sfx().play(t.getLocation(), Snd.A10_SEAL, 1.1f, 1.0f);
        p.sendMessage(plugin.settings().msg("seal-placed", "<green>DEATH'S RETURN <gray>seal placed on <white>{target}<gray>. Recast to detonate.", "target", t.getName()));
        final double max = cfg("max-stored", 30);
        tasks().timer(id, 0, 2, (int) (cfg("duration-seconds", 15) * 10) + 5, n -> {
            if (!alive(p) || seals.get(id) != s) return false;
            Entity e = Bukkit.getEntity(s.target);
            if (!(e instanceof LivingEntity le) || !le.isValid() || le.isDead()) { fizzle(p, s); return false; }
            if (System.currentTimeMillis() > s.expires) { fizzle(p, s); return false; }
            s.last = le.getLocation();
            double f = Math.min(1.0, s.stored / max);
            Location base = le.getLocation().add(0, 0.12, 0);
            if (s.disp != null && s.disp.isValid()) {
                s.disp.teleport(base);
                if (n % 5 == 0) {
                    float sc = (float) (0.9 + f * 1.4);
                    vfx().animate(s.disp, new Vector3f(sc, 1f, sc), new Quaternionf().rotateY(n * 0.15f), 10);
                }
            }
            Vfx.Audience a = vfx().at(base);
            vfx().ring(a, base, 1.0 + f * 1.2, 10 + (int) (f * 14), n * 0.25, Vfx.NEON, 1.0f + (float) f * 0.5f);
            a.dust(le.getLocation().add(0, le.getHeight() + 0.4, 0), 1 + (int) (f * 4), 0.2, f > 0.66 ? Vfx.PALE : Vfx.EMERALD, 1.2f);
            if (f > 0.5 && n % 4 == 0) vfx().glitch(a, base.clone().add(0, 1, 0));
            return true;
        }, null);
        return true;
    }

    private void fizzle(Player p, Seal s) {
        seals.remove(p.getUniqueId());
        tasks().release(p.getUniqueId(), s.disp);
        if (alive(p)) {
            vfx().glitch(vfx().at(s.last), s.last);
            plugin.cooldowns().setSeconds(p, type, plugin.settings().cooldownSeconds(type));
        }
    }

    /** Stores a share of damage ERROR dealt to the marked target (called by DamageService and the melee listener). */
    public void record(Player src, LivingEntity t, double dealt) {
        Seal s = seals.get(src.getUniqueId());
        if (s == null || !s.target.equals(t.getUniqueId()) || dealt <= 0) return;
        s.stored = Math.min(cfg("max-stored", 30), s.stored + dealt * cfg("store-fraction", 0.35));
    }

    private void detonate(Player p) {
        final UUID id = p.getUniqueId();
        Seal s = seals.remove(id);
        if (s == null) return;
        tasks().release(id, s.disp);
        Entity e = Bukkit.getEntity(s.target);
        LivingEntity target = e instanceof LivingEntity le && le.isValid() && !le.isDead() ? le : null;
        Location c = (target != null ? target.getLocation() : s.last).clone();
        double base = cfg("base-damage", 4);
        double dmg = base + s.stored;
        CastContext ctx = s.ctx;
        ctx.maxHitsPerTarget = 2;
        p.swingMainHand();
        sfx().play(c, Snd.A10_DETONATE, 1.5f, 1.0f);
        shockRing(id, c, cfg("splash-radius", 5.0), 8, true);
        vfx().sphereBurst(c.clone().add(0, 1, 0), 2.0);
        vfx().column(vfx().at(c), c, 4.0, 0.9, 10, Vfx.NEON, 1.4f);
        if (target != null) ctx.hit(target, dmg, true);
        for (LivingEntity o : enemies(p, c, cfg("splash-radius", 5.0))) {
            if (target != null && o.equals(target)) continue;
            if (ctx.hit(o, dmg * cfg("splash-fraction", 0.5), false)) {
                Vector out = o.getLocation().toVector().subtract(c.toVector()).setY(0);
                if (out.lengthSquared() > 1e-4) dmg().push(p, o, out.normalize().multiply(0.8).setY(0.35), ctx.castId);
            }
        }
        plugin.cooldowns().setSeconds(p, type, plugin.settings().cooldownSeconds(type));
    }

    @Override
    public void onAbort(Player p) {
        Seal s = seals.remove(p.getUniqueId());
        if (s != null) tasks().release(p.getUniqueId(), s.disp);
    }
}

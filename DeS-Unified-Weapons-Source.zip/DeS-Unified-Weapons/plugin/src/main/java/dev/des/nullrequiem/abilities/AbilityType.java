package dev.des.nullrequiem.abilities;

import java.util.Locale;

public enum AbilityType {
    RIFT_CLEAVER("rift_cleaver", "RIFT CLEAVER", 0, 6),
    ZERO_POINT_EXECUTION("zero_point_execution", "ZERO-POINT EXECUTION", 10, 14),
    BROKEN_COORDINATES("broken_coordinates", "BROKEN COORDINATES", 10, 22),
    NULL_GRAVITY("null_gravity", "NULL GRAVITY", 15, 26),
    FALSE_REALITY("false_reality", "FALSE REALITY", 15, 24),
    WORLD_BREAK("world_break", "WORLD//BREAK", 20, 30),
    CORRUPTION_CASCADE("corruption_cascade", "CORRUPTION CASCADE", 10, 18),
    FRACTURE_STORM("fracture_storm", "FRACTURE STORM", 15, 22),
    TIME_DESYNC("time_desync", "TIME//DESYNC", 10, 20),
    DEATHS_RETURN("deaths_return", "DEATH'S RETURN", 10, 16),
    ABSOLUTE_NULLIFICATION("absolute_nullification", "ABSOLUTE NULLIFICATION", 60, 45),
    FINAL_VARIABLE("final_variable", "FINAL VARIABLE", 25, 28),
    ULTIMATE("ultimate", "404: WORLD CORRUPTED", 100, 180);

    public static final AbilityType[] ACTIVES = {
        RIFT_CLEAVER, ZERO_POINT_EXECUTION, BROKEN_COORDINATES, NULL_GRAVITY, FALSE_REALITY, WORLD_BREAK,
        CORRUPTION_CASCADE, FRACTURE_STORM, TIME_DESYNC, DEATHS_RETURN, ABSOLUTE_NULLIFICATION, FINAL_VARIABLE
    };

    private final String key, display;
    private final double cost, cooldown;

    AbilityType(String key, String display, double cost, double cooldown) {
        this.key = key; this.display = display; this.cost = cost; this.cooldown = cooldown;
    }

    public String key() { return key; }
    public String display() { return display; }
    public double defaultCost() { return cost; }
    public double defaultCooldown() { return cooldown; }
    public boolean isUltimate() { return this == ULTIMATE; }

    public static AbilityType parse(String s) {
        if (s == null) return null;
        String k = s.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        try { int n = Integer.parseInt(k); if (n >= 1 && n <= 12) return ACTIVES[n - 1]; if (n == 13) return ULTIMATE; } catch (NumberFormatException ignored) { }
        for (AbilityType t : values()) if (t.key.equals(k) || t.name().equalsIgnoreCase(k)) return t;
        return null;
    }
}

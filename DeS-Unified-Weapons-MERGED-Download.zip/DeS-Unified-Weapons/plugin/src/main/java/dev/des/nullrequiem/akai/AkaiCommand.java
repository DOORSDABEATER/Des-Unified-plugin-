package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /akai ... - tab-completed, permission checked, console aware (admin commands), owner-only for personal ones. */
final class AkaiCommand implements TabExecutor {
    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    AkaiCommand(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    private void say(CommandSender s, String mm) { s.sendMessage(m.settings().mm(m.settings().prefix() + mm)); }
    private boolean admin(CommandSender s) { if (s.hasPermission("akai.admin")) return true; say(s, "<red>You do not have permission."); return false; }

    private Player online(CommandSender s, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) say(s, "<red>Player not found / offline: " + name);
        return p;
    }

    /** Self-service commands: only the Sovereign (or admins). */
    private Player self(CommandSender s, String[] a, int argIndex) {
        Player t = null;
        if (a.length > argIndex) { if (!admin(s)) return null; t = online(s, a[argIndex]); }
        else if (s instanceof Player p) t = p;
        else say(s, "<red>Specify a player.");
        if (t != null && s instanceof Player sp && t.equals(sp) && !m.weapon().isOwner(sp) && !sp.hasPermission("akai.admin")) { say(s, "<red>Only the Sovereign may use this."); return null; }
        return t;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) { say(sender, "<red>/akai <gray>give|remove|reload|stats|mastery|energy|reset|test|ultimate|cast|select|camera"); return true; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "give" -> {
                if (!admin(sender) || a.length < 2) { if (a.length < 2) say(sender, "<gray>/akai give <player>"); return true; }
                Player t = online(sender, a[1]); if (t == null) return true;
                UUID owner = m.settings().ownerUuid();
                if (owner == null) {
                    if (!t.getName().equalsIgnoreCase(m.settings().s("owner.name", "RIK"))) { say(sender, "<yellow>The owner UUID is not set yet. Give it to <white>" + m.settings().s("owner.name", "RIK") + "<yellow> first (or set owner.uuid in akai.yml)."); return true; }
                    m.settings().learnOwner(t.getUniqueId());
                    owner = t.getUniqueId();
                    say(sender, "<gray>Owner UUID learned and saved: <white>" + owner);
                } else if (!owner.equals(t.getUniqueId())) { say(sender, "<red>AKAI NO \u014c is bound to UUID <white>" + owner + "<red>. It cannot be issued to " + t.getName() + "."); return true; }
                ItemStack it = m.weapon().create(owner);
                if (!t.getInventory().addItem(it).isEmpty()) { m.weapon().removeAll(t); say(sender, "<red>Inventory full - nothing given."); return true; }
                AkaiData d = m.store().get(t.getUniqueId()); d.owned = true; d.name = t.getName();
                say(sender, "<green>Gave AKAI NO \u014c to " + t.getName());
                t.sendMessage(m.settings().mm("<dark_red>[AKAI NO \u014c] <red>The blade does not serve the throne. The throne serves the blade."));
            }
            case "remove" -> { if (!admin(sender) || a.length < 2) return true; Player t = online(sender, a[1]); if (t != null) say(sender, "<green>Removed " + m.weapon().removeAll(t) + " item(s) from " + t.getName()); }
            case "reload" -> { if (!admin(sender)) return true; m.settings().reload(); say(sender, "<green>akai.yml reloaded."); }
            case "stats" -> {
                Player t = self(sender, a, 1); if (t == null) return true;
                AkaiData d = m.store().get(t.getUniqueId());
                say(sender, "<red>" + t.getName() + " <gray>| stage <white>" + m.mastery().name(m.mastery().stage(d)) + " <gray>| xp <white>" + d.xp + " <gray>| hits <white>" + d.hits + " <gray>| kills <white>" + d.kills
                    + " <gray>(decreed " + d.decreeKills + ") | casts <white>" + d.casts + " <gray>| thrones <white>" + d.ultimates);
            }
            case "mastery" -> {
                Player t = self(sender, a, 1); if (t == null) return true;
                AkaiData d = m.store().get(t.getUniqueId()); int stage = m.mastery().stage(d);
                say(sender, "<red>Mastery: <white>" + m.mastery().name(stage));
                for (int s = 2; s <= 3; s++) {
                    AkaiSettings c = m.settings();
                    say(sender, "<gray>Stage " + s + " (" + AkaiMastery.NAMES[s - 1] + "): xp " + d.xp + "/" + (int) c.d("mastery.stage" + s + ".xp", s == 2 ? 1500 : 6000) + ", hits " + d.hits + "/" + (int) c.d("mastery.stage" + s + ".hits", s == 2 ? 250 : 1200)
                        + ", kills " + d.kills + "/" + (int) c.d("mastery.stage" + s + ".kills", s == 2 ? 12 : 60) + ", thrones " + d.ultimates + "/" + (int) c.d("mastery.stage" + s + ".ultimates", s == 2 ? 0 : 3)
                        + ", decree kills " + d.decreeKills + "/" + (int) c.d("mastery.stage" + s + ".decree-kills", s == 2 ? 0 : 8));
                }
            }
            case "energy" -> {
                if (a.length >= 3) { if (!admin(sender)) return true; Player t = online(sender, a[1]); if (t == null) return true; try { m.energy().set(t, Double.parseDouble(a[2])); } catch (NumberFormatException e) { say(sender, "<red>Invalid number."); return true; } }
                Player t = self(sender, a, a.length >= 3 ? 1 : 1); if (t == null) return true;
                say(sender, "<red>Imperial Energy: <white>" + (int) m.energy().get(t) + "<gray>/" + (int) m.energy().max());
            }
            case "reset" -> { if (!admin(sender) || a.length < 2) return true; Player t = online(sender, a[1]); if (t == null) return true; m.store().reset(t.getUniqueId()); m.resetCooldowns(t); say(sender, "<green>Progress reset for " + t.getName()); }
            case "test" -> {
                if (!admin(sender)) return true;
                if (!(sender instanceof Player p)) { say(sender, "<red>Players only."); return true; }
                AkaiType t = a.length > 1 ? AkaiType.parse(a[1]) : null;
                if (t == null) { say(sender, "<red>Unknown ability (1-12, 13/ultimate, or name)."); return true; }
                say(sender, "<gray>test " + t.display() + ": <white>" + m.manager().cast(p, t, true));
            }
            case "ultimate" -> {
                if (!admin(sender) || a.length < 2) { if (a.length < 2) say(sender, "<gray>/akai ultimate <player>"); return true; }
                Player t = online(sender, a[1]); if (t == null) return true;
                say(sender, "<gray>throne for " + t.getName() + ": <white>" + m.manager().cast(t, AkaiType.ULTIMATE, true));
            }
            case "cast" -> {
                if (!(sender instanceof Player p)) return true;
                AkaiType t = a.length > 1 ? AkaiType.parse(a[1]) : null;
                if (t == null) { say(sender, "<gray>/akai cast <1-12|ultimate|name>"); return true; }
                if (m.manager().cast(p, t, false) == AkaiManager.Result.NOT_HOLDING) say(sender, "<yellow>Hold AKAI NO \u014c (and be its Sovereign).");
            }
            case "select" -> { if (sender instanceof Player p && a.length > 1 && m.weapon().holdsUsable(p)) { try { m.manager().selectIndex(p, Integer.parseInt(a[1]) - 1); } catch (NumberFormatException e) { say(sender, "<red>Invalid number."); } } }
            case "camera" -> {
                if (!(sender instanceof Player p) || a.length < 2) { say(sender, "<gray>/akai camera <on|off>"); return true; }
                boolean on = a[1].equalsIgnoreCase("on");
                m.store().get(p.getUniqueId()).cutsceneCamera = on;
                say(sender, "<green>Cinematic camera " + (on ? "enabled" : "disabled"));
            }
            default -> say(sender, "<red>Unknown subcommand. /akai help");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) { for (String s : List.of("help", "give", "remove", "reload", "stats", "mastery", "energy", "reset", "test", "ultimate", "cast", "select", "camera")) if (s.startsWith(a[0].toLowerCase())) out.add(s); }
        else if (a.length == 2) {
            String s = a[0].toLowerCase();
            if (List.of("give", "remove", "stats", "mastery", "energy", "reset", "ultimate").contains(s)) for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(a[1].toLowerCase())) out.add(p.getName());
            if (List.of("test", "cast").contains(s)) for (AkaiType t : AkaiType.values()) out.add(t.key());
            if (s.equals("camera")) { out.add("on"); out.add("off"); }
        }
        return out;
    }
}

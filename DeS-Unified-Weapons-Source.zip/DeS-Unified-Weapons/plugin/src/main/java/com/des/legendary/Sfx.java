package com.des.legendary;

import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.entity.Player;

import java.util.Map;

/** Plays the custom sound events registered in the resource pack (assets/des/sounds.json). */
public final class Sfx {
    private final LegendaryPlugin pl;
    /** Optional vanilla "weight" layer, enabled with sounds.vanilla-layer: true (useful while testing without the pack). */
    private static final Map<String, String> VANILLA = Map.ofEntries(
            Map.entry("noiseform.final_release", "entity.warden.sonic_boom"), Map.entry("noiseform.final_explode", "entity.generic.explode"),
            Map.entry("noiseform.frequency_slam", "entity.iron_golem.damage"), Map.entry("noiseform.rupture_cast", "entity.player.attack.sweep"),
            Map.entry("noiseform.dash", "entity.enderman.teleport"), Map.entry("nebulux.supernova_explode", "entity.generic.explode"),
            Map.entry("nebulux.starfall_impact", "entity.generic.explode"), Map.entry("nebulux.pierce_fire", "entity.warden.sonic_boom"),
            Map.entry("nebulux.astral_out", "entity.enderman.teleport"), Map.entry("nebulux.astral_return", "entity.enderman.teleport"));

    public Sfx(LegendaryPlugin pl) { this.pl = pl; }

    private float vol(String ev, float v) { return (float) (pl.cfg().d("sounds.events." + ev + ".volume", 1.0) * v * pl.cfg().d("sounds.master-volume", 1.0)); }
    private float pit(String ev, float p) { return (float) Math.max(0.5, Math.min(2.0, pl.cfg().d("sounds.events." + ev + ".pitch", 1.0) * p)); }

    /** World sound heard by everyone nearby (volume > 1 carries further). */
    public void play(Location l, String ev, float volume, float pitch) {
        if (l == null || l.getWorld() == null) return;
        float v = vol(ev, volume), p = pit(ev, pitch);
        l.getWorld().playSound(l, "des:" + ev, SoundCategory.PLAYERS, v, p);
        if (pl.cfg().b("sounds.vanilla-layer", false)) {
            String vs = VANILLA.get(ev);
            if (vs != null) l.getWorld().playSound(l, vs, SoundCategory.PLAYERS, v * 0.8f, p);
        }
    }

    /** Private UI sound (select / deny / level-up). */
    public void to(Player pl2, String ev, float volume, float pitch) {
        pl2.playSound(pl2.getLocation(), "des:" + ev, SoundCategory.PLAYERS, vol(ev, volume), pit(ev, pitch));
    }
}

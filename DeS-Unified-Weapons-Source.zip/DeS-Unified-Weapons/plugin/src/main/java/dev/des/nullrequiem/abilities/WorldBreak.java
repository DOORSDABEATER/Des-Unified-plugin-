package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** ABILITY 6 - ground slam; emerald fractures spread, erupt, and a final eruption knocks everything back. No terrain damage. */
public final class WorldBreak extends AbilityBase {
    private record Eruption(int tick, Location at) { }

    public WorldBreak(NullRequiemPlugin plugin) { super(plugin, AbilityType.WORLD_BREAK); }

    @Override
    public boolean execute(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        ctx.maxHitsPerTarget = 3;
        final int windup = cfgI("windup-ticks", 10);
        final int lines = cfgI("fractures", 6);
        final double len = cfg("length", 12);
        p.swingMainHand();
        sfx().play(p.getLocation(), Snd.A6_SLAM, 0.6f, 1.4f);
        tasks().timer(id, 0, 1, windup, t -> {
            if (!alive(p)) return false;
            Location top = p.getLocation().add(0, 2.3 + t * 0.05, 0);
            vfx().tiltedRing(vfx().at(top), top, new Vector(0, 1, 0), 0.8, 10, t * 0.5, Vfx.NEON, 1.0f);
            vfx().at(top).dust(top, 3, 0.3, Vfx.PALE, 1.1f);
            return true;
        }, () -> slam(ctx, lines, len));
        return true;
    }

    private void slam(CastContext ctx, int lines, double len) {
        final Player p = ctx.player;
        if (!alive(p)) return;
        final UUID id = p.getUniqueId();
        final Location c = Locs.ground(p.getLocation());
        sfx().play(c, Snd.A6_SLAM, 1.5f, 1.0f);
        vfx().block(vfx().at(c), c);
        shockRing(id, c, 4.5, 6, true);
        final double base = Math.random() * Math.PI * 2;
        final List<Eruption> erupts = new ArrayList<>();
        final Location[] ends = new Location[lines];
        final double[] angles = new double[lines];
        for (int k = 0; k < lines; k++) {
            angles[k] = base + k * Math.PI * 2 / lines + (Math.random() - 0.5) * 0.3;
            for (int j = 1; j <= 4; j++) {
                double dist = len * j / 4.0;
                Location pt = Locs.ground(c.clone().add(Math.cos(angles[k]) * dist, 0, Math.sin(angles[k]) * dist));
                erupts.add(new Eruption(2 + (int) (dist / 1.2) + 3, pt));
            }
        }
        final int finalTick = 2 + (int) (len / 1.2) + 10;
        final double speed = 1.2;
        tasks().timer(id, 1, 1, finalTick + 4, t -> {
            if (!alive(p)) return false;
            Vfx.Audience a = vfx().at(c);
            double front = Math.min(len, speed * (t + 1)), back = Math.min(len, speed * t);
            if (back < len) for (int k = 0; k < lines; k++) {
                Location f0 = Locs.ground(c.clone().add(Math.cos(angles[k]) * back, 0, Math.sin(angles[k]) * back));
                Location f1 = Locs.ground(c.clone().add(Math.cos(angles[k]) * front, 0, Math.sin(angles[k]) * front));
                vfx().crack(a, f0.add(0, 0.15, 0), f1.add(0, 0.15, 0), 0.35, Vfx.NEON, 1.2f);
                a.dust(f1, 2, 0.2, Vfx.VOID, 1.4f);
            }
            int fired = 0;
            for (Eruption e : erupts) if (e.tick() == t) {
                if (fired++ == 0) sfx().play(e.at(), Snd.A6_ERUPT, 1.0f, (float) (0.9 + Math.random() * 0.3));
                erupt(ctx, e.at());
            }
            if (t == finalTick) finalEruption(ctx, c);
            return t < finalTick;
        }, null);
    }

    private void erupt(CastContext ctx, Location at) {
        Player p = ctx.player;
        Vfx.Audience a = vfx().at(at);
        vfx().column(a, at, 3.2, 0.5, 9, Vfx.NEON, 1.3f);
        a.block(at.clone().add(0, 0.5, 0), 14, 0.4, Material.EMERALD_BLOCK);
        a.block(at.clone().add(0, 0.5, 0), 8, 0.4, Material.BLACK_CONCRETE);
        a.villager(at.clone().add(0, 1, 0), 4, 0.5);
        for (LivingEntity e : enemies(p, at, cfg("eruption-radius", 1.9))) {
            if (ctx.hit(e, cfg("eruption-damage", 5))) {
                dmg().push(p, e, new Vector(0, cfg("eruption-launch", 0.6), 0), ctx.castId);
                vfx().hitBurst(e.getLocation().add(0, 1, 0), false);
            }
        }
    }

    private void finalEruption(CastContext ctx, Location c) {
        Player p = ctx.player;
        sfx().play(c, Snd.A6_FINAL, 1.6f, 1.0f);
        shockRing(p.getUniqueId(), c, cfg("final-radius", 6.0), 8, true);
        vfx().sphereBurst(c.clone().add(0, 1, 0), 2.2);
        vfx().column(vfx().at(c), c, 5.0, 1.2, 12, Vfx.NEON, 1.5f);
        for (LivingEntity e : enemies(p, c, cfg("final-radius", 6.0))) {
            if (ctx.hit(e, cfg("final-damage", 8))) {
                Vector out = e.getLocation().toVector().subtract(c.toVector()).setY(0);
                if (out.lengthSquared() < 1e-4) out = new Vector(1, 0, 0);
                dmg().push(p, e, out.normalize().multiply(cfg("final-knockback", 1.5)).setY(0.55), ctx.castId);
            }
        }
    }
}

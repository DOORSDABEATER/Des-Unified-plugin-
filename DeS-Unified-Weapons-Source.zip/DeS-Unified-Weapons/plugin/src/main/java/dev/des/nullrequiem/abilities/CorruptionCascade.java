package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** ABILITY 7 - mark an enemy; corruption chains between nearby enemies, exposed targets take extra, each link pays fragments. */
public final class CorruptionCascade extends AbilityBase {
    public CorruptionCascade(NullRequiemPlugin plugin) { super(plugin, AbilityType.CORRUPTION_CASCADE); }

    @Override
    public boolean execute(CastContext ctx) {
        Player p = ctx.player;
        LivingEntity first = aimTarget(p, cfg("range", 24), cfg("cone-degrees", 30), true);
        if (first == null) { actionbar(p, "<yellow>CORRUPTION CASCADE <gray>- no target in sight"); return false; }
        p.swingMainHand();
        sfx().play(p.getLocation(), Snd.A7_MARK, 1.0f, 1.0f);
        Set<UUID> visited = new HashSet<>();
        link(ctx, p.getEyeLocation().add(0, -0.3, 0), first, visited, 0, cfgI("max-jumps", 5));
        return true;
    }

    private void link(CastContext ctx, Location from, LivingEntity target, Set<UUID> visited, int n, int max) {
        Player p = ctx.player;
        if (!alive(p) || !target.isValid() || target.isDead()) return;
        visited.add(target.getUniqueId());
        Location to = target.getLocation().add(0, target.getHeight() / 2, 0);
        Vfx.Audience a = vfx().at(to);
        vfx().crack(a, from, to, 0.5, Vfx.NEON, 1.3f);
        vfx().crack(a, from, to, 0.8, Vfx.VOID, 1.0f);
        vfx().sphere(a, to, 0.7, 14, Vfx.EMERALD, 1.1f);
        sfx().play(to, Snd.A7_CHAIN, 1.0f, 0.9f + n * 0.12f);
        double dmg = cfg("damage", 6);
        if (ctx.hit(target, dmg, true)) {
            vfx().hitBurst(to, plugin.fracture().isExposed(target));
            plugin.fragments().add(p, cfg("fragments-per-link", 4));
        }
        if (n + 1 >= max) return;
        LivingEntity next = null; double best = Double.MAX_VALUE;
        for (LivingEntity e : enemies(p, to, cfg("jump-radius", 8))) {
            if (visited.contains(e.getUniqueId())) continue;
            double d = e.getLocation().distanceSquared(to);
            if (d < best) { best = d; next = e; }
        }
        if (next == null) return;
        final LivingEntity nx = next;
        tasks().later(p.getUniqueId(), cfgI("jump-delay-ticks", 6), () -> link(ctx, to, nx, visited, n + 1, max));
    }
}

# Commands & permissions  (`/nullrequiem`, aliases `/nr`, `/requiem`)
| Command | Permission | Description |
|---|---|---|
| `give <player> [force]` | nullrequiem.admin | Issue the weapon. Only the configured owner (`owner.name`, default ERROR) unless `force`. Item gets owner UUID + registered serial in its PDC |
| `remove <player>` | nullrequiem.admin | Remove every weapon from inventory and ender chest, revoke serials |
| `reload` | nullrequiem.admin | Reload config.yml |
| `mastery <player> <xp>` | nullrequiem.admin | Add XP (negative subtracts) |
| `fragments <player> <n>` | nullrequiem.admin | Set Reality Fragments |
| `stats [player]` | self / admin | Mastery, kills, hits, casts, 404 count |
| `reset <player>` | nullrequiem.admin | Wipe progression + cooldowns |
| `test <ability>` | nullrequiem.admin | Cast any ability ignoring cost/cooldown (1-12, 13 = ultimate, or name) |
| `ultimate <player>` | nullrequiem.admin | Force 404: WORLD CORRUPTED as that player |
| `collection [player]` | nullrequiem.collection | Open the collection GUI |
| `camera <on\|off>` | - | Choose whether YOU see the 404 camera or stay in your own view |
| `cast <n\|name>`, `select <n>` | nullrequiem.use | Command fallback for the in-game controls |

Other permissions: `nullrequiem.use` (default true), `nullrequiem.immune` (never captured by 404).

## In-game controls (all server-side)
Right-click = cast selected ability (hold = charge FINAL VARIABLE) | F = next ability | Q = previous (weapon can't be dropped) |
Shift+F = 404: WORLD CORRUPTED | Shift+scroll = cycle abilities.

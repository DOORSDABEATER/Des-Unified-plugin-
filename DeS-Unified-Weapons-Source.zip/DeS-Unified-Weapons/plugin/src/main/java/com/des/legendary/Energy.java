package com.des.legendary;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Resonance (NOISEFORM) / Cosmic Energy (NEBULUX): 0-100 meter with anti-farm generation rules. */
public final class Energy {
    private final LegendaryPlugin pl;
    private final Map<UUID, Map<UUID, Long>> victimCd = new HashMap<>();

    public Energy(LegendaryPlugin pl) { this.pl = pl; }
    public double max() { return pl.cfg().d("energy.max", 100.0); }
    public double get(Player p, Weapon w) { return pl.data().get(p.getUniqueId()).of(w).energy; }
    public boolean overdrive(Player p, Weapon w) { return get(p, w) >= max(); }

    public void gain(Player p, Weapon w, double amt) {
        if (amt <= 0) return;
        PlayerData d = pl.data().get(p.getUniqueId()); PlayerData.WD x = d.of(w);
        double before = x.energy; x.energy = Math.min(max(), x.energy + amt); d.dirty = true;
        if (before < max() && x.energy >= max()) {
            Location l = p.getLocation().add(0, 1, 0);
            pl.sfx().play(l, w == Weapon.NOISEFORM ? "noiseform.overdrive_ready" : "nebulux.ascension_ready", 1.2f, 1f);
            pl.fx().burst(l, w == Weapon.NOISEFORM ? Pal.PURPLE : Pal.CYAN, w == Weapon.NOISEFORM ? Pal.WHITE : Pal.MAGENTA, 50, 1.6);
            String name = w == Weapon.NOISEFORM ? "OVERDRIVE" : "CHROMATIC ASCENSION";
            p.showTitle(Title.title(Component.empty(), MiniMessage.miniMessage().deserialize("<" + w.color.asHexString() + "><bold>" + name),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(900), Duration.ofMillis(300))));
        } else if (pl.cfg().b("energy.tick-sound", true) && amt >= 4) pl.sfx().to(p, "noiseform.resonance_tick", 0.35f, w == Weapon.NOISEFORM ? 1f : 1.6f);
    }

    public boolean spend(Player p, Weapon w, double amt) {
        PlayerData d = pl.data().get(p.getUniqueId()); PlayerData.WD x = d.of(w);
        if (x.energy < amt) return false;
        x.energy -= amt; d.dirty = true; return true;
    }

    /** Called by Dmg after an ability hit actually landed. */
    public void onHit(Ctx c, LivingEntity t) {
        if (c.id.ultimate && !pl.cfg().b("energy.from-ultimates", false)) return;
        if (!pl.mastery().eligible(c.p, t)) return;
        double per = pl.cfg().d("energy.per-hit", 12.0);
        if (!(t instanceof Player)) per *= pl.cfg().d("energy.mob-factor", 0.5);
        per = Math.min(per, pl.cfg().d("energy.max-per-cast", 24.0) - c.energyGained);       // controlled generation for multi-hit abilities
        if (per <= 0) return;
        long now = pl.casts().now(), cd = pl.cfg().i("anti-farm.energy-victim-cooldown-ticks", 80);
        Map<UUID, Long> m = victimCd.computeIfAbsent(c.p.getUniqueId(), k -> new HashMap<>());
        Long lastT = m.get(t.getUniqueId());
        if (lastT != null && now - lastT < cd) return;                                          // same victim cannot be farmed back-to-back
        m.put(t.getUniqueId(), now);
        c.energyGained += per;
        gain(c.p, c.w, per);
    }

    /** Resonance Guard: damage absorbed is converted into Resonance (capped per guard). */
    public void absorb(Player p, PlayerData.Guard g, double absorbedHp) {
        double cap = pl.cfg().d("energy.absorb-cap-per-guard", 30.0);
        double amt = Math.min(absorbedHp * pl.cfg().d("energy.absorb-per-hp", 2.0), cap - g.absorbEnergy);
        if (amt <= 0) return;
        g.absorbEnergy += amt; gain(p, g.w, amt);
    }

    public void forget(UUID p) { victimCd.remove(p); }
}

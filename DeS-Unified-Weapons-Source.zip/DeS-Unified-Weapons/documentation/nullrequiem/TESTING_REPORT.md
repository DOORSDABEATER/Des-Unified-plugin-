# Testing report - read this first
**Nothing in this project has been run inside Minecraft.** The build environment had no Paper API, no network and no Minecraft server.

| Item | Status |
|---|---|
| Plugin source (45 files, ~4.4k lines) | **Implemented** |
| Java syntax | **Checked**: full javac parse of all 45 files, 0 syntax errors |
| Cross-class references | **Checked**: javac reports no unresolved symbol between plugin classes (only the missing Paper/JavaPlugin API) |
| Compilation against Paper | **NOT DONE** (no Paper API jar). Expect a few signature fixes on first build |
| Plugin JAR | **NOT BUILT** - use `gradle build` or the included GitHub Actions workflow |
| Resource pack | **Built & validated by script**: all model/texture/item/sound references resolve, element bounds legal, 46/46 sounds exist and match the plugin's sound ids |
| Model silhouette | **Rendered** (orthographic preview in `documentation/preview_*.png`); **not** viewed in-game |
| Held-item transforms, first/third person, GUI, ground | **NOT TESTED** (computed values) |
| Sounds | Generated and encoded, **never listened to in-game** |
| All 12 abilities, passive, fragments, ultimate, cutscene sync, damage-at-impact, restore, disconnect cleanup, mastery/collection persistence, multiplayer, TPS | **NOT TESTED** |

## Highest-risk spots to check first
1. Scythe pose/scale in hand (tune `display`).
2. Camera: armor-stand eye offset (`ultimate.camera-eye-offset`) and whether pitch is honoured when spectating an armor stand; if not, use `cutscene-mode: FREEZE`.
3. Switching a captured player out of/into spectator for the impact hit (brief view flicker expected).
4. FINAL VARIABLE hold detection (relies on repeated right-click events; tune `controls.hold-release-timeout-ticks`).
5. Egg-timing of ItemDisplay interpolation (`animate`) for rings/slashes.
6. Balance numbers - all are first-pass.

## Known limitations
- Existing DeS collection plugin not inspected: a standalone GUI + `exportEntry()` API are provided, not a hook into your collection.
- No true full-body player animation; no custom particle types (vanilla-only mod-free constraint).
- Mastery/fragments are per-session for fragments (not persisted); ultimate cooldown and mastery are persisted.

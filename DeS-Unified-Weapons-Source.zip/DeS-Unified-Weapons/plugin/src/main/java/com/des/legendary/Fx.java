package com.des.legendary;

import org.bukkit.*;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Reusable VFX toolkit: budgeted particle helpers + pooled/expiring ItemDisplay sprites (crescents, rings, orbs, shields ...).
 * Every display entity is non-persistent, tagged "des_fx", capped (vfx.max-displays) and force-removed on expiry/shutdown.
 */
public final class Fx {
    public static final String TAG = "des_fx";
    private static final class Tracked { final Entity e; final long expire; Tracked(Entity e, long x) { this.e = e; this.expire = x; } }

    private final LegendaryPlugin pl;
    private final List<Tracked> tracked = new ArrayList<>();
    private int used, maxPerTick, maxDisplays;
    private double mult, viewRange;

    public Fx(LegendaryPlugin pl) { this.pl = pl; reload(); }

    public void reload() {
        mult = pl.cfg().d("vfx.particle-multiplier", 1.0);
        maxPerTick = pl.cfg().i("vfx.max-particles-per-tick", 2500);
        maxDisplays = pl.cfg().i("vfx.max-displays", 300);
        viewRange = pl.cfg().d("vfx.display-view-range", 0.6);
    }

    /** Called once per server tick by the CastManager. */
    public void tick(long now) {
        used = 0;
        for (int i = tracked.size() - 1; i >= 0; i--) {
            Tracked t = tracked.get(i);
            if (!t.e.isValid() || now >= t.expire) { if (t.e.isValid()) t.e.remove(); tracked.remove(i); }
        }
    }

    public void shutdown() { for (Tracked t : tracked) if (t.e.isValid()) t.e.remove(); tracked.clear(); }
    public int displayCount() { return tracked.size(); }

    // ---------------------------------------------------------------- particles
    private int budget(int n) {
        int k = Math.max(1, (int) Math.round(n * mult));
        if (used + k > maxPerTick) return 0;
        used += k; return k;
    }
    public void dust(Location l, Color c, float size, int n, double spread) {
        int k = budget(n); if (k == 0) return;
        l.getWorld().spawnParticle(Particle.DUST, l, k, spread, spread, spread, 0, new Particle.DustOptions(c, size));
    }
    public void dust2(Location l, Color a, Color b, float size, int n, double spread) {
        int k = budget(n); if (k == 0) return;
        l.getWorld().spawnParticle(Particle.DUST_COLOR_TRANSITION, l, k, spread, spread, spread, 0, new Particle.DustTransition(a, b, size));
    }
    public void part(Particle p, Location l, int n, double spread, double speed) {
        int k = budget(n); if (k == 0) return;
        l.getWorld().spawnParticle(p, l, k, spread, spread, spread, speed);
    }
    public void debris(Location l, int n, double spread) {
        int k = budget(n); if (k == 0) return;
        org.bukkit.block.Block b = l.clone().subtract(0, 0.6, 0).getBlock();
        org.bukkit.block.data.BlockData bd = b.getType().isAir() ? Material.STONE.createBlockData() : b.getBlockData();
        l.getWorld().spawnParticle(Particle.BLOCK, l, k, spread, 0.15, spread, 0.12, bd);
    }
    public void ring(Location c, double r, int pts, Color a, Color b, float size) {
        pts = Math.max(8, (int) (pts * Math.max(0.3, mult)));
        for (int i = 0; i < pts; i++) {
            double ang = 2 * Math.PI * i / pts;
            int k = budget(1); if (k == 0) return;
            Location p = c.clone().add(Math.cos(ang) * r, 0, Math.sin(ang) * r);
            p.getWorld().spawnParticle(Particle.DUST_COLOR_TRANSITION, p, 1, 0, 0, 0, 0, new Particle.DustTransition(a, b, size));
        }
    }
    public void sphere(Location c, double r, int pts, Color a, Color b, float size) {
        pts = Math.max(6, (int) (pts * Math.max(0.3, mult)));
        for (int i = 0; i < pts; i++) {
            double y = 1 - 2.0 * (i + 0.5) / pts, rr = Math.sqrt(1 - y * y), th = i * 2.399963;
            int k = budget(1); if (k == 0) return;
            Location p = c.clone().add(Math.cos(th) * rr * r, y * r, Math.sin(th) * rr * r);
            p.getWorld().spawnParticle(Particle.DUST_COLOR_TRANSITION, p, 1, 0, 0, 0, 0, new Particle.DustTransition(a, b, size));
        }
    }
    public void line(Location a, Location b, double step, Color c1, Color c2, float size) {
        Vector d = b.toVector().subtract(a.toVector()); double len = d.length(); if (len < 1e-4) return;
        d.multiply(1.0 / len);
        for (double t = 0; t <= len; t += step) {
            int k = budget(1); if (k == 0) return;
            Location p = a.clone().add(d.clone().multiply(t));
            p.getWorld().spawnParticle(Particle.DUST_COLOR_TRANSITION, p, 1, 0, 0, 0, 0, new Particle.DustTransition(c1, c2, size));
        }
    }
    /** Spherical impact burst: coloured dust + electric sparks + end-rod glints. */
    public void burst(Location l, Color a, Color b, int n, double r) {
        sphere(l, r, n, a, b, 1.4f);
        part(Particle.ELECTRIC_SPARK, l, Math.max(2, n / 3), r * 0.4, 0.25);
        part(Particle.END_ROD, l, Math.max(1, n / 6), 0.15, r * 0.25);
    }
    public void explosion(Location l, double r, Color a, Color b) {
        burst(l, a, b, (int) (60 + r * 20), r);
        part(Particle.EXPLOSION_EMITTER, l, 1, 0, 0);
        part(Particle.EXPLOSION, l, 6, r * 0.4, 0);
    }

    // ---------------------------------------------------------------- display sprites
    public static Quaternionf orient(Vector dir, float roll) {
        Vector3f n = new Vector3f((float) dir.getX(), (float) dir.getY(), (float) dir.getZ());
        if (n.lengthSquared() < 1e-6f) n.set(0, 0, 1);
        n.normalize();
        Quaternionf q = new Quaternionf().rotationTo(new Vector3f(0, 0, 1), n);
        if (roll != 0f) q = new Quaternionf().fromAxisAngleRad(n, roll).mul(q);
        return q;
    }

    private ItemDisplay spawn(Location l, org.bukkit.inventory.ItemStack stack, Transformation t, Display.Billboard bb, int life) {
        if (tracked.size() >= maxDisplays || l.getWorld() == null) return null;
        final float vr = (float) viewRange;
        ItemDisplay d = l.getWorld().spawn(l, ItemDisplay.class, e -> {
            e.setItemStack(stack);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            e.setBillboard(bb);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setViewRange(vr);
            e.setPersistent(false); e.setGravity(false); e.setInvulnerable(true);
            e.setShadowRadius(0f); e.setShadowStrength(0f);
            e.addScoreboardTag(TAG);
            e.setTransformation(t);
            e.setInterpolationDuration(0); e.setTeleportDuration(1);
        });
        tracked.add(new Tracked(d, pl.casts().now() + life));
        return d;
    }

    /** Sprite whose face normal points along dir (e.g. a crescent slash flying at the target). */
    public ItemDisplay facing(Location l, String model, float w, float h, Vector dir, float roll, int life) {
        return spawn(l, pl.items().fx(model), new Transformation(new Vector3f(), orient(dir, roll), new Vector3f(w, h, 1f), new Quaternionf()), Display.Billboard.FIXED, life);
    }
    /** Always faces the viewer (orbs, flares, shields). */
    public ItemDisplay billboard(Location l, String model, float size, int life) {
        return spawn(l, pl.items().fx(model), new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(size, size, 1f), new Quaternionf()), Display.Billboard.CENTER, life);
    }
    /** Lies flat on the ground (shockwave rings, vortex discs, markers). */
    public ItemDisplay flat(Location l, String model, float size, float spin, int life) {
        Quaternionf q = new Quaternionf().rotationY(spin).mul(new Quaternionf().rotationX((float) (-Math.PI / 2)));
        return spawn(l, pl.items().fx(model), new Transformation(new Vector3f(), q, new Vector3f(size, size, 1f), new Quaternionf()), Display.Billboard.FIXED, life);
    }

    /** Any item (e.g. a player head for afterimages) as a camera-facing display. */
    public ItemDisplay item(Location l, org.bukkit.inventory.ItemStack stack, float scale, int life) {
        return spawn(l, stack, new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(scale, scale, scale), new Quaternionf()), Display.Billboard.VERTICAL, life);
    }

    public Transformation swordTransform(Weapon w, float scale, Vector dir) {
        Vector3f n = new Vector3f((float) dir.getX(), (float) dir.getY(), (float) dir.getZ());
        if (n.lengthSquared() < 1e-6f) n.set(0, 1, 0);
        n.normalize();
        Quaternionf q = new Quaternionf().rotationTo(new Vector3f(0.7071f, 0.7071f, 0f), n);   // model blade axis is the (1,1,0) diagonal
        float c = w == Weapon.NOISEFORM ? 0.375f : 0.4375f;                                   // blade-centre offset from the model origin
        Vector3f off = new Vector3f(c, c, 0f).mul(scale); q.transform(off); off.negate();
        return new Transformation(off, q, new Vector3f(scale, scale, scale), new Quaternionf());
    }
    /** A floating copy of the actual weapon model (Echo Blades, raised Final Frequency sword, stance sword). */
    public ItemDisplay sword(Location l, Weapon w, float scale, Vector dir, int life) {
        ItemDisplay d = spawn(l, pl.items().displayStack(w), swordTransform(w, scale, dir), Display.Billboard.FIXED, life);
        if (d != null) { d.setInterpolationDuration(2); d.setTeleportDuration(2); }
        return d;
    }
    public void aim(ItemDisplay d, Weapon w, float scale, Vector dir) {
        if (d != null && d.isValid()) { d.setInterpolationDelay(0); d.setTransformation(swordTransform(w, scale, dir)); }
    }

    /** Smoothly resize a sprite over `ticks` (client-side interpolation). Scheduled one tick later so the client sees the start state. */
    public void resize(Display d, int ticks, float w, float h) {
        if (d == null) return;
        org.bukkit.Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (!d.isValid()) return;
            Transformation t = d.getTransformation();
            d.setInterpolationDelay(0); d.setInterpolationDuration(ticks);
            d.setTransformation(new Transformation(t.getTranslation(), t.getLeftRotation(), new Vector3f(w, h, 1f), t.getRightRotation()));
        }, 1L);
    }
    /** Spin a flat/facing sprite about its own normal by `radians` over `ticks`. */
    public void spin(Display d, int ticks, float radians) {
        if (d == null || !d.isValid()) return;
        Transformation t = d.getTransformation();
        Quaternionf q = new Quaternionf().rotationY(radians).mul(t.getLeftRotation());
        d.setInterpolationDelay(0); d.setInterpolationDuration(ticks);
        d.setTransformation(new Transformation(t.getTranslation(), q, t.getScale(), t.getRightRotation()));
    }
    public void move(Entity e, Location l) { if (e != null && e.isValid()) e.teleport(l); }
    public void remove(Entity e) { if (e != null && e.isValid()) e.remove(); }

    public static double rnd(double a, double b) { return a + ThreadLocalRandom.current().nextDouble() * (b - a); }
}

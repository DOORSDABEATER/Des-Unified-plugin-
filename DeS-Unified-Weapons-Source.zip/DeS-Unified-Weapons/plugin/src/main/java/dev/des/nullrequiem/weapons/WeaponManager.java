package dev.des.nullrequiem.weapons;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Weapon identity. The item is identified ONLY through PersistentDataContainer (never name/lore),
 * is bound to an owner UUID and carries a unique serial registered in serials.yml, so copies made
 * from a renamed ordinary item (or a duplicated stack) are rejected.
 */
public final class WeaponManager {
    private final NullRequiemPlugin plugin;
    private final NamespacedKey keyWeapon, keyOwner, keySerial;
    private final Set<String> serials = new HashSet<>();
    private final File serialFile;

    public WeaponManager(NullRequiemPlugin plugin) {
        this.plugin = plugin;
        this.keyWeapon = new NamespacedKey(plugin.java(), "weapon");
        this.keyOwner = new NamespacedKey(plugin.java(), "owner");
        this.keySerial = new NamespacedKey(plugin.java(), "serial");
        this.serialFile = new File(plugin.getDataFolder(), "serials.yml");
        if (serialFile.exists()) serials.addAll(YamlConfiguration.loadConfiguration(serialFile).getStringList("serials"));
    }

    private void saveSerials() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("serials", new ArrayList<>(serials));
        try { y.save(serialFile); } catch (IOException e) { plugin.getLogger().warning("Could not save serials.yml: " + e.getMessage()); }
    }

    public ItemStack create(UUID ownerId, String ownerName) {
        Settings s = plugin.settings();
        Material mat = Material.matchMaterial(s.s("weapon.base-material", "NETHERITE_HOE"));
        if (mat == null) mat = Material.NETHERITE_HOE;
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(s.mm(s.s("weapon.display-name", "<gradient:#39ff14:#00a651><bold>NULL//REQUIEM</bold></gradient>")));
        List<Component> lore = new ArrayList<>();
        for (String line : s.list("weapon.lore")) lore.add(s.mm(line.replace("{owner}", ownerName == null ? "ERROR" : ownerName)));
        m.lore(lore);
        m.setUnbreakable(true);
        m.addItemFlags(ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES);
        m.setEnchantmentGlintOverride(true);
        NamespacedKey model = NamespacedKey.fromString(s.s("weapon.item-model", "nullrequiem:nullrequiem"));
        if (model != null) m.setItemModel(model);
        double dmg = s.d("weapon.attack-damage-modifier", 8.0);
        double spd = s.d("weapon.attack-speed-modifier", -2.6);
        m.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(new NamespacedKey(plugin.java(), "atk"), dmg, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        m.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(new NamespacedKey(plugin.java(), "spd"), spd, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        PersistentDataContainer pdc = m.getPersistentDataContainer();
        String serial = UUID.randomUUID().toString();
        pdc.set(keyWeapon, PersistentDataType.BYTE, (byte) 1);
        if (ownerId != null) pdc.set(keyOwner, PersistentDataType.STRING, ownerId.toString());
        pdc.set(keySerial, PersistentDataType.STRING, serial);
        it.setItemMeta(m);
        serials.add(serial);
        saveSerials();
        return it;
    }

    public boolean hasMarker(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(keyWeapon, PersistentDataType.BYTE);
    }

    /** Marker present AND serial registered (when enforcement is on). */
    public boolean isWeapon(ItemStack it) {
        if (!hasMarker(it)) return false;
        if (!plugin.settings().b("weapon.require-registered-serial", true)) return true;
        String s = it.getItemMeta().getPersistentDataContainer().get(keySerial, PersistentDataType.STRING);
        return s != null && serials.contains(s);
    }

    public UUID ownerOf(ItemStack it) {
        if (!hasMarker(it)) return null;
        String o = it.getItemMeta().getPersistentDataContainer().get(keyOwner, PersistentDataType.STRING);
        try { return o == null ? null : UUID.fromString(o); } catch (IllegalArgumentException e) { return null; }
    }

    public String serialOf(ItemStack it) {
        if (!hasMarker(it)) return null;
        return it.getItemMeta().getPersistentDataContainer().get(keySerial, PersistentDataType.STRING);
    }

    /** Owner binding: only the bound owner (or admins when allowed) may use the weapon. */
    public boolean canUse(Player p, ItemStack it) {
        if (!isWeapon(it)) return false;
        if (!p.hasPermission("nullrequiem.use")) return false;
        if (!plugin.settings().b("owner.enforce-binding", true)) return true;
        UUID o = ownerOf(it);
        if (o == null || o.equals(p.getUniqueId())) return true;
        return plugin.settings().b("owner.admins-can-use", false) && p.hasPermission("nullrequiem.admin");
    }

    public ItemStack held(Player p) { return p.getInventory().getItemInMainHand(); }

    public boolean holdsUsable(Player p) { return canUse(p, held(p)); }

    /** Removes every weapon stack from inventory + ender chest, revoking its serial. Returns amount removed. */
    public int removeAll(Player p) {
        int n = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (hasMarker(it)) { serials.remove(serialOf(it)); inv.setItem(i, null); n++; }
        }
        for (int i = 0; i < p.getEnderChest().getSize(); i++) {
            ItemStack it = p.getEnderChest().getItem(i);
            if (hasMarker(it)) { serials.remove(serialOf(it)); p.getEnderChest().setItem(i, null); n++; }
        }
        if (n > 0) saveSerials();
        return n;
    }

    /** Removes duplicated stacks (same serial twice in one inventory) and unregistered fakes carrying the marker. */
    public void sanitize(Player p) {
        Set<String> seen = new HashSet<>();
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack it = inv.getItem(i);
            if (!hasMarker(it)) continue;
            String s = serialOf(it);
            boolean fake = plugin.settings().b("weapon.require-registered-serial", true) && (s == null || !serials.contains(s));
            if (fake || !seen.add(s)) {
                inv.setItem(i, null);
                plugin.getLogger().warning("Removed duplicated/unregistered NULL//REQUIEM item from " + p.getName());
            }
        }
    }
}

package dev.des.nullrequiem.sounds;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;

/** Plays resource-pack sounds (namespace nullrequiem). Volumes are scaled by sounds.master-volume and sounds.volumes.<id>. */
public final class SoundManager {
    private final NullRequiemPlugin plugin;
    public SoundManager(NullRequiemPlugin plugin) { this.plugin = plugin; }

    private float vol(String id, float v) {
        double master = plugin.settings().d("sounds.master-volume", 1.0);
        double per = plugin.settings().d("sounds.volumes." + id, 1.0);
        return (float) (v * master * per);
    }

    public void play(Location l, String id, float volume, float pitch) {
        World w = l.getWorld();
        if (w == null) return;
        w.playSound(l, "nullrequiem:" + id, SoundCategory.PLAYERS, vol(id, volume), pitch);
    }

    public void play(Location l, String id) { play(l, id, 1.0f, 1.0f); }

    public void playTo(Player p, String id, float volume, float pitch) {
        p.playSound(p.getLocation(), "nullrequiem:" + id, SoundCategory.PLAYERS, vol(id, volume), pitch);
    }
}

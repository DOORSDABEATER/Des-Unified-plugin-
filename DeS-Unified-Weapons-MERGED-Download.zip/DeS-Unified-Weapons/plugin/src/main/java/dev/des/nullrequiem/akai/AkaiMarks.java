package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** SOVEREIGN'S AUTHORITY: up to 5 Sovereign Marks; 5 = ROYAL DECREE. Also the BLOOD MARK (sigil) from ability 03. */
public final class AkaiMarks {
    private static final class Mark { int stacks; long expires; UUID owner; ItemDisplay glyph; }
    private static final class Blood { UUID owner; long until; double bonus; ItemDisplay glyph; }

    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    private final Map<UUID, Mark> marks = new HashMap<>();
    private final Map<UUID, Blood> blood = new HashMap<>();
    private BukkitTask task;
    private int run;

    public AkaiMarks(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    private int max() { return m.settings().i("marks.max-stacks", 5); }

    public int stacks(LivingEntity t) {
        Mark k = marks.get(t.getUniqueId());
        if (k == null) return 0;
        if (k.expires < System.currentTimeMillis()) { drop(t.getUniqueId()); return 0; }
        return k.stacks;
    }

    public boolean isDecreed(LivingEntity t) { return stacks(t) >= max(); }
    public boolean hasBlood(LivingEntity t) { Blood b = blood.get(t.getUniqueId()); return b != null && b.until > System.currentTimeMillis(); }

    /** Total damage multiplier from marks (stacks, blood mark, royal decree). */
    public double mult(LivingEntity t, boolean decreeBonus) {
        double x = 1.0 + stacks(t) * m.settings().d("marks.damage-bonus-per-stack", 0.05);
        if (hasBlood(t)) x *= 1.0 + blood.get(t.getUniqueId()).bonus;
        if (decreeBonus && isDecreed(t)) x *= m.settings().d("marks.royal-decree-multiplier", 1.5);
        return x;
    }

    public void apply(Player src, LivingEntity t) {
        UUID id = t.getUniqueId();
        Mark k = marks.get(id);
        if (k == null) {
            if (marks.size() >= m.settings().i("marks.max-tracked", 80)) return;
            k = new Mark(); marks.put(id, k);
        }
        boolean was = k.stacks >= max();
        k.stacks = Math.min(max(), k.stacks + 1);
        k.owner = src.getUniqueId();
        k.expires = System.currentTimeMillis() + (long) (m.settings().d("marks.duration-seconds", 12) * 1000);
        Location l = t.getLocation().add(0, t.getHeight() / 2, 0);
        AkaiFx.sound(plugin, l, "mark", 0.7f, 0.8f + k.stacks * 0.1f);
        if (k.stacks >= max() && !was) {
            AkaiFx.sound(plugin, l, "decree", 1.2f, 1.0f);
            AkaiFx.decreeBurst(plugin, t);
            src.sendActionBar(m.settings().mm("<dark_red>[AKAI NO \u014c] <red><bold>ROYAL DECREE</bold> <gray>- " + t.getName() + " has been judged"));
            if (t instanceof Player tp) tp.sendActionBar(m.settings().mm("<red><bold>ROYAL DECREE</bold> <gray>- you have been judged"));
        }
    }

    /** Force a target to full stacks (used by the ultimate when the Domain closes). */
    public void forceDecree(Player src, LivingEntity t) {
        Mark k = marks.computeIfAbsent(t.getUniqueId(), x -> new Mark());
        k.stacks = max(); k.owner = src.getUniqueId();
        k.expires = System.currentTimeMillis() + (long) (m.settings().d("marks.duration-seconds", 12) * 1000);
    }

    public void bloodMark(Player src, LivingEntity t) {
        UUID id = t.getUniqueId();
        Blood old = blood.remove(id);
        if (old != null) plugin.tasks().release(old.owner, old.glyph);
        Blood b = new Blood();
        b.owner = src.getUniqueId();
        b.until = System.currentTimeMillis() + (long) (m.settings().ab(AkaiType.BLOOD_MARK, "duration-seconds", 12) * 1000);
        b.bonus = m.settings().ab(AkaiType.BLOOD_MARK, "damage-bonus", 0.25);
        b.glyph = plugin.vfx().display(b.owner, t.getLocation().add(0, t.getHeight() + 0.9, 0), "akai:glyph", new Vector3f(1.6f, 1.6f, 1.6f), new Quaternionf(), true, 2);
        blood.put(id, b);
    }

    public boolean isBloodOwner(UUID ownerId, LivingEntity t) { Blood b = blood.get(t.getUniqueId()); return b != null && b.owner.equals(ownerId) && b.until > System.currentTimeMillis(); }

    /** Called on death: blood-marked kill gives visual feedback and extra energy. Returns true when the target was blood marked. */
    public boolean onDeath(LivingEntity t) {
        UUID id = t.getUniqueId();
        boolean was = hasBlood(t);
        boolean decreed = isDecreed(t);
        if (was) AkaiFx.executionBurst(plugin, t.getLocation().add(0, t.getHeight() / 2, 0));
        drop(id);
        return was || decreed;
    }

    private void drop(UUID id) {
        Mark k = marks.remove(id);
        if (k != null && k.glyph != null) plugin.tasks().release(k.owner, k.glyph);
        Blood b = blood.remove(id);
        if (b != null && b.glyph != null) plugin.tasks().release(b.owner, b.glyph);
    }

    public void clear(UUID id) { drop(id); }

    public void start() { if (task == null) task = Bukkit.getScheduler().runTaskTimer(plugin.java(), this::tick, 20L, 5L); }

    public void stop() {
        if (task != null) task.cancel();
        task = null;
        for (UUID id : new java.util.ArrayList<>(marks.keySet())) drop(id);
        for (UUID id : new java.util.ArrayList<>(blood.keySet())) drop(id);
    }

    private void tick() {
        run++;
        long now = System.currentTimeMillis();
        int budget = m.settings().i("marks.visual-budget-per-tick", 24);
        int decreeDisplays = 0, cap = m.settings().i("marks.max-decree-displays", 8);
        for (Iterator<Map.Entry<UUID, Mark>> it = marks.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Mark> en = it.next(); Mark k = en.getValue();
            Entity e = Bukkit.getEntity(en.getKey());
            if (k.expires < now || !(e instanceof LivingEntity le) || !le.isValid() || le.isDead()) {
                if (k.glyph != null) plugin.tasks().release(k.owner, k.glyph);
                it.remove(); continue;
            }
            if (k.stacks >= max()) {
                if (k.glyph == null && decreeDisplays < cap) k.glyph = plugin.vfx().display(k.owner, le.getLocation().add(0, le.getHeight() + 0.7, 0), "akai:glyph", new Vector3f(1.4f, 1.4f, 1.4f), new Quaternionf(), true, 2);
                if (k.glyph != null) { decreeDisplays++; if (k.glyph.isValid()) { k.glyph.teleport(le.getLocation().add(0, le.getHeight() + 0.7, 0)); if (run % 4 == 0) plugin.vfx().animate(k.glyph, new Vector3f(1.4f, 1.4f, 1.4f), new Quaternionf().rotateY(run * 0.2f), 10); } }
            }
            if (budget-- > 0) AkaiFx.markVisual(plugin, le, k.stacks, run);
        }
        for (Iterator<Map.Entry<UUID, Blood>> it = blood.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, Blood> en = it.next(); Blood b = en.getValue();
            Entity e = Bukkit.getEntity(en.getKey());
            if (b.until < now || !(e instanceof LivingEntity le) || !le.isValid() || le.isDead()) {
                if (b.glyph != null) plugin.tasks().release(b.owner, b.glyph);
                it.remove(); continue;
            }
            if (b.glyph != null && b.glyph.isValid()) {
                b.glyph.teleport(le.getLocation().add(0, le.getHeight() + 0.9, 0));
                if (run % 4 == 0) plugin.vfx().animate(b.glyph, new Vector3f(1.6f, 1.6f, 1.6f), new Quaternionf().rotateY(-run * 0.25f), 10);
            }
            if (budget-- > 0) { var a = plugin.vfx().at(le.getLocation()); plugin.vfx().ring(a, le.getLocation().add(0, 0.1, 0), 0.9, 10, run * 0.3, AkaiFx.CRIM, 1.1f); }
        }
    }
}

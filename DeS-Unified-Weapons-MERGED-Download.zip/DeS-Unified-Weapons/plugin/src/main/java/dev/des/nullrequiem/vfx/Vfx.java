package dev.des.nullrequiem.vfx;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Matrix3f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Reusable effects toolkit. Everything is emerald/black: DUST (green/black), HAPPY_VILLAGER, BLOCK(emerald/black) and
 * ItemDisplay entities using the pack's 3D FX models. No vanilla blue/purple/orange particle is ever used.
 * Particle counts are scaled by vfx.particle-multiplier and by viewer distance (Audience).
 */
public final class Vfx {
    public static final Color NEON = Color.fromRGB(70, 255, 60);
    public static final Color EMERALD = Color.fromRGB(0, 190, 85);
    public static final Color DEEP = Color.fromRGB(0, 95, 45);
    public static final Color PALE = Color.fromRGB(190, 255, 200);
    public static final Color VOID = Color.fromRGB(6, 22, 12);

    private final NullRequiemPlugin plugin;
    private final Random rnd = new Random();
    private final Map<String, ItemStack> modelCache = new HashMap<>();

    public Vfx(NullRequiemPlugin plugin) { this.plugin = plugin; }

    // ------------------------------------------------------------------ audience
    public Audience at(Location c) { return new Audience(c); }

    public final class Audience {
        private final Player[] ps; private final float[] factor; private int n;
        private final double mult;

        Audience(Location c) {
            World w = c.getWorld();
            double max = plugin.settings().d("vfx.max-view-distance", 56);
            double red = plugin.settings().d("vfx.reduced-quality-distance", 28);
            float redF = (float) plugin.settings().d("vfx.reduced-quality-factor", 0.4);
            mult = plugin.settings().d("vfx.particle-multiplier", 1.0);
            java.util.List<Player> list = w == null ? java.util.List.of() : w.getPlayers();
            ps = new Player[list.size()]; factor = new float[list.size()];
            for (Player p : list) {
                double d2 = p.getLocation().distanceSquared(c);
                if (d2 > max * max) continue;
                ps[n] = p; factor[n++] = d2 > red * red ? redF : 1f;
            }
        }

        private int stoch(double v) { int b = (int) v; if (rnd.nextDouble() < v - b) b++; return b; }

        public <T> void particle(Particle p, Location l, int count, double dx, double dy, double dz, double speed, T data) {
            for (int i = 0; i < n; i++) {
                int c = stoch(count * factor[i] * mult);
                if (c > 0) ps[i].spawnParticle(p, l, c, dx, dy, dz, speed, data);
            }
        }

        public void particle(Particle p, Location l, int count, double dx, double dy, double dz, double speed) {
            for (int i = 0; i < n; i++) {
                int c = stoch(count * factor[i] * mult);
                if (c > 0) ps[i].spawnParticle(p, l, c, dx, dy, dz, speed);
            }
        }

        public void dust(Location l, int count, double spread, Color c, float size) {
            particle(Particle.DUST, l, count, spread, spread, spread, 0, new Particle.DustOptions(c, size));
        }

        public void trans(Location l, int count, double spread, Color a, Color b, float size) {
            particle(Particle.DUST_COLOR_TRANSITION, l, count, spread, spread, spread, 0, new Particle.DustTransition(a, b, size));
        }

        public void villager(Location l, int count, double spread) { particle(Particle.HAPPY_VILLAGER, l, count, spread, spread, spread, 0); }

        public void block(Location l, int count, double spread, Material m) {
            particle(Particle.BLOCK, l, count, spread, spread, spread, 0.1, Bukkit.createBlockData(m));
        }

        public void smoke(Location l, int count, double spread) { particle(Particle.SMOKE, l, count, spread, spread, spread, 0.01); }
        public void ink(Location l, int count, double spread) { particle(Particle.SQUID_INK, l, count, spread, spread, spread, 0.02); }
    }

    // ------------------------------------------------------------------ shapes
    public void ring(Audience a, Location c, double r, int pts, double phase, Color col, float size) {
        for (int i = 0; i < pts; i++) {
            double ang = phase + Math.PI * 2 * i / pts;
            a.dust(c.clone().add(Math.cos(ang) * r, 0, Math.sin(ang) * r), 1, 0, col, size);
        }
    }

    public void tiltedRing(Audience a, Location c, Vector axis, double r, int pts, double phase, Color col, float size) {
        Vector ax = axis.clone().normalize();
        Vector u = Math.abs(ax.getY()) < 0.9 ? ax.clone().crossProduct(new Vector(0, 1, 0)).normalize() : new Vector(1, 0, 0);
        Vector v = ax.clone().crossProduct(u).normalize();
        for (int i = 0; i < pts; i++) {
            double ang = phase + Math.PI * 2 * i / pts;
            Vector o = u.clone().multiply(Math.cos(ang) * r).add(v.clone().multiply(Math.sin(ang) * r));
            a.dust(c.clone().add(o), 1, 0, col, size);
        }
    }

    public void sphere(Audience a, Location c, double r, int pts, Color col, float size) {
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < pts; i++) {
            double y = 1 - (i / (double) Math.max(1, pts - 1)) * 2;
            double rad = Math.sqrt(Math.max(0, 1 - y * y));
            double th = golden * i;
            a.dust(c.clone().add(Math.cos(th) * rad * r, y * r, Math.sin(th) * rad * r), 1, 0, col, size);
        }
    }

    public void line(Audience a, Location from, Location to, double step, Color col, float size) {
        Vector d = to.toVector().subtract(from.toVector());
        double len = d.length();
        if (len < 0.01) return;
        d.normalize().multiply(step);
        Location cur = from.clone();
        for (double t = 0; t < len; t += step) { a.dust(cur, 1, 0, col, size); cur.add(d); }
    }

    /** Jagged emerald crack line between two points (used for fractures, chains, rifts). */
    public void crack(Audience a, Location from, Location to, double jitter, Color col, float size) {
        Vector d = to.toVector().subtract(from.toVector());
        double len = d.length();
        int segs = Math.max(2, (int) (len / 0.6));
        Location prev = from.clone();
        for (int i = 1; i <= segs; i++) {
            Location p = from.clone().add(d.clone().multiply(i / (double) segs));
            if (i < segs) p.add((rnd.nextDouble() - 0.5) * jitter, (rnd.nextDouble() - 0.5) * jitter, (rnd.nextDouble() - 0.5) * jitter);
            line(a, prev, p, 0.3, col, size);
            prev = p;
        }
    }

    public void column(Audience a, Location base, double height, double radius, int rings, Color col, float size) {
        for (int i = 0; i < rings; i++) ring(a, base.clone().add(0, height * i / Math.max(1, rings - 1), 0), radius, 8, rnd.nextDouble() * 6, col, size);
    }

    /** "404 glitch": short horizontal green bars at random offsets. */
    public void glitch(Audience a, Location c) {
        for (int k = 0; k < 3; k++) {
            double y = (rnd.nextDouble() - 0.2) * 1.8;
            double ox = (rnd.nextDouble() - 0.5) * 1.2, oz = (rnd.nextDouble() - 0.5) * 1.2;
            boolean alongX = rnd.nextBoolean();
            for (int i = 0; i < 6; i++) {
                double t = i * 0.2;
                a.dust(c.clone().add(ox + (alongX ? t : 0), y, oz + (alongX ? 0 : t)), 1, 0, rnd.nextBoolean() ? NEON : VOID, 1.0f);
            }
        }
    }

    /** Crescent drawn with dust (apex at pos, opening backwards). vertical=true makes a vertical slash plane. */
    public void arcCrescent(Audience a, Location pos, Vector dir, double radius, boolean vertical, Color col, float size) {
        arcCrescent(a, pos, dir, radius, vertical, NEON, PALE, size);
    }

    public void arcCrescent(Audience a, Location pos, Vector dir, double radius, boolean vertical, Color main, Color alt, float size) {
        Vector d = dir.clone().normalize();
        Vector right = d.clone().crossProduct(new Vector(0, 1, 0));
        if (right.lengthSquared() < 1e-6) right = new Vector(1, 0, 0);
        right.normalize();
        Vector side = vertical ? right.clone().crossProduct(d).normalize() : right;
        for (int deg = -70; deg <= 70; deg += 10) {
            double r = Math.toRadians(deg);
            Vector o = side.clone().multiply(Math.sin(r) * radius).add(d.clone().multiply((Math.cos(r) - 1) * radius * 0.9));
            a.dust(pos.clone().add(o), 1, 0.03, deg % 20 == 0 ? main : alt, size);
        }
    }

    // ------------------------------------------------------------------ displays
    private ItemStack modelStack(String model) {
        return modelCache.computeIfAbsent(model, m -> {
            ItemStack it = new ItemStack(Material.PAPER);
            ItemMeta meta = it.getItemMeta();
            NamespacedKey k = m.indexOf(':') >= 0 ? NamespacedKey.fromString(m) : new NamespacedKey("nullrequiem", m);
            meta.setItemModel(k);
            it.setItemMeta(meta);
            return it;
        });
    }

    /** Spawns a tracked, non-persistent ItemDisplay. Returns null when display entities are disabled or the live cap is reached. */
    public ItemDisplay display(UUID owner, Location loc, String model, Vector3f scale, Quaternionf rot, boolean glow, int teleportDuration) {
        if (!plugin.settings().b("vfx.use-display-entities", true)) return null;
        if (plugin.tasks().liveEntities() >= plugin.settings().i("vfx.max-live-displays", 160)) return null;
        World w = loc.getWorld();
        if (w == null) return null;
        final ItemStack stack = modelStack(model);
        final float view = (float) plugin.settings().d("vfx.display-view-range", 1.0);
        ItemDisplay d = w.spawn(loc, ItemDisplay.class, e -> {
            e.setItemStack(stack);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            e.setTransformation(new Transformation(new Vector3f(), rot == null ? new Quaternionf() : rot, scale, new Quaternionf()));
            e.setBrightness(new Display.Brightness(15, 15));
            e.setViewRange(view);
            e.setShadowRadius(0f);
            e.setPersistent(false);
            e.setInvulnerable(true);
            e.setGravity(false);
            e.setInterpolationDelay(0);
            e.setInterpolationDuration(0);
            e.setTeleportDuration(Math.max(0, Math.min(59, teleportDuration)));
            if (glow) { e.setGlowing(true); e.setGlowColorOverride(model.startsWith("akai:") ? Color.fromRGB(225, 25, 45) : NEON); }
        });
        plugin.tasks().track(owner, d);
        return d;
    }

    public void animate(ItemDisplay d, Vector3f scale, Quaternionf rot, int ticks) {
        if (d == null || !d.isValid()) return;
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(Math.max(1, ticks));
        d.setTransformation(new Transformation(new Vector3f(), rot == null ? new Quaternionf() : rot, scale, new Quaternionf()));
    }

    /** Rotation sending the model's +Y axis along forward, with +Z roughly along upHint. */
    public static Quaternionf orient(Vector forward, Vector upHint) {
        Vector3f y = new Vector3f((float) forward.getX(), (float) forward.getY(), (float) forward.getZ());
        if (y.lengthSquared() < 1e-6) return new Quaternionf();
        y.normalize();
        Vector3f z = new Vector3f((float) upHint.getX(), (float) upHint.getY(), (float) upHint.getZ());
        if (Math.abs(y.dot(z.normalize(new Vector3f()))) > 0.98f) z = new Vector3f(1, 0, 0);
        Vector3f x = new Vector3f(); y.cross(z, x); x.normalize();
        Vector3f zz = new Vector3f(); x.cross(y, zz); zz.normalize();
        return new Quaternionf().setFromNormalized(new Matrix3f(x, y, zz));
    }

    public static Quaternionf yaw(double radians) { return new Quaternionf().rotateY((float) radians); }

    // ------------------------------------------------------------------ signature effects
    public void drawBurst(Player p) {
        Location l = p.getLocation().add(0, 1.0, 0);
        Audience a = at(l);
        ring(a, p.getLocation().add(0, 0.1, 0), 1.4, 16, 0, NEON, 1.0f);
        a.villager(l, 6, 0.6);
        glitch(a, l);
    }

    public void idleAura(Player p, int stage, int run) {
        Location base = p.getLocation().add(0, 1.0, 0);
        Audience a = at(base);
        double t = run * 0.35;
        // stage I: subtle glitch + sparks around the weapon arm
        Vector dir = p.getLocation().getDirection().setY(0).normalize();
        Location hand = base.clone().add(dir.clone().multiply(0.5)).add(0, 0.3, 0);
        a.dust(hand.clone().add(rnd.nextGaussian() * 0.3, rnd.nextGaussian() * 0.5, rnd.nextGaussian() * 0.3), 1, 0, NEON, 0.8f);
        if (run % 12 == 0) glitch(a, base);
        if (stage >= 2) {
            a.trans(hand.clone().add(0, 0.9, 0), 2, 0.5, NEON, DEEP, 1.0f);
            a.villager(base, 1, 0.7);
            ring(a, base.clone().add(0, -0.85, 0), 0.9 + 0.2 * Math.sin(t), 6, t, EMERALD, 0.9f);
        }
        if (stage >= 3) {
            for (int i = 0; i < 3; i++) {
                double ang = t + i * Math.PI * 2 / 3;
                a.dust(base.clone().add(Math.cos(ang) * 1.3, 0.8 + Math.sin(t * 1.3 + i) * 0.5, Math.sin(ang) * 1.3), 1, 0, PALE, 1.2f);
            }
            a.ink(base.clone().add(0, 0.3, 0), 1, 0.5);
            if (run % 20 == 0) a.block(base, 6, 0.5, Material.EMERALD_BLOCK);
        }
    }

    public void hitBurst(Location l, boolean crit) {
        Audience a = at(l);
        a.dust(l, crit ? 20 : 8, 0.35, NEON, 1.1f);
        a.villager(l, crit ? 6 : 2, 0.3);
        if (crit) { glitch(a, l); a.block(l, 10, 0.3, Material.EMERALD_BLOCK); }
    }

    public void killEffect(Location l) {
        Audience a = at(l);
        a.block(l.clone().add(0, 1, 0), 40, 0.6, Material.EMERALD_BLOCK);
        a.dust(l.clone().add(0, 1, 0), 30, 0.7, NEON, 1.4f);
        column(a, l, 3.0, 0.6, 10, EMERALD, 1.1f);
        glitch(a, l);
        a.ink(l.clone().add(0, 1, 0), 10, 0.5);
    }

    /** Ground impact: emerald/black block debris + ring. */
    public void block(Audience a, Location c) {
        a.block(c.clone().add(0, 0.3, 0), 30, 0.8, Material.EMERALD_BLOCK);
        a.block(c.clone().add(0, 0.3, 0), 20, 0.8, Material.BLACK_CONCRETE);
        ring(a, c.clone().add(0, 0.15, 0), 1.6, 16, 0, NEON, 1.3f);
    }

    /** Expanding-looking spherical eruption (all green/black). */
    public void sphereBurst(Location c, double radius) {
        Audience a = at(c);
        sphere(a, c, radius, 40, NEON, 1.5f);
        sphere(a, c, radius * 0.6, 24, PALE, 1.2f);
        sphere(a, c, radius * 1.4, 30, DEEP, 1.4f);
        a.villager(c, 14, radius * 0.6);
        a.ink(c, 12, radius * 0.5);
        glitch(a, c);
    }
}

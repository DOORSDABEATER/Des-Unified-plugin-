package dev.des.nullrequiem.commands;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import dev.des.nullrequiem.abilities.AbilityManager;
import dev.des.nullrequiem.abilities.AbilityType;
import dev.des.nullrequiem.mastery.MasteryManager;
import dev.des.nullrequiem.storage.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class NullRequiemCommand implements TabExecutor {
    private final NullRequiemPlugin plugin;
    public NullRequiemCommand(NullRequiemPlugin plugin) { this.plugin = plugin; }

    private void say(CommandSender s, String mm) { s.sendMessage(plugin.settings().raw(plugin.settings().prefix() + mm)); }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("nullrequiem.admin")) return true;
        say(s, "<red>You do not have permission.");
        return false;
    }

    private Player target(CommandSender s, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) say(s, "<red>Player not found / offline: " + name);
        return p;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] a) {
        Settings st = plugin.settings();
        if (a.length == 0 || a[0].equalsIgnoreCase("help")) {
            say(sender, "<green>/nullrequiem <gray>give|remove|reload|mastery|fragments|stats|reset|test|ultimate|collection|camera|cast|select");
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "give" -> {
                if (!admin(sender) || a.length < 2) { if (a.length < 2) say(sender, "<gray>/nullrequiem give <player> [force]"); return true; }
                Player t = target(sender, a[1]); if (t == null) return true;
                String owner = st.s("owner.name", "ERROR");
                boolean force = a.length > 2 && a[2].equalsIgnoreCase("force");
                if (!t.getName().equalsIgnoreCase(owner) && !force) {
                    say(sender, "<yellow>NULL//REQUIEM is <green>" + owner + "<yellow>'s exclusive weapon. Use <white>/nullrequiem give " + t.getName() + " force<yellow> to override.");
                    return true;
                }
                ItemStack it = plugin.weapons().create(t.getUniqueId(), t.getName());
                var left = t.getInventory().addItem(it);
                if (!left.isEmpty()) { say(sender, "<red>Inventory full - nothing given."); plugin.weapons().removeAll(t); return true; }
                PlayerData d = plugin.data().get(t.getUniqueId());
                d.owned = true; d.obtainedAt = System.currentTimeMillis(); d.name = t.getName();
                say(sender, "<green>Gave NULL//REQUIEM to " + t.getName());
                t.sendMessage(st.raw("<dark_green>[NULL//REQUIEM] <green>REALITY FRACTURED. <gray>The Last Error in Reality is yours."));
            }
            case "remove" -> {
                if (!admin(sender) || a.length < 2) return true;
                Player t = target(sender, a[1]); if (t == null) return true;
                say(sender, "<green>Removed " + plugin.weapons().removeAll(t) + " weapon(s) from " + t.getName());
            }
            case "reload" -> { if (!admin(sender)) return true; plugin.reloadAll(); say(sender, "<green>Configuration reloaded."); }
            case "mastery" -> {
                if (!admin(sender) || a.length < 3) { if (a.length < 3) say(sender, "<gray>/nullrequiem mastery <player> <xp>  (negative = subtract)"); return true; }
                Player t = target(sender, a[1]); if (t == null) return true;
                try { long v = Long.parseLong(a[2]); if (v >= 0) plugin.mastery().addXp(t, v); else plugin.mastery().setXp(t, Math.max(0, plugin.data().get(t.getUniqueId()).xp + v)); }
                catch (NumberFormatException e) { say(sender, "<red>Invalid number."); return true; }
                say(sender, "<green>" + t.getName() + " XP: " + plugin.data().get(t.getUniqueId()).xp + " (stage " + plugin.mastery().stage(t) + ")");
            }
            case "fragments" -> {
                if (!admin(sender) || a.length < 3) return true;
                Player t = target(sender, a[1]); if (t == null) return true;
                try { plugin.fragments().set(t, Double.parseDouble(a[2])); } catch (NumberFormatException e) { say(sender, "<red>Invalid number."); return true; }
                say(sender, "<green>" + t.getName() + " fragments: " + (int) plugin.fragments().get(t));
            }
            case "stats" -> {
                Player t = a.length > 1 ? target(sender, a[1]) : sender instanceof Player p ? p : null;
                if (t == null) return true;
                if (!t.equals(sender) && !sender.hasPermission("nullrequiem.admin")) { say(sender, "<red>You do not have permission."); return true; }
                PlayerData d = plugin.data().get(t.getUniqueId());
                int stage = plugin.mastery().stage(d.xp);
                say(sender, "<green>" + t.getName() + " <gray>| stage <white>" + MasteryManager.NAMES[stage - 1] + " <gray>| xp <white>" + d.xp + " <gray>| kills <white>" + d.kills
                    + " <gray>| exposed kills <white>" + d.exposedKills + " <gray>| hits <white>" + d.hits + " <gray>| casts <white>" + d.casts + " <gray>| 404s <white>" + d.ultimates);
            }
            case "reset" -> {
                if (!admin(sender) || a.length < 2) return true;
                Player t = target(sender, a[1]); if (t == null) return true;
                plugin.data().reset(t.getUniqueId());
                plugin.cooldowns().reset(t);
                plugin.fragments().set(t, 0);
                say(sender, "<green>Progress reset for " + t.getName());
            }
            case "test" -> {
                if (!admin(sender)) return true;
                if (!(sender instanceof Player p)) { say(sender, "<red>Players only."); return true; }
                AbilityType t = a.length > 1 ? AbilityType.parse(a[1]) : null;
                if (t == null) { say(sender, "<red>Unknown ability. Use 1-12, 13/ultimate or the ability name."); return true; }
                var r = plugin.abilities().cast(p, t, true);
                say(sender, "<gray>test " + t.display() + ": <white>" + r);
            }
            case "ultimate" -> {
                if (!admin(sender) || a.length < 2) return true;
                Player t = target(sender, a[1]); if (t == null) return true;
                var r = plugin.abilities().cast(t, AbilityType.ULTIMATE, true);
                say(sender, "<gray>ultimate for " + t.getName() + ": <white>" + r);
            }
            case "collection" -> {
                if (!(sender instanceof Player p)) { say(sender, "<red>Players only."); return true; }
                if (!p.hasPermission("nullrequiem.collection")) { say(sender, "<red>You do not have permission."); return true; }
                Player t = p;
                if (a.length > 1) { if (!p.hasPermission("nullrequiem.admin")) { say(sender, "<red>You do not have permission."); return true; } t = target(sender, a[1]); if (t == null) return true; }
                plugin.collection().open(p, t);
            }
            case "camera" -> {
                if (!(sender instanceof Player p)) return true;
                if (a.length < 2) { say(sender, "<gray>/nullrequiem camera <on|off>"); return true; }
                boolean on = a[1].equalsIgnoreCase("on");
                plugin.data().get(p.getUniqueId()).cutsceneCamera = on;
                say(sender, "<green>Cinematic camera " + (on ? "enabled" : "disabled (you will stay in your own view during 404)"));
            }
            case "cast" -> {
                if (!(sender instanceof Player p)) return true;
                if (!p.hasPermission("nullrequiem.use")) { say(sender, "<red>You do not have permission."); return true; }
                AbilityType t = a.length > 1 ? AbilityType.parse(a[1]) : null;
                if (t == null) { say(sender, "<gray>/nullrequiem cast <1-12|ultimate|name>"); return true; }
                AbilityManager.Result r = plugin.abilities().cast(p, t, false);
                if (r == AbilityManager.Result.NOT_HOLDING) say(sender, "<yellow>Hold NULL//REQUIEM in your main hand.");
            }
            case "select" -> {
                if (!(sender instanceof Player p) || a.length < 2) return true;
                try { plugin.abilities().selectIndex(p, Integer.parseInt(a[1]) - 1); } catch (NumberFormatException e) { say(sender, "<red>Invalid number."); }
            }
            default -> say(sender, "<red>Unknown subcommand. /nullrequiem help");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String s : List.of("help", "give", "remove", "reload", "mastery", "fragments", "stats", "reset", "test", "ultimate", "collection", "camera", "cast", "select"))
                if (s.startsWith(a[0].toLowerCase())) out.add(s);
        } else if (a.length == 2) {
            String s = a[0].toLowerCase();
            if (List.of("give", "remove", "mastery", "fragments", "stats", "reset", "ultimate", "collection").contains(s))
                for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase().startsWith(a[1].toLowerCase())) out.add(p.getName());
            if (List.of("test", "cast").contains(s)) for (AbilityType t : AbilityType.values()) out.add(t.key());
            if (s.equals("camera")) { out.add("on"); out.add("off"); }
        }
        return out;
    }
}

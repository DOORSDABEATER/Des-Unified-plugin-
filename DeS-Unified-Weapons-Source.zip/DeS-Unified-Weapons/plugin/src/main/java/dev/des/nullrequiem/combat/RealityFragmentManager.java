package dev.des.nullrequiem.combat;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import dev.des.nullrequiem.abilities.CastContext;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

/** REALITY FRAGMENTS (0-100). All generation/consumption is server side and capped to prevent farming. */
public final class RealityFragmentManager {
    private final NullRequiemPlugin plugin;
    public RealityFragmentManager(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public double max() { return plugin.settings().d("fragments.max", 100); }
    public double get(Player p) { return plugin.states().get(p).fragments; }

    public void add(Player p, double amount) {
        if (amount <= 0) return;
        PlayerState st = plugin.states().get(p);
        st.fragments = Math.min(max(), st.fragments + amount);
    }

    public boolean spend(Player p, double amount) {
        PlayerState st = plugin.states().get(p);
        if (amount <= 0) return true;
        if (st.fragments + 1e-6 < amount) return false;
        st.fragments = Math.max(0, st.fragments - amount);
        return true;
    }

    public void set(Player p, double v) { plugin.states().get(p).fragments = Math.max(0, Math.min(max(), v)); }

    /** Called for the first hit on each target within a cast. */
    public void onHit(CastContext ctx, LivingEntity target) {
        Settings s = plugin.settings();
        Player p = ctx.player;
        double g = ctx.distinctHits() <= 1 ? s.d("fragments.per-hit", 3) : s.d("fragments.extra-target", 2);
        if (!(target instanceof Player) && !(target instanceof Monster)) g *= s.d("fragments.passive-mob-multiplier", 0.4);
        long now = System.currentTimeMillis();
        PlayerState st = ctx.state;
        Long last = st.fragRepeat.get(target.getUniqueId());
        if (last != null && now - last < s.d("fragments.repeat-window-seconds", 8) * 1000) g *= s.d("fragments.repeat-multiplier", 0.3);
        st.fragRepeat.put(target.getUniqueId(), now);
        g = Math.min(g, s.d("fragments.max-per-cast", 10) - ctx.gained);
        if (g <= 0) return;
        ctx.gained += g;
        add(p, g);
    }

    public void onKill(Player p, boolean exposed) {
        Settings s = plugin.settings();
        add(p, exposed ? s.d("fragments.exposed-kill", 25) : s.d("fragments.kill", 10));
    }

    /** Plain melee hit (vanilla swing with the scythe): small, rate-limited gain. */
    public void onMelee(Player p, LivingEntity target) {
        Settings s = plugin.settings();
        PlayerState st = plugin.states().get(p);
        long now = System.currentTimeMillis();
        double g = s.d("fragments.melee-hit", 2);
        if (!(target instanceof Player) && !(target instanceof Monster)) g *= s.d("fragments.passive-mob-multiplier", 0.4);
        Long last = st.fragRepeat.get(target.getUniqueId());
        if (last != null && now - last < s.d("fragments.repeat-window-seconds", 8) * 1000) g *= s.d("fragments.repeat-multiplier", 0.3);
        st.fragRepeat.put(target.getUniqueId(), now);
        add(p, g);
    }
}

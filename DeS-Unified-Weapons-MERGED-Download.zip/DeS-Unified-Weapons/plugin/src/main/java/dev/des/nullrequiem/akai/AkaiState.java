package dev.des.nullrequiem.akai;

import org.bukkit.Location;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class AkaiState {
    public int selected;
    public boolean busy;
    public boolean wasHolding;
    public long lastClickMs, msgUntil;
    public Location lastActiveLoc;
    public long lastActiveMs = System.currentTimeMillis();
    public final Map<UUID, Long> energyRepeat = new HashMap<>(), xpRepeat = new HashMap<>(), killRepeat = new HashMap<>();
    public long xpWindowStart; public int xpWindow;
    public int chain; public long chainUntil; public final Set<AkaiType> chainSet = new HashSet<>();
    // CRIMSON REVERSAL
    public long stanceUntil; public AkaiCtx stanceCtx; public boolean stanceResolved;

    public void prune(long now) {
        if (energyRepeat.size() > 64) energyRepeat.values().removeIf(t -> now - t > 60_000);
        if (xpRepeat.size() > 64) xpRepeat.values().removeIf(t -> now - t > 120_000);
        if (killRepeat.size() > 64) killRepeat.values().removeIf(t -> now - t > 600_000);
    }
}

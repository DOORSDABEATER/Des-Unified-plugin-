package dev.des.nullrequiem.cutscene;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.event.player.PlayerGameModeChangeEvent;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Safe capture / restore of players during the 404 cinematic.
 * Safety nets: (1) idempotent release, (2) restore on quit/death/world change, (3) restoreAll on shutdown,
 * (4) a pending-restore.yml written BEFORE a player is touched and replayed on next join (crash/kill -9 recovery).
 */
public final class CutsceneManager implements Listener {
    public static final class Captured {
        public UUID id; public GameMode mode; public Location loc; public boolean allowFlight, flying, camera;
        public float walk, fly;
        UUID owner;
    }

    private final NullRequiemPlugin plugin;
    private final Map<UUID, Captured> captured = new HashMap<>();
    private final File pendingFile;
    private boolean restoring;

    public CutsceneManager(NullRequiemPlugin plugin) {
        this.plugin = plugin;
        this.pendingFile = new File(plugin.getDataFolder(), "pending-restore.yml");
    }

    public boolean isCaptured(UUID id) { return captured.containsKey(id); }
    public Captured get(UUID id) { return captured.get(id); }
    public int count() { return captured.size(); }

    // ------------------------------------------------------------------ capture
    public Captured capture(Player p, UUID owner, boolean camera) {
        if (captured.containsKey(p.getUniqueId())) return captured.get(p.getUniqueId());
        Captured c = new Captured();
        c.id = p.getUniqueId(); c.owner = owner;
        c.mode = p.getGameMode(); c.loc = p.getLocation().clone();
        c.allowFlight = p.getAllowFlight(); c.flying = p.isFlying();
        c.walk = p.getWalkSpeed(); c.fly = p.getFlySpeed();
        c.camera = camera;
        writePending(c);                     // persist FIRST
        captured.put(c.id, c);
        p.setWalkSpeed(0f);
        p.setFlySpeed(0f);
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 20 * 30, 128, false, false, false));
        if (camera) p.setGameMode(GameMode.SPECTATOR);
        return c;
    }

    /** Idempotent. Restores game mode, speeds, flight and (for camera mode) the exact original location. */
    public void release(Player p, boolean teleportBack) {
        Captured c = captured.remove(p.getUniqueId());
        if (c == null) return;
        restoring = true;
        try {
            if (c.camera) p.setSpectatorTarget(null);
            p.setGameMode(c.mode);
            if (c.camera && teleportBack && c.loc.getWorld() != null) p.teleport(c.loc);
            p.setWalkSpeed(c.walk);
            p.setFlySpeed(c.fly);
            p.removePotionEffect(PotionEffectType.JUMP_BOOST);
            p.setAllowFlight(c.allowFlight || c.mode == GameMode.CREATIVE || c.mode == GameMode.SPECTATOR);
            if (c.flying && p.getAllowFlight()) p.setFlying(true);
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Cutscene restore problem for " + p.getName(), t);
        } finally {
            restoring = false;
            clearPending(p.getUniqueId());
        }
    }

    public void restoreAll(String reason) {
        for (UUID id : new java.util.ArrayList<>(captured.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) release(p, true);
            else captured.remove(id);
        }
    }


    /** Briefly leaves spectator (original mode, original spot) so the ultimate can damage a captured camera player. */
    public void exitCamera(Player p) {
        Captured c = captured.get(p.getUniqueId());
        if (c == null || !c.camera) return;
        restoring = true;
        try { p.setSpectatorTarget(null); p.setGameMode(c.mode); if (c.loc.getWorld() != null) p.teleport(c.loc); }
        finally { restoring = false; }
    }

    /** Puts a captured player back on the cinematic camera. */
    public void enterCamera(Player p, Entity cam) {
        Captured c = captured.get(p.getUniqueId());
        if (c == null || !c.camera || p.isDead() || !p.isOnline() || cam == null || !cam.isValid()) return;
        restoring = true;
        try { p.setGameMode(GameMode.SPECTATOR); p.setSpectatorTarget(cam); }
        finally { restoring = false; }
    }

    // ------------------------------------------------------------------ pending file (crash recovery)
    private void writePending(Captured c) {
        try {
            YamlConfiguration y = pendingFile.exists() ? YamlConfiguration.loadConfiguration(pendingFile) : new YamlConfiguration();
            String k = "p." + c.id;
            y.set(k + ".mode", c.mode.name());
            y.set(k + ".world", c.loc.getWorld().getName());
            y.set(k + ".x", c.loc.getX()); y.set(k + ".y", c.loc.getY()); y.set(k + ".z", c.loc.getZ());
            y.set(k + ".yaw", c.loc.getYaw()); y.set(k + ".pitch", c.loc.getPitch());
            y.set(k + ".allowFlight", c.allowFlight); y.set(k + ".walk", c.walk); y.set(k + ".fly", c.fly);
            y.save(pendingFile);
        } catch (IOException e) { plugin.getLogger().warning("Could not write pending-restore.yml: " + e.getMessage()); }
    }

    private void clearPending(UUID id) {
        if (!pendingFile.exists()) return;
        try {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(pendingFile);
            y.set("p." + id, null);
            y.save(pendingFile);
        } catch (IOException e) { plugin.getLogger().warning("Could not update pending-restore.yml: " + e.getMessage()); }
    }

    /** On join: a player left in a half-captured state by a crash gets their state back. */
    public void recoverPending(Player p) {
        if (!pendingFile.exists() || captured.containsKey(p.getUniqueId())) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(pendingFile);
        String k = "p." + p.getUniqueId();
        if (!y.contains(k)) return;
        try {
            restoring = true;
            GameMode gm = GameMode.valueOf(y.getString(k + ".mode", "SURVIVAL"));
            World w = Bukkit.getWorld(y.getString(k + ".world", ""));
            p.setSpectatorTarget(null);
            p.setGameMode(gm);
            if (w != null) p.teleport(new Location(w, y.getDouble(k + ".x"), y.getDouble(k + ".y"), y.getDouble(k + ".z"), (float) y.getDouble(k + ".yaw"), (float) y.getDouble(k + ".pitch")));
            p.setWalkSpeed((float) y.getDouble(k + ".walk", 0.2));
            p.setFlySpeed((float) y.getDouble(k + ".fly", 0.1));
            p.removePotionEffect(PotionEffectType.JUMP_BOOST);
            plugin.getLogger().info("Recovered " + p.getName() + " from an interrupted 404 cinematic.");
        } catch (Throwable t) {
            plugin.getLogger().log(Level.WARNING, "Recovery failed for " + p.getName(), t);
        } finally {
            restoring = false;
            clearPending(p.getUniqueId());
        }
    }

    // ------------------------------------------------------------------ guards while captured
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Captured c = captured.get(e.getPlayer().getUniqueId());
        if (c == null || c.camera || e.getTo() == null) return;
        Location f = e.getFrom();
        if (f.getX() != e.getTo().getX() || f.getY() != e.getTo().getY() || f.getZ() != e.getTo().getZ()) {
            Location t = f.clone(); t.setYaw(e.getTo().getYaw()); t.setPitch(e.getTo().getPitch());
            e.setTo(t);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (restoring || !captured.containsKey(e.getPlayer().getUniqueId())) return;
        if (e.getCause() == PlayerTeleportEvent.TeleportCause.PLUGIN && plugin.settings().b("ultimate.allow-plugin-teleports-while-captured", false)) return;
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onLeaveCameraMode(PlayerGameModeChangeEvent e) {
        Captured c = captured.get(e.getPlayer().getUniqueId());
        if (!restoring && c != null && c.camera && e.getNewGameMode() != GameMode.SPECTATOR) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (captured.containsKey(e.getPlayer().getUniqueId()) && !e.getPlayer().hasPermission("nullrequiem.admin")) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) { if (captured.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) { if (captured.containsKey(e.getPlayer().getUniqueId())) e.setCancelled(true); }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && captured.containsKey(p.getUniqueId())) e.setCancelled(true);
    }

    /** Captured players only take damage from the ultimate itself (delivered through DamageService). */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDamaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && captured.containsKey(p.getUniqueId()) && !plugin.damage().isInternal(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) { release(e.getPlayer(), true); }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) { release(e.getEntity(), false); }
}

package com.des.legendary;

/** Every ability. dmg = default raw damage (HP), cd = default cooldown seconds. All are overridable in config.yml. */
public enum AbilityId {
    SONIC_RUPTURE(Weapon.NOISEFORM, "Sonic Rupture", 6, 6, false),
    FREQUENCY_BREAK(Weapon.NOISEFORM, "Frequency Break", 5, 12, false),
    STATIC_OVERDRIVE(Weapon.NOISEFORM, "Static Overdrive", 3, 14, false),
    DISSONANCE(Weapon.NOISEFORM, "Dissonance", 6, 22, false),
    ECHO_BLADES(Weapon.NOISEFORM, "Echo Blades", 3, 18, false),
    RESONANCE_GUARD(Weapon.NOISEFORM, "Resonance Guard", 3, 25, false),
    FINAL_FREQUENCY(Weapon.NOISEFORM, "Final Frequency", 14, 60, true),

    PRISMATIC_CLEAVE(Weapon.NEBULUX, "Prismatic Cleave", 3, 8, false),
    STARFALL(Weapon.NEBULUX, "Starfall", 4, 20, false),
    GRAVITY_WELL(Weapon.NEBULUX, "Gravity Well", 7, 24, false),
    ASTRAL_FRACTURE(Weapon.NEBULUX, "Astral Fracture", 5, 17, false),
    CHROMATIC_REFRACTION(Weapon.NEBULUX, "Chromatic Refraction", 8, 26, false),
    CELESTIAL_PIERCE(Weapon.NEBULUX, "Celestial Pierce", 10, 18, false),
    SUPERNOVA(Weapon.NEBULUX, "Supernova", 16, 90, true);

    public final Weapon weapon;
    public final String display;
    public final double dmg, cd;
    public final boolean ultimate;

    AbilityId(Weapon w, String display, double dmg, double cd, boolean ult) {
        this.weapon = w; this.display = display; this.dmg = dmg; this.cd = cd; this.ultimate = ult;
    }

    /** kebab-case key used in config and commands, e.g. sonic-rupture. */
    public String key() { return name().toLowerCase().replace('_', '-'); }

    public static AbilityId byKey(String s) {
        for (AbilityId a : values()) if (a.key().equalsIgnoreCase(s) || a.name().equalsIgnoreCase(s)) return a;
        return null;
    }
}

# Testing report (be honest: nothing has been run in a live Minecraft/Paper server)

Legend: **Implemented** = code/asset written. **Built** = produced by a tool that ran here. **Tested** = executed in the real game. **Not tested** = never run.

| Item | Implemented | Built | Tested |
|---|---|---|---|
| Resource pack (models, animated textures, 18 FX sprites, 44 OGG sounds, sounds.json, item defs, pack.mcmeta, ZIP) | yes | **yes** (JSON/reference/OGG validation script passed: 0 problems) | **No** (not loaded in a client) |
| Model look / size | yes | software preview only (`previews/`) | **No** (first/third person, dropped, inventory, item frame untested) |
| Plugin source (all 14 abilities, passives, ultimates, combos, mastery, collection GUI, commands, persistence) | yes | **No JAR** - no Paper API / network here. Syntax-checked with javac: 0 syntax errors; remaining errors are only the missing Paper/Adventure/JOML classes | **No** |
| Ability activation, cooldowns, damage + armor, energy, mastery save, reconnect persistence, cleanup, multi-player load, console errors | yes | - | **No** (needs a server run) |

## What to test first (suggested order, ~15 min)
1. Build the JAR (GitHub Actions / Gradle). Fix any one-word API rename the compiler reports.
2. `/noiseform give`, `/nebulux give`: check size, held pose, inventory and drop look. Tune `display()` scales if needed.
3. `/weapon energy set <you> noiseform 100`, cast every ability on a zombie farm / second account (`targets.armor-stands: true` for dummies).
4. Check TPS during a 4-5 player fight with `/spark` or `/tps`; lower `vfx.particle-multiplier` if needed.
5. Relog and run `/weapon mastery` to confirm persistence.

## Known limitations / risks
* Untested numeric feel (projectile speeds, sizes, timings) - all configurable.
* Item-display sprite orientation (crescent roll, vortex spin) and the sword-model orientation for Echo Blades are derived mathematically; a flipped axis is possible and would be a one-line fix in `Fx`.
* `PLAYER_HEAD` afterimage fetches skins client-side (may show default skin on first spawn).
* Teleport / dash use `Player#teleport`; movement anti-cheat plugins may need an exemption.
* Supernova hover disables gravity for 2s; the plugin restores gravity on end/cancel/quit/death/disable.
* No Folia support. Single-threaded Paper API usage only (disk writes are async).

package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** One AKAI cast: per-target hit limits, damage multipliers (PvP/PvE/boss/marks), energy and mastery hooks. */
public final class AkaiCtx {
    public final NullRequiemPlugin plugin;
    public final AkaiModule m;
    public final Player player;
    public final AkaiState state;
    public final AkaiType type;
    public final UUID castId = UUID.randomUUID();
    public double gained;
    public int maxHits = 1;
    private final Map<UUID, Integer> hits = new HashMap<>();
    private boolean first;

    public AkaiCtx(NullRequiemPlugin plugin, AkaiModule m, Player p, AkaiState st, AkaiType type) { this.plugin = plugin; this.m = m; this.player = p; this.state = st; this.type = type; }

    public double cfg(String k, double def) { return m.settings().ab(type, k, def); }
    public int distinct() { return hits.size(); }

    public boolean hit(LivingEntity t, double raw, boolean decreeBonus) { return hit(t, raw, decreeBonus, 1.0); }

    public boolean hit(LivingEntity t, double raw, boolean decreeBonus, double extra) {
        int c = hits.getOrDefault(t.getUniqueId(), 0);
        if (c >= maxHits) return false;
        AkaiSettings s = m.settings();
        double a = raw * extra * s.d("damage.global-multiplier", 1.0) * (t instanceof Player ? s.d("damage.pvp-multiplier", 0.8) : s.d("damage.pve-multiplier", 1.5));
        if (plugin.damage().isBoss(t)) a *= s.d("damage.boss-multiplier", 0.4);
        a *= m.marks().mult(t, decreeBonus);
        if (!plugin.damage().damageRaw(player, t, a, s.d("damage.max-health-fraction-vs-players", 0.55))) return false;
        hits.put(t.getUniqueId(), c + 1);
        if (c == 0) { m.marks().apply(player, t); m.energy().onHit(this, t); }
        m.mastery().registerHit(player, type, t);
        m.store().get(player.getUniqueId()).hits++;
        if (!first) { first = true; m.energy().onCastHit(this); }
        return true;
    }
}

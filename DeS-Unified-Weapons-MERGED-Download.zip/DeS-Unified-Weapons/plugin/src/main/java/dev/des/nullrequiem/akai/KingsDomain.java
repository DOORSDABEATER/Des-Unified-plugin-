package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** 07 - royal battlefield: giant sigil, floating royal glyphs, configurable debuffs/bonuses, dramatic collapse. */
final class KingsDomain extends AkaiBase {
    KingsDomain(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.KINGS_DOMAIN); }

    private List<String> list(String key, List<String> def) { List<String> l = m.settings().list("abilities.kings_domain." + key); return l.isEmpty() ? def : l; }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        ctx.maxHits = 1;
        final Location c = Locs.ground(p.getLocation());
        final double r = cfg("radius", 10);
        final int dur = cfgI("duration-ticks", 200);
        final List<String> enemyFx = list("enemy-effects", List.of("SLOWNESS:1", "WEAKNESS:0"));
        final List<String> ownerFx = list("owner-effects", List.of("STRENGTH:0", "SPEED:0"));
        p.swingMainHand();
        snd(c, "a7_domain", 1.8f, 1.0f);
        final float full = (float) (r * 2.05);
        final ItemDisplay sigil = vfx().display(id, c.clone().add(0, 0.1, 0), "akai:sigil", new Vector3f(0.5f, 1f, 0.5f), new Quaternionf(), false, 0);
        plugin.tasks().later(id, 1, () -> vfx().animate(sigil, new Vector3f(full, 1f, full), new Quaternionf().rotateY(1.2f), 20));
        final List<ItemDisplay> glyphs = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            ItemDisplay g = vfx().display(id, c.clone().add(0, 2.5, 0), "akai:glyph", new Vector3f(1.8f, 1.8f, 1.8f), new Quaternionf(), true, 2);
            if (g != null) glyphs.add(g);
        }
        plugin.tasks().timer(id, 2, 2, dur / 2, t -> {
            if (!alive(p)) return false;
            Vfx.Audience a = vfx().at(c);
            double ph = t * 0.18;
            vfx().ring(a, c.clone().add(0, 0.12, 0), r, 40, ph, AkaiFx.CRIM, 1.2f);
            vfx().ring(a, c.clone().add(0, 0.12, 0), r * 0.6, 24, -ph, AkaiFx.GOLD, 1.0f);
            for (int k = 0; k < 3; k++) { // crimson wall
                double ang = Math.random() * Math.PI * 2;
                vfx().column(a, c.clone().add(Math.cos(ang) * r, 0, Math.sin(ang) * r), 4.5, 0.15, 5, AkaiFx.BLOOD, 1.3f);
            }
            a.block(c.clone().add((Math.random() - 0.5) * r, 0.3, (Math.random() - 0.5) * r), 3, 0.2, Material.REDSTONE_BLOCK);
            if (t % 4 == 0) AkaiFx.embers(plugin, c.clone().add((Math.random() - 0.5) * r * 1.4, 0.5, (Math.random() - 0.5) * r * 1.4), 4, 0.3);
            for (int i = 0; i < glyphs.size(); i++) {
                ItemDisplay g = glyphs.get(i);
                if (!g.isValid()) continue;
                double ang = ph * 0.6 + i * Math.PI * 2 / glyphs.size();
                g.teleport(c.clone().add(Math.cos(ang) * r * 0.55, 2.6 + Math.sin(ph * 2 + i) * 0.4, Math.sin(ang) * r * 0.55));
                if (t % 5 == 0) vfx().animate(g, new Vector3f(1.8f, 1.8f, 1.8f), new Quaternionf().rotateY((float) (ph * 2 + i)), 10);
            }
            if (t % 20 == 0) snd(c, "a7_loop", 0.8f, 1.0f);
            for (LivingEntity e : enemies(p, c, r)) applyEffects(e, enemyFx, 44);
            if (p.getWorld() == c.getWorld() && p.getLocation().distanceSquared(c) <= r * r) applyEffects(p, ownerFx, 44);
            return true;
        }, () -> {
            snd(c, "a7_collapse", 1.8f, 1.0f);
            if (sigil != null && sigil.isValid()) vfx().animate(sigil, new Vector3f(0.2f, 1f, 0.2f), new Quaternionf().rotateY(4f), 12);
            for (ItemDisplay g : glyphs) if (g.isValid()) g.teleport(c.clone().add(0, 1.5, 0));
            plugin.tasks().later(id, 14, () -> { plugin.tasks().release(id, sigil); for (ItemDisplay g : glyphs) plugin.tasks().release(id, g); });
            if (!alive(p)) return;
            shockRing(id, c, r, 10);
            AkaiFx.sphereBurst(plugin, c.clone().add(0, 1.2, 0), 3.0);
            for (LivingEntity e : enemies(p, c, r)) {
                if (ctx.hit(e, cfg("collapse-damage", 8), true)) {
                    Vector out = e.getLocation().toVector().subtract(c.toVector()).setY(0);
                    if (out.lengthSquared() > 1e-4) plugin.damage().push(p, e, out.normalize().multiply(1.1).setY(0.45), ctx.castId);
                }
            }
        });
        return true;
    }
}

# Abilities, passives, combos, mastery (all numbers are config defaults; HP = raw damage before armor)

## NOISEFORM (balanced) — Resonance 0-100
| Ability | Dmg | CD | Mechanics |
|---|---|---|---|
| Sonic Rupture | 6 | 6s | Crescent flies 12 blocks (1.5 b/tick), pierces 3, purple distortion trail, stops on blocks |
| Frequency Break | 5 | 12s | 0.3s wind-up, ground slam, 5-block shockwave expands over 0.5s, slight upward knock + brief slow-stun |
| Static Overdrive | 3 +3 | 14s | Collision-safe dash up to 7 blocks, afterimages (dust silhouette + player-head ghost), hits crossed enemies; next sword hit within 3s +3 |
| Dissonance | 6 | 22s | Vortex at aim point (24 range), r=4, pulls 2s, holds 0.5s, then explodes (knockback) |
| Echo Blades | 3 each | 18s | 3 floating copies of the real model, each picks its own target within 15 (shares if fewer), launched 0.3s apart; 3rd strike on one target = bonus knockback |
| Resonance Guard | pulse 3 | 25s | -40% damage for 3s, absorbed damage feeds Resonance, ends with a 5-block sonic pulse |
| **Final Frequency** (ult) | 14 | 60s | 100 Resonance. 1.5s visible charge (raised blade, converging rings, growing sphere), 18-block wave, ends in a large explosion |
Passive **Resonance Engine**: +12 per landed ability hit (max 24 per cast, mobs x0.5, 4s per-victim cooldown, no energy from AFK/dummy/armor-stand victims, ultimates give none). At 100 = **Overdrive** (orbiting energy, next ability auto-empowers). Spend 50 to empower: +25% damage plus a utility upgrade (Rupture +1 pierce/wider, Break +1 radius, Overdrive +1 dash & window, Dissonance +1 radius/+0.5s hold, Echo +1 blade, Guard +0.5s). Spend 100 for the ultimate. One spend per activation.

## NEBULUX (high skill) — Cosmic Energy 0-100
| Ability | Dmg | CD | Mechanics |
|---|---|---|---|
| Prismatic Cleave | 3/3/6 | 8s | Three slashes 0.4s apart, each launched along your CURRENT aim on a different arc (miss = no damage) |
| Starfall | 4 x3 | 20s | Aim within 18 blocks; marked impact zones; first meteor lands after 1.4s, then every 0.7s; 3rd is larger |
| Gravity Well | 7 | 24s | Cosmic sphere (24 range) -> 5-block field pulls 2s -> implodes |
| Astral Fracture | 5 | 17s | Teleport up to 8 blocks (blocks/border/lava/void-safe), leaves a rift; recast within 2s to snap back + energy slash. Recast is free (no cooldown) |
| Chromatic Refraction | counter 8 | 26s | -35% for 2.5s. A hit in the FIRST second triggers the perfect counter (homing rainbow bolt at the attacker, +10 energy); later hits only reduce damage |
| Celestial Pierce | 10 | 18s | 1s charge, aim tracks for 0.5s then LOCKS (solid warning line), beam travels 4 blocks/tick, pierces up to 6 within 16 blocks - dodgeable |
| **Supernova** (ult) | 16 | 90s | 100 energy. Rise slightly, 2s charge, red/white danger ring on the ground at r=8, prismatic shockwave, massive (capped) knockback, 2.5s nausea on hit players |
Passive **Cosmic Ascension**: energy from hits, perfect counters and combos. Empower upgrades are mechanical, not just damage (+10%): Cleave +25% hitbox & final slow, Starfall lingering slow fields, Gravity +1 radius/+0.5s, Fracture +1s window, Refraction +0.4s perfect window, Pierce wider +1 target.

## Combos (bonus only: +10 energy, +15 mastery XP, 8s chaining window, 8s award cooldown)
NOISEFORM: Static Overdrive -> Sonic Rupture -> Frequency Break (Sonic Execution) · Dissonance -> Echo Blades -> Final Frequency (Echo Trap)
NEBULUX: Gravity Well -> Starfall -> Celestial Pierce (Celestial Execution) · Astral Fracture -> Chromatic Refraction -> Prismatic Cleave (Dimensional Punishment)
A step counts when that cast lands at least one hit.

## Balance protection
Per-target hit keys (no double hits), max targets per cast, burst cap (24 ability HP per player per 3s), CC resistance (50% per repeat inside 4s, immune below 20%), boss CC x0.25 / boss damage multiplier, velocity cap 1.9, no self-damage, no energy/XP from AFK or dummy targets, `AbilityTargetEvent` for safe zones.

## Mastery (cosmetic/utility only)
XP 3 per ability hit, 1 per melee hit, 25 per player kill, 4 per mob kill; per-victim hourly caps; levels at 0/400/1200/2800/5500/10000.
L1 Awakening · L2 Resonance: extra cast rings · L3 Evolution: Guard +0.5s / Fracture window +0.5s · L4 Overdrive: bigger Rupture crescent & wider Overdrive window / final-cleave ring, +2s combo window · L5 Ascension: unique aura · L6 Transcendence: mastery visual + title.

package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.combat.DamageService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/** Controls: right-click cast | F next | Shift+F THRONE OF BLOOD | Q previous (the katana can never be dropped) | Shift+scroll cycle. */
final class AkaiListener implements Listener {
    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    AkaiListener(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    private boolean foreign(Player p, ItemStack it) { return m.weapon().hasMarker(it) && !m.weapon().canUse(p, it) && !p.hasPermission("akai.admin"); }

    @EventHandler public void onPreLogin(AsyncPlayerPreLoginEvent e) { if (e.getLoginResult() == AsyncPlayerPreLoginEvent.Result.ALLOWED) m.store().get(e.getUniqueId()); }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        AkaiData d = m.store().get(e.getPlayer().getUniqueId());
        d.name = e.getPlayer().getName();
        d.energy = Math.max(0, Math.min(m.energy().max(), d.energy));
    }

    @EventHandler(priority = EventPriority.MONITOR) public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer(); UUID id = p.getUniqueId();
        m.manager().abort(p);
        m.store().saveSync(id); m.store().unload(id); m.removeState(id);
    }

    @EventHandler public void onWorld(PlayerChangedWorldEvent e) { m.manager().abort(e.getPlayer()); }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND || (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK)) return;
        Player p = e.getPlayer(); ItemStack it = p.getInventory().getItemInMainHand();
        if (!m.weapon().hasMarker(it)) return;
        if (!m.weapon().canUse(p, it)) { p.sendActionBar(m.settings().mm("<red>AKAI NO \u014c answers only to its Sovereign.")); e.setCancelled(true); return; }
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null && e.getClickedBlock().getType().isInteractable() && !p.isSneaking()) return;
        e.setUseItemInHand(Event.Result.DENY); e.setUseInteractedBlock(Event.Result.DENY); e.setCancelled(true);
        if (plugin.cutscene().isCaptured(p.getUniqueId())) return;
        AkaiState st = m.state(p); long now = System.currentTimeMillis();
        if (now - st.lastClickMs < m.settings().i("controls.click-debounce-ticks", 4) * 50L) return;
        st.lastClickMs = now;
        m.manager().cast(p, AkaiType.ACTIVES[st.selected], false);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        if (!m.weapon().hasMarker(e.getOffHandItem()) && !m.weapon().hasMarker(e.getMainHandItem())) return;
        e.setCancelled(true);
        if (!m.weapon().canUse(p, e.getOffHandItem()) || plugin.cutscene().isCaptured(p.getUniqueId())) return;
        if (p.isSneaking() && m.settings().b("controls.sneak-swap-ultimate", true)) m.manager().cast(p, AkaiType.ULTIMATE, false);
        else m.manager().select(p, 1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrop(PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack();
        if (!m.weapon().hasMarker(it)) return;
        e.setCancelled(true);          // dropping / trading by dropping is impossible
        if (m.weapon().canUse(e.getPlayer(), it)) m.manager().select(e.getPlayer(), -1);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        if (!p.isSneaking() || !m.settings().b("controls.sneak-scroll-select", true)) return;
        if (!m.weapon().canUse(p, p.getInventory().getItem(e.getPreviousSlot()))) return;
        int a = e.getPreviousSlot(), b = e.getNewSlot();
        e.setCancelled(true);
        m.manager().select(p, (a == 8 && b == 0) ? 1 : (a == 0 && b == 8) ? -1 : Integer.signum(b - a));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player p && foreign(p, e.getItem().getItemStack())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (foreign(p, e.getCurrentItem()) || foreign(p, e.getCursor())) e.setCancelled(true);
    }

    private LivingEntity resolve(Entity d) {
        if (d instanceof LivingEntity le) return le;
        if (d instanceof Projectile pr && pr.getShooter() instanceof LivingEntity le) return le;
        return null;
    }

    /** Passive SOVEREIGN'S AUTHORITY on plain katana hits. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof LivingEntity victim) || plugin.damage().isInternal(victim.getUniqueId())) return;
        if (!(e.getDamager() instanceof Player p) || e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!m.weapon().holdsUsable(p) || plugin.cutscene().isCaptured(p.getUniqueId()) || !plugin.damage().canTarget(p, victim)) return;
        boolean full = p.getAttackCooldown() >= 0.9f;
        e.setDamage(e.getDamage() * m.marks().mult(victim, false));
        boolean crit = full && p.getFallDistance() > 0 && !p.isOnGround() && !p.isSprinting();
        if (full && m.settings().b("marks.melee-applies", true)) {
            m.marks().apply(p, victim);
            m.energy().onMelee(p, victim);
            m.mastery().registerHit(p, AkaiType.CRIMSON_DRAW, victim);
            m.store().get(p.getUniqueId()).hits++;
        }
        var l = victim.getLocation().add(0, victim.getHeight() / 2, 0);
        AkaiFx.hitBurst(plugin, l, crit);
        AkaiFx.sound(plugin, l, crit ? "crit" : full ? "hit_heavy" : "hit_light", crit ? 1.1f : 0.8f, 1.0f);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMeleeMonitor(EntityDamageByEntityEvent e) {
        if (e.getEntity() instanceof LivingEntity v && !plugin.damage().isInternal(v.getUniqueId()) && e.getDamager() instanceof Player p
            && e.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK && m.weapon().holdsUsable(p)) plugin.damage().tagHit(p, v, "akai");
    }

    /** CRIMSON REVERSAL window. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        AkaiState st = m.state(p);
        if (st.stanceResolved || System.currentTimeMillis() > st.stanceUntil) return;
        LivingEntity attacker = e instanceof EntityDamageByEntityEvent be ? resolve(be.getDamager()) : null;
        m.manager().reversal().onHurt(p, e, attacker);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        LivingEntity victim = e.getEntity(); UUID id = victim.getUniqueId();
        DamageService.Tag tag = plugin.damage().lastHit(id);
        Player killer = victim.getKiller();
        if (killer != null && !m.weapon().holdsUsable(killer) && !(tag != null && "akai".equals(tag.source()) && tag.attacker().equals(killer.getUniqueId()))) killer = null;
        if (killer == null && tag != null && "akai".equals(tag.source()) && System.currentTimeMillis() - tag.time() < 5000) killer = Bukkit.getPlayer(tag.attacker());
        boolean special = m.marks().onDeath(victim);
        if (killer != null && !killer.equals(victim) && m.weapon().isOwner(killer)) {
            m.energy().onKill(killer, special);
            m.mastery().registerKill(killer, victim, special);
            AkaiFx.executionBurst(plugin, victim.getLocation().add(0, 1, 0));
            AkaiFx.sound(plugin, victim.getLocation(), "kill", 1.2f, special ? 0.8f : 1.0f);
            killer.sendActionBar(m.settings().mm("<dark_red>[AKAI NO \u014c] <red><bold>JUDGEMENT COMPLETE.</bold> <gray>" + victim.getName() + (special ? " <dark_red>(decreed: energy restored)" : "")));
            m.state(killer).msgUntil = System.currentTimeMillis() + 1800;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        m.manager().abort(p);
        if (m.settings().b("energy.lose-on-death", true)) m.store().get(p.getUniqueId()).energy = 0;
    }
}

package com.des.legendary;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.EnumMap;
import java.util.List;

/** NOISEFORM - sonic destruction. Six abilities + Final Frequency. */
final class Noiseform {
    private Noiseform() {}

    static void register(LegendaryPlugin pl, EnumMap<AbilityId, Abilities.Handler> r) {
        r.put(AbilityId.SONIC_RUPTURE, c -> rupture(pl, c));
        r.put(AbilityId.FREQUENCY_BREAK, c -> frequency(pl, c));
        r.put(AbilityId.STATIC_OVERDRIVE, c -> dash(pl, c));
        r.put(AbilityId.DISSONANCE, c -> dissonance(pl, c));
        r.put(AbilityId.ECHO_BLADES, c -> echo(pl, c));
        r.put(AbilityId.RESONANCE_GUARD, c -> guard(pl, c));
        r.put(AbilityId.FINAL_FREQUENCY, c -> finalFrequency(pl, c));
    }

    private static Location mid(LivingEntity e) { return e.getBoundingBox().getCenter().toLocation(e.getWorld()); }

    // ------------------------------------------------------------------ 1. SONIC RUPTURE
    private static void rupture(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        double range = cfg.x(c.id, "range", 12), speed = cfg.x(c.id, "speed", 1.5), dmg = cfg.dmg(c.id);
        c.maxTargets = (int) cfg.x(c.id, "pierce", 3) + (c.empowered ? 1 : 0);
        double radius = 1.5 + (c.tier >= 4 ? 0.3 : 0) + (c.empowered ? 0.4 : 0);
        float size = 3.4f + (c.tier >= 4 ? 0.6f : 0f);
        p.swingMainHand();
        Vector dir = c.dir();
        Location pos = c.eye().add(dir.clone().multiply(1.3)).add(0, -0.25, 0);
        pl.sfx().play(p.getLocation(), "noiseform.rupture_cast", 1f, 1f);
        if (c.tier >= 2) fx.ring(p.getLocation().add(0, 0.1, 0), 1.3, 16, Pal.PURPLE, Pal.VIOLET, 1.2f);
        ItemDisplay d = c.track(fx.facing(pos, "crescent_purple", size, size, dir, (float) Math.toRadians(-18), (int) (range / speed) + 6));
        double[] trav = {0};
        pl.casts().start(c, age -> {
            boolean blocked = Proj.advance(pl, c, pos, dir, speed, radius, e -> {
                if (c.hit(e, "rupture", dmg)) {
                    Location l = mid(e);
                    pl.sfx().play(l, "noiseform.rupture_hit", 1f, 1f);
                    fx.burst(l, Pal.PURPLE, Pal.WHITE, 36, 1.1);
                    fx.part(Particle.SONIC_BOOM, l, 1, 0, 0);
                }
            });
            trav[0] += speed;
            fx.move(d, pos);
            fx.dust2(pos, Pal.PURPLE, Pal.DEEP, 1.8f, 6, 0.35);
            fx.part(Particle.REVERSE_PORTAL, pos, 4, 0.4, 0.08);
            fx.part(Particle.ELECTRIC_SPARK, pos, 2, 0.5, 0.1);
            if (c.tier >= 4) fx.dust(pos, Pal.WHITE, 1.0f, 2, 0.5);
            if (blocked || trav[0] >= range) { fx.burst(pos, Pal.PURPLE, Pal.WHITE, 30, 1.0); return true; }
            return false;
        }, null);
    }

    // ------------------------------------------------------------------ 2. FREQUENCY BREAK
    private static void frequency(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        double radius = cfg.x(c.id, "radius", 5) + (c.empowered ? 1 : 0), dmg = cfg.dmg(c.id);
        int stun = (int) cfg.x(c.id, "stun-ticks", 14);
        p.swingMainHand();
        Location[] ctr = {p.getLocation().clone()};
        pl.casts().start(c, age -> {
            if (age < 6) {                                               // wind-up: blade raised, energy gathers
                Location l = p.getLocation().add(0, 1, 0);
                fx.part(Particle.REVERSE_PORTAL, l, 6, 0.6, 0.1);
                fx.dust(l.clone().add(0, 1.2, 0), Pal.VIOLET, 1.3f, 4, 0.3);
                if (age == 0) pl.sfx().play(p.getLocation(), "noiseform.frequency_ring", 0.6f, 1.4f);
                return false;
            }
            if (age == 6) {                                              // slam
                ctr[0] = p.getLocation().clone();
                pl.sfx().play(ctr[0], "noiseform.frequency_slam", 1.5f, 1f);
                pl.sfx().play(ctr[0], "noiseform.frequency_ring", 1f, 0.9f);
                ItemDisplay ring = c.track(fx.flat(ctr[0].clone().add(0, 0.12, 0), "ring_purple", 1f, 0f, 24));
                fx.resize(ring, 10, (float) (radius * 2.1), (float) (radius * 2.1));
                fx.debris(ctr[0], 40, radius * 0.4);
                fx.part(Particle.EXPLOSION, ctr[0], 3, 0.5, 0);
                fx.part(Particle.CLOUD, ctr[0].clone().add(0, 0.2, 0), 14, radius * 0.3, 0.12);
            }
            int a = age - 6;
            double r = Math.min(radius, (a + 1) * radius / 10.0);
            Location g = ctr[0];
            fx.ring(g.clone().add(0, 0.15, 0), r, (int) (14 + r * 9), Pal.PURPLE, Pal.VIOLET, 1.5f);
            if (a % 2 == 0) fx.ring(g.clone().add(0, 0.5, 0), Math.max(0.5, r - 0.8), 18, Pal.DEEP, Pal.PURPLE, 1.1f);
            fx.debris(g.clone().add(Math.cos(a * 1.7) * r, 0.2, Math.sin(a * 1.7) * r), 3, 0.3);
            for (LivingEntity e : Targets.sphere(pl, p, g, r)) {
                if (Math.abs(e.getLocation().getY() - g.getY()) > 3.5) continue;     // ground wave: only things near the floor
                if (c.hit(e, "wave", dmg)) {
                    double m = c.ccMult(e);
                    Vector out = e.getLocation().toVector().subtract(g.toVector()).setY(0);
                    out = out.lengthSquared() < 1e-4 ? new Vector() : out.normalize().multiply(0.25);
                    pl.cc().velocity(e, out.setY(0.55), m);                       // slight upward knockback
                    pl.cc().slow(e, stun, 6, m);                                  // briefly interrupts movement
                    Location l = mid(e);
                    pl.sfx().play(l, "noiseform.rupture_hit", 0.9f, 0.8f);
                    fx.burst(l, Pal.PURPLE, Pal.WHITE, 24, 0.9);
                }
            }
            return a >= 10;
        }, null);
    }

    // ------------------------------------------------------------------ 3. STATIC OVERDRIVE
    private static void afterimage(LegendaryPlugin pl, Player p, Location at) {
        Fx fx = pl.fx();
        for (double y = 0; y <= 1.7; y += 0.28) fx.dust2(at.clone().add(0, y, 0), Pal.PURPLE, Pal.DEEP, 1.5f, 2, y > 1.0 ? 0.28 : 0.16);
        fx.dust(at.clone().add(0, 1.78, 0), Pal.VIOLET, 1.6f, 4, 0.18);
        Vector side = Util.flatDir(p).crossProduct(new Vector(0, 1, 0)).normalize();
        fx.line(at.clone().add(side.clone().multiply(-0.5)).add(0, 1.3, 0), at.clone().add(side.clone().multiply(0.5)).add(0, 1.3, 0), 0.2, Pal.VIOLET, Pal.PURPLE, 1.1f);
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        if (skull.getItemMeta() instanceof SkullMeta sm) { sm.setOwningPlayer(p); skull.setItemMeta(sm); }
        fx.item(at.clone().add(0, 1.65, 0), skull, 0.55f, 9);
    }

    private static void dash(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx(); PlayerData d = pl.data().get(p.getUniqueId());
        double dist = cfg.x(c.id, "distance", 7) + (c.empowered ? 1 : 0), dmg = cfg.dmg(c.id);
        Location start = p.getLocation().clone();
        Vector dir = p.getEyeLocation().getDirection();
        dir.setY(Math.max(-0.35, Math.min(0.35, dir.getY()))).normalize();
        Location end = SafeMove.walk(start, dir, dist);
        if (end.distanceSquared(start) < 1.0) { c.fail("No room to dash"); return; }
        Vector delta = end.toVector().subtract(start.toVector());
        int ticks = 4;
        pl.sfx().play(start, "noiseform.dash", 1f, 1f);
        p.swingMainHand();
        fx.burst(start.clone().add(0, 1, 0), Pal.PURPLE, Pal.WHITE, 24, 0.9);
        Location[] prev = {start.clone()};
        pl.casts().start(c, age -> {
            Location to = start.clone().add(delta.clone().multiply((age + 1) / (double) ticks));
            afterimage(pl, p, prev[0]);
            fx.line(prev[0].clone().add(0, 1, 0), to.clone().add(0, 1, 0), 0.25, Pal.PURPLE, Pal.WHITE, 1.4f);   // violet lightning trail
            fx.part(Particle.ELECTRIC_SPARK, to.clone().add(0, 1, 0), 8, 0.5, 0.25);
            p.teleport(to);
            for (Location s : List.of(to, prev[0].clone().add(to.toVector().subtract(prev[0].toVector()).multiply(0.5)))) {
                for (LivingEntity e : Targets.sphere(pl, p, s.clone().add(0, 1, 0), 1.6)) {
                    if (c.hit(e, "dash", dmg)) {
                        Location l = mid(e);
                        pl.sfx().play(l, "noiseform.rupture_hit", 0.9f, 1.3f);
                        fx.burst(l, Pal.PURPLE, Pal.WHITE, 22, 0.8);
                    }
                }
            }
            prev[0] = to;
            if (age + 1 >= ticks) {
                p.setVelocity(dir.clone().multiply(0.25));
                p.setFallDistance(0f);
                fx.burst(to.clone().add(0, 1, 0), Pal.VIOLET, Pal.WHITE, 26, 1.0);
                fx.part(Particle.SONIC_BOOM, to.clone().add(0, 1, 0), 1, 0, 0);
                d.bonusUntil = pl.casts().now() + cfg.ticks(c.id, "bonus-window", 3.0) + (c.tier >= 4 ? 20 : 0);   // mastery 4: wider window
                d.bonusDmg = cfg.x(c.id, "bonus-damage", 3.0) * c.dmgMul;
                return true;
            }
            return false;
        }, null);
    }

    // ------------------------------------------------------------------ 4. DISSONANCE
    private static void dissonance(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        double radius = cfg.x(c.id, "radius", 4) + (c.empowered ? 1 : 0), dmg = cfg.dmg(c.id), range = cfg.x(c.id, "range", 24);
        int pull = cfg.ticks(c.id, "pull-time", 2.0), hold = cfg.ticks(c.id, "hold-time", 0.5) + (c.empowered ? 10 : 0), total = pull + hold;
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 10);
        Location center = Util.aimPoint(pl, p, range);
        p.swingMainHand();
        pl.sfx().play(center, "noiseform.dissonance_start", 1.3f, 1f);
        ItemDisplay disc = c.track(fx.flat(center.clone().add(0, 0.12, 0), "vortex_purple", (float) (radius * 2.3), 0f, total + 30));
        ItemDisplay warn = c.track(fx.flat(center.clone().add(0, 0.1, 0), "ring_purple", (float) (radius * 2.0), 0f, total + 30));
        ItemDisplay orb = c.track(fx.billboard(center.clone().add(0, 1.3, 0), "orb_purple", 0.8f, total + 30));
        pl.casts().start(c, age -> {
            Location core = center.clone().add(0, 1.0, 0);
            if (age % 8 == 0) fx.spin(disc, 8, (float) Math.toRadians(150));
            if (age % 10 == 0) fx.resize(orb, 10, (float) (0.9 + 0.8 * (age / (double) total)), (float) (0.9 + 0.8 * (age / (double) total)));
            for (int arm = 0; arm < 3; arm++) for (int k = 0; k < 7; k++) {     // rotating vortex arms
                double h = k / 7.0, a = age * 0.45 + arm * 2.094 + h * 5.0, rr = radius * (1.0 - 0.8 * h);
                fx.dust2(center.clone().add(Math.cos(a) * rr, 0.15 + h * 2.2, Math.sin(a) * rr), Pal.PURPLE, Pal.VIOLET, 1.4f, 1, 0.02);
            }
            fx.part(Particle.REVERSE_PORTAL, core, 5, radius * 0.45, 0.2);        // pulling particles
            fx.dust(core, Pal.WHITE, 1.6f, 2, 0.25);                              // visible energy centre
            if (age < total) {
                for (LivingEntity e : Targets.sphere(pl, p, core, radius)) {
                    double m = c.ccMult(e); if (m <= 0) continue;
                    Vector v = core.toVector().subtract(mid(e).toVector());
                    double len = v.length();
                    if (age >= pull) { pl.cc().slow(e, 6, 6, m); v = len > 1.4 ? v.normalize().multiply(0.15) : new Vector(0, 0.03, 0); }
                    else v = len < 0.8 ? new Vector(0, 0.03, 0) : v.normalize().multiply(0.4);
                    v.setY(Math.max(-0.15, Math.min(0.3, v.getY())));
                    pl.cc().velocity(e, v, m);
                }
                return false;
            }
            for (LivingEntity e : Targets.sphere(pl, p, core, radius + 0.5)) {   // final explosion
                if (c.hit(e, "blast", dmg)) {
                    double m = c.ccMult(e);
                    Vector out = mid(e).toVector().subtract(core.toVector()).setY(0);
                    out = out.lengthSquared() < 1e-4 ? Util.flatDir(p) : out.normalize();
                    pl.cc().velocity(e, out.multiply(1.5).setY(0.5), m);
                }
            }
            pl.sfx().play(center, "noiseform.dissonance_explode", 1.8f, 1f);
            ItemDisplay ring = c.track(fx.flat(center.clone().add(0, 0.2, 0), "ring_purple", 1f, 0f, 14));
            fx.resize(ring, 7, (float) (radius * 2.8), (float) (radius * 2.8));
            fx.explosion(core, radius * 0.6, Pal.PURPLE, Pal.WHITE);
            fx.ring(center.clone().add(0, 0.2, 0), radius, 36, Pal.VIOLET, Pal.WHITE, 1.8f);
            fx.remove(disc); fx.remove(warn); fx.remove(orb);
            return true;
        }, null);
    }

    // ------------------------------------------------------------------ 5. ECHO BLADES
    private static Location orbit(Player p, int i, int n, int age) {
        double a = age * 0.12 + i * 2 * Math.PI / n;
        return p.getLocation().add(Math.cos(a) * 1.7, 2.0 + 0.25 * Math.sin(age * 0.15 + i * 2), Math.sin(a) * 1.7);
    }

    private static void echo(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        int n = (int) cfg.x(c.id, "blades", 3) + (c.empowered ? 1 : 0);
        double range = cfg.x(c.id, "range", 15) + (c.tier >= 3 ? 2 : 0), dmg = cfg.dmg(c.id), speed = cfg.x(c.id, "speed", 1.7);
        c.maxTargets = 12;
        ItemDisplay[] sw = new ItemDisplay[n]; Location[] pos = new Location[n]; LivingEntity[] tg = new LivingEntity[n];
        Vector[] hd = new Vector[n]; int[] state = new int[n], life = new int[n];
        for (int i = 0; i < n; i++) { pos[i] = orbit(p, i, n, 0); hd[i] = new Vector(0, 1, 0); sw[i] = c.track(fx.sword(pos[i], Weapon.NOISEFORM, 0.55f, new Vector(0.2, 1, 0), 220)); }
        pl.sfx().play(p.getLocation(), "noiseform.echo_summon", 1.1f, 1f);
        p.swingMainHand();
        final int startAt = 14, gap = 6;
        pl.casts().start(c, age -> {
            int open = 0;
            for (int i = 0; i < n; i++) {
                if (state[i] == 2) continue;
                open++;
                if (state[i] == 0) {                                          // orbiting spectral copy
                    pos[i] = orbit(p, i, n, age);
                    fx.move(sw[i], pos[i]);
                    fx.aim(sw[i], Weapon.NOISEFORM, 0.55f, new Vector(Math.cos(age * 0.2 + i) * 0.3, 1, Math.sin(age * 0.2 + i) * 0.3));
                    fx.dust2(pos[i], Pal.PURPLE, Pal.DEEP, 1.0f, 1, 0.1);
                    if (age >= startAt + i * gap) {                           // launch: each blade picks its own target
                        List<LivingEntity> cand = Targets.byDistance(Targets.sphere(pl, p, p.getLocation(), range), p.getLocation());
                        if (!cand.isEmpty()) tg[i] = cand.get(i % cand.size()); else hd[i] = p.getEyeLocation().getDirection().normalize();
                        state[i] = 1;
                        pl.sfx().play(pos[i], "noiseform.echo_launch", 0.9f, 1f + 0.1f * i);
                    }
                    continue;
                }
                Vector toward;
                if (tg[i] != null && tg[i].isValid() && !tg[i].isDead()) toward = mid(tg[i]).toVector().subtract(pos[i].toVector());
                else { tg[i] = null; toward = hd[i].clone(); }
                double dist = toward.length();
                toward.normalize(); hd[i] = toward.clone();
                Location from = pos[i].clone();
                boolean done = false;
                if (tg[i] != null && dist <= speed + 0.9) {
                    LivingEntity t = tg[i];
                    if (c.hit(t, "blade" + i, dmg)) {
                        int strikes = c.strikes.merge(t.getUniqueId(), 1, Integer::sum);
                        Location l = mid(t);
                        pl.sfx().play(l, "noiseform.echo_hit", 1f, 1f + 0.12f * strikes);
                        fx.burst(l, Pal.PURPLE, Pal.WHITE, 28, 1.0);
                        if (strikes >= 3) {                                    // third strike on the same target: bonus knockback
                            pl.cc().velocity(t, toward.clone().multiply(1.1).setY(0.4), c.ccMult(t));
                            fx.burst(l, Pal.VIOLET, Pal.WHITE, 40, 1.5);
                            fx.part(Particle.SONIC_BOOM, l, 1, 0, 0);
                        }
                    }
                    done = true;
                } else {
                    pos[i].add(toward.clone().multiply(speed));
                    if (tg[i] == null) {
                        for (LivingEntity e : Targets.sphere(pl, p, pos[i], 1.0)) if (c.hit(e, "blade" + i, dmg)) { fx.burst(mid(e), Pal.PURPLE, Pal.WHITE, 22, 0.9); pl.sfx().play(mid(e), "noiseform.echo_hit", 1f, 1f); done = true; break; }
                    }
                    if (!pos[i].getBlock().isPassable() || ++life[i] * speed > range + 10) { fx.burst(pos[i], Pal.PURPLE, Pal.WHITE, 14, 0.6); done = true; }
                }
                fx.line(from, pos[i], 0.3, Pal.PURPLE, Pal.VIOLET, 1.1f);
                fx.move(sw[i], pos[i]); fx.aim(sw[i], Weapon.NOISEFORM, 0.55f, toward);
                if (done) { state[i] = 2; fx.remove(sw[i]); }
            }
            return open == 0;
        }, null);
    }

    // ------------------------------------------------------------------ 6. RESONANCE GUARD
    private static void guard(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx(); PlayerData d = pl.data().get(p.getUniqueId());
        int dur = cfg.ticks(c.id, "duration", 3.0) + (c.tier >= 3 ? 10 : 0) + (c.empowered ? 10 : 0);   // mastery 3: +0.5s
        double pulseDmg = cfg.x(c.id, "pulse-damage", 3.0), pulseR = cfg.x(c.id, "pulse-radius", 5.0);
        PlayerData.Guard g = new PlayerData.Guard();
        g.w = Weapon.NOISEFORM; g.reduction = cfg.x(c.id, "reduction", 0.40); g.endTick = pl.casts().now() + dur;
        d.guard = g; c.maxTargets = 10;
        pl.sfx().play(p.getLocation(), "noiseform.guard_start", 1.1f, 1f);
        p.swingMainHand();
        fx.burst(p.getLocation().add(0, 1, 0), Pal.PURPLE, Pal.WHITE, 30, 1.2);
        ItemDisplay shield = c.track(fx.billboard(p.getLocation().add(0, 1, 0), "shield_purple", 0.5f, dur + 10));
        fx.resize(shield, 6, 3.3f, 3.3f);
        ItemDisplay stance = c.track(fx.sword(p.getLocation().add(0, 1.2, 0), Weapon.NOISEFORM, 0.9f, new Vector(0, 1, 0), dur + 10));
        pl.casts().start(c, age -> {
            if (d.guard != g) return true;
            Location chest = p.getLocation().add(0, 1.0, 0);
            fx.move(shield, chest);
            fx.move(stance, chest.clone().add(Util.flatDir(p).multiply(0.9)));
            fx.aim(stance, Weapon.NOISEFORM, 0.9f, new Vector(0, 1, 0.05));
            if (age % 2 == 0) for (int k = 0; k < 2; k++) for (int j = 0; j < 10; j++) {      // rotating soundwave rings
                double a = age * 0.3 + k * Math.PI + j * Math.PI * 2 / 10, tilt = k == 0 ? 0.5 : -0.5;
                fx.dust2(chest.clone().add(Math.cos(a) * 1.5, Math.sin(a) * 1.5 * tilt, Math.sin(a) * 1.5), Pal.PURPLE, Pal.VIOLET, 1.1f, 1, 0.0);
            }
            if (age >= dur) {                                                                  // expiry: outward sonic pulse
                d.guard = null;
                Location ctr = p.getLocation();
                pl.sfx().play(ctr, "noiseform.guard_pulse", 1.4f, 1f);
                ItemDisplay ring = c.track(fx.flat(ctr.clone().add(0, 0.15, 0), "ring_purple", 1f, 0f, 14));
                fx.resize(ring, 8, (float) (pulseR * 2.1), (float) (pulseR * 2.1));
                fx.ring(ctr.clone().add(0, 0.2, 0), pulseR * 0.8, 32, Pal.VIOLET, Pal.WHITE, 1.6f);
                fx.burst(ctr.clone().add(0, 1, 0), Pal.PURPLE, Pal.WHITE, 40, 1.8);
                for (LivingEntity e : Targets.sphere(pl, p, ctr.clone().add(0, 1, 0), pulseR)) {
                    if (c.hit(e, "pulse", pulseDmg)) {
                        Vector out = mid(e).toVector().subtract(ctr.toVector()).setY(0);
                        out = out.lengthSquared() < 1e-4 ? Util.flatDir(p) : out.normalize();
                        pl.cc().velocity(e, out.multiply(0.9).setY(0.3), c.ccMult(e));
                    }
                }
                return true;
            }
            return false;
        }, () -> { if (d.guard == g) d.guard = null; });
    }

    // ------------------------------------------------------------------ ULTIMATE: FINAL FREQUENCY
    private static void finalFrequency(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx(); PlayerData d = pl.data().get(p.getUniqueId());
        int charge = cfg.ticks(c.id, "charge-time", 1.5);
        double range = cfg.x(c.id, "range", 18), dmg = cfg.dmg(c.id), speed = cfg.x(c.id, "speed", 1.6), width = cfg.x(c.id, "width", 3.0);
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 10);
        c.requireHeld = true;
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, charge + 6, 3, false, false, false));
        Location eye0 = p.getEyeLocation();
        ItemDisplay raised = c.track(fx.sword(p.getLocation().add(0, 2.7, 0), Weapon.NOISEFORM, 1.2f, new Vector(0, 1, 0), charge + 40));
        ItemDisplay orb = c.track(fx.billboard(eye0.clone().add(eye0.getDirection().multiply(2.6)), "orb_purple", 0.3f, charge + 10));
        fx.resize(orb, charge, 3.4f, 3.4f);
        ItemDisplay halo = c.track(fx.flat(p.getLocation().add(0, 0.1, 0), "ring_purple", 7f, 0f, charge + 10));
        pl.sfx().play(p.getLocation(), "noiseform.final_charge", 2.2f, 1f);
        Location[] pos = new Location[1]; Vector[] dir = new Vector[1]; ItemDisplay[] wave = new ItemDisplay[1];
        double[] trav = {0}; boolean[] released = {false};
        pl.casts().start(c, age -> {
            if (age < charge) {                                                 // 1.5s charging sequence (visible to everyone nearby)
                Location base = p.getLocation(); double prog = age / (double) charge;
                fx.move(raised, base.clone().add(0, 2.7 + Math.sin(age * 0.2) * 0.1, 0));
                fx.spin(halo, 2, (float) Math.toRadians(40));
                Location fr = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(2.6));
                fx.move(orb, fr);
                if (age % 6 == 0) p.swingMainHand();
                double r = 3.8 * (1 - prog) + 0.5;
                fx.ring(base.clone().add(0, 0.2 + prog * 1.5, 0), r, 24, Pal.PURPLE, Pal.WHITE, 1.4f);
                fx.ring(base.clone().add(0, 2.4 - prog, 0), r * 0.8, 18, Pal.VIOLET, Pal.PURPLE, 1.2f);
                for (int k = 0; k < 3; k++) {
                    double a = age * 0.5 + k * 2.09;
                    fx.line(fr.clone().add(Math.cos(a) * r * 1.2, Math.sin(a * 1.3) * r * 0.6, Math.sin(a) * r * 1.2), fr, 0.6, Pal.PURPLE, Pal.WHITE, 1.1f);
                }
                fx.part(Particle.ELECTRIC_SPARK, fr, 3, r * 0.4, 0.15);
                return false;
            }
            if (age == charge) {                                                // release
                released[0] = true; c.requireHeld = false;
                p.removePotionEffect(PotionEffectType.SLOWNESS);
                fx.remove(raised); fx.remove(orb); fx.remove(halo);
                dir[0] = p.getEyeLocation().getDirection().normalize();
                pos[0] = p.getEyeLocation().add(dir[0].clone().multiply(1.8));
                wave[0] = c.track(fx.facing(pos[0], "crescent_purple", 8f, 8f, dir[0], (float) Math.toRadians(-12), (int) (range / speed) + 12));
                pl.sfx().play(p.getLocation(), "noiseform.final_release", 3.0f, 1f);
                p.swingMainHand();
                fx.burst(pos[0], Pal.PURPLE, Pal.WHITE, 60, 2.0);
                return false;
            }
            boolean blocked = Proj.advance(pl, c, pos[0], dir[0], speed, width, e -> {
                if (c.hit(e, "wave", dmg)) {
                    pl.cc().velocity(e, dir[0].clone().multiply(0.9).setY(0.45), c.ccMult(e));
                    Location l = mid(e);
                    pl.sfx().play(l, "noiseform.rupture_hit", 1.4f, 0.7f);
                    fx.burst(l, Pal.PURPLE, Pal.WHITE, 40, 1.4);
                }
            });
            trav[0] += speed;
            fx.move(wave[0], pos[0]);
            fx.dust2(pos[0], Pal.PURPLE, Pal.WHITE, 2.4f, 14, 1.2);
            fx.sphere(pos[0], 2.2, 16, Pal.VIOLET, Pal.PURPLE, 1.5f);
            fx.part(Particle.REVERSE_PORTAL, pos[0], 8, 1.4, 0.15);
            if ((age - charge) % 3 == 0) fx.part(Particle.SONIC_BOOM, pos[0], 1, 0, 0);
            if (blocked || trav[0] >= range) {                                  // ends in a large purple explosion
                Location ex = pos[0].clone();
                pl.sfx().play(ex, "noiseform.final_explode", 3.2f, 1f);
                ItemDisplay ring = c.track(fx.flat(ex.clone().add(0, 0.1, 0), "ring_purple", 1f, 0f, 16));
                fx.resize(ring, 8, 13f, 13f);
                ItemDisplay sph = c.track(fx.billboard(ex, "orb_purple", 1f, 14));
                fx.resize(sph, 6, 9f, 9f);
                fx.explosion(ex, 4.5, Pal.PURPLE, Pal.WHITE);
                fx.ring(ex.clone().add(0, 0.2, 0), 5.0, 48, Pal.VIOLET, Pal.WHITE, 2.0f);
                for (LivingEntity e : Targets.sphere(pl, p, ex, 5.0)) {
                    if (c.hit(e, "wave", dmg)) {
                        Vector out = mid(e).toVector().subtract(ex.toVector()).setY(0);
                        out = out.lengthSquared() < 1e-4 ? dir[0].clone() : out.normalize();
                        pl.cc().velocity(e, out.multiply(1.1).setY(0.5), c.ccMult(e));
                    }
                }
                fx.remove(wave[0]);
                return true;
            }
            return false;
        }, () -> {
            p.removePotionEffect(PotionEffectType.SLOWNESS);
            if (c.cancelled && !released[0]) d.cooldowns.remove(c.id.key());     // cancelled before release: no cooldown (energy refunded by CastManager)
        });
    }
}

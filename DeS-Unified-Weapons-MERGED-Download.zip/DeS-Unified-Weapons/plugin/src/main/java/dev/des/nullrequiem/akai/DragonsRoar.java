package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** 06 - a crimson dragon (display-entity chain) surges forward as a shockwave and detonates. */
final class DragonsRoar extends AkaiBase {
    DragonsRoar(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.DRAGONS_ROAR); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        ctx.maxHits = 2;
        Location eye = p.getEyeLocation();
        final Vector dir = eye.getDirection().clone(); dir.setY(dir.getY() * 0.25).normalize();
        final Location pos = eye.clone().add(dir.clone().multiply(2.0)).subtract(0, 0.6, 0);
        final double range = cfg("range", 18), speed = cfg("speed", 1.1), radius = cfg("hit-radius", 3.0), dmg = cfg("damage", 11);
        final AkaiDragon dragon = new AkaiDragon(plugin, id, pos, dir, cfgI("segments", 7), (float) cfg("scale", 1.8));
        p.swingMainHand();
        snd(p.getLocation(), "a6_roar", 1.5f, 1.0f);
        final Set<UUID> hit = new HashSet<>(); final double[] trav = {0};
        plugin.tasks().timer(id, 1, 1, (int) (range / speed) + 3, t -> {
            if (!alive(p)) return false;
            pos.add(dir.clone().multiply(speed)); trav[0] += speed;
            if (!pos.getBlock().isPassable()) return false;
            dragon.move(pos);
            Vfx.Audience a = vfx().at(pos);
            a.dust(pos, 5, 0.9, AkaiFx.CRIM, 1.3f);
            if (t % 3 == 0) AkaiFx.lightning(plugin, a, pos.clone().add(0, 1.5, 0), pos.clone().subtract(0, 1.2, 0));
            if (t % 4 == 0) vfx().ring(a, pos.clone().subtract(0, 0.5, 0), radius, 20, t, AkaiFx.BLOOD, 1.2f);
            for (LivingEntity e : enemies(p, pos, radius)) {
                if (!hit.add(e.getUniqueId())) continue;
                if (ctx.hit(e, dmg, false)) {
                    AkaiFx.hitBurst(plugin, e.getLocation().add(0, 1, 0), m.marks().isDecreed(e));
                    snd(e.getLocation(), "a6_impact", 0.9f, 1.0f);
                    plugin.damage().push(p, e, dir.clone().multiply(0.8).setY(0.3), ctx.castId);
                }
            }
            return trav[0] < range;
        }, () -> {
            Location end = pos.clone();
            snd(end, "a6_impact", 1.5f, 0.8f);
            AkaiFx.sphereBurst(plugin, end, 2.8);
            shockRing(id, end.clone().subtract(0, 0.8, 0), 5.0, 8);
            for (LivingEntity e : enemies(p, end, 4.0)) if (ctx.hit(e, cfg("explosion-damage", 5), false)) plugin.damage().push(p, e, e.getLocation().toVector().subtract(end.toVector()).setY(0).normalize().multiply(0.9).setY(0.35), ctx.castId);
            dragon.dissolve(true);
        });
        return true;
    }
}

package com.des.legendary;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.*;

/** State of one ability activation. Owns the display entities it spawns and the per-target hit bookkeeping. */
public final class Ctx {
    public final LegendaryPlugin pl;
    public final Player p;
    public final Weapon w;
    public final AbilityId id;
    public final boolean empowered;
    public final int tier;                       // mastery level of the caster (1-6)
    public double dmgMul = 1.0;
    public int maxTargets = 8;
    public boolean cancelled, landed, requireHeld, failed;
    public String failMsg = "";
    public double energyGained, refundEnergy;
    public final Map<UUID, Set<String>> done = new HashMap<>();   // targets -> hit keys already applied (per-target hit limit)
    public final Set<UUID> targets = new HashSet<>();
    public final Map<UUID, Integer> strikes = new HashMap<>();
    private final Map<UUID, Double> cc = new HashMap<>();
    private final List<Entity> ents = new ArrayList<>();

    public Ctx(LegendaryPlugin pl, Player p, Weapon w, AbilityId id, boolean empowered, int tier) {
        this.pl = pl; this.p = p; this.w = w; this.id = id; this.empowered = empowered; this.tier = tier;
    }

    public boolean hit(LivingEntity t, String key, double base) { return pl.dmg().hit(this, t, key, base); }
    /** Crowd-control multiplier for this target, computed once per cast (resistance / boss scaling / protection). */
    public double ccMult(LivingEntity t) { return cc.computeIfAbsent(t.getUniqueId(), k -> pl.cc().apply(p, t, id)); }
    public <T extends Entity> T track(T e) { if (e != null) ents.add(e); return e; }
    public void fail(String msg) { failed = true; failMsg = msg; }
    public Location eye() { return p.getEyeLocation(); }
    public Vector dir() { return p.getEyeLocation().getDirection().normalize(); }
    void cleanup() { for (Entity e : ents) if (e.isValid()) e.remove(); ents.clear(); }
}

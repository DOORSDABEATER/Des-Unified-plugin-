package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.cutscene.CutsceneManager;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * THRONE OF BLOOD. 1 Imperial Awakening (warning, circle, sky embers, royal glyphs) -> 2 Crimson Domain (capture inside radius only,
 * enemies marked ROYAL DECREE) -> 3 Dragon Emperor (shared camera, colossal dragon, giant blade) -> 4 Final Decree (damage exactly at
 * impact + dragon dive + explosion) -> 5 Sovereign Remains (embers, collapse, release, cleanup).
 * Capture/camera/restore safety is delegated to the shared CutsceneManager (pending-restore file, quit/death/shutdown handlers).
 */
public final class AkaiUltimate {
    private static final class Run {
        Player caster; UUID id; AkaiCtx ctx; Location anchor, ground; Vector fwd, right;
        double radius; int W, C; double sf;
        final List<Player> players = new ArrayList<>();
        final List<LivingEntity> mobs = new ArrayList<>();
        final Map<UUID, Boolean> ai = new HashMap<>();
        ArmorStand cam; ItemDisplay katana, circle; AkaiDragon dragon; Location dragonPos;
        final List<ItemDisplay> glyphs = new ArrayList<>();
        boolean captured, impacted, exploded, dissolved, collapsed, t1, t2, t3, finished;
    }

    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    private final Map<UUID, Run> runs = new HashMap<>();

    public AkaiUltimate(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    public boolean isRunning(UUID id) { return runs.containsKey(id); }

    public boolean start(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        if (runs.containsKey(id)) return false;
        final Run r = new Run();
        r.caster = p; r.id = id; r.ctx = ctx;
        r.anchor = p.getLocation().clone(); r.ground = Locs.ground(r.anchor);
        r.fwd = Locs.flat(p.getLocation().getDirection());
        r.right = r.fwd.clone().crossProduct(new Vector(0, 1, 0)).normalize();
        r.radius = ctx.cfg("radius", 14);
        r.W = (int) Math.max(30, ctx.cfg("warning-ticks", 50));
        r.C = (int) Math.max(100, ctx.cfg("cinematic-ticks", 160));
        r.sf = r.C / 160.0;
        ctx.maxHits = 1;
        ctx.state.busy = true;
        runs.put(id, r);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, r.W + r.C + 40, 6, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, r.W + r.C + 40, 128, false, false, false));
        p.swingMainHand();
        announce(r);
        r.circle = plugin.vfx().display(id, r.ground.clone().add(0, 0.1, 0), "akai:sigil", new Vector3f(0.5f, 1f, 0.5f), new Quaternionf(), false, 0);
        final float full = (float) (r.radius * 2.05);
        plugin.tasks().later(id, 1, () -> plugin.vfx().animate(r.circle, new Vector3f(full, 1f, full), new Quaternionf().rotateY(1.6f), 40));
        r.katana = plugin.vfx().display(id, r.anchor.clone().add(r.fwd.clone().multiply(0.9)).add(0, 1.3, 0), "akai:katana", new Vector3f(2.6f, 2.6f, 2.6f), new Quaternionf(), true, 2);
        plugin.tasks().timer(id, 0, 1, r.W + r.C + 14, t -> tick(r, t), () -> finish(r, false));
        return true;
    }

    private void announce(Run r) {
        AkaiSettings s = m.settings();
        String name = r.caster.getName().toUpperCase();
        double range = r.radius + s.d("ultimate.announce-extra-radius", 30);
        Title ti = Title.title(s.mm("<red><bold>[" + name + "] HAS AWAKENED THE CRIMSON SOVEREIGN</bold>"), s.mm("<dark_red>THRONE OF BLOOD \u2014 LEAVE THE CIRCLE"),
            Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(2000), Duration.ofMillis(400)));
        for (Player o : r.anchor.getWorld().getPlayers()) if (o.getLocation().distanceSquared(r.anchor) <= range * range) {
            o.showTitle(ti);
            o.sendMessage(s.mm("<dark_red>[AKAI NO \u014c] <red>The blade does not serve the throne. The throne serves the blade."));
        }
        AkaiFx.sound(plugin, r.anchor, "u_awaken", 4.0f, 1.0f);
    }

    private boolean tick(Run r, int t) {
        Player p = r.caster;
        if (!p.isOnline() || p.isDead() || r.finished || p.getWorld() != r.anchor.getWorld()) return false;
        if (p.getLocation().distanceSquared(r.anchor) > 0.5) { Location b = r.anchor.clone(); b.setYaw(p.getLocation().getYaw()); b.setPitch(p.getLocation().getPitch()); p.teleport(b); }
        if (t < r.W) phase1(r, t);
        else { if (!r.captured) capture(r); cinematic(r, t - r.W); }
        return t < r.W + r.C;
    }

    // ---- Phase 1: Imperial Awakening
    private void phase1(Run r, int t) {
        Vfx v = plugin.vfx(); double f = t / (double) r.W;
        Vfx.Audience a = v.at(r.ground);
        v.ring(a, r.ground.clone().add(0, 0.15, 0), r.radius, (int) (r.radius * 7), t * 0.1, AkaiFx.CRIM, 1.5f);
        if (t % 2 == 0) v.ring(a, r.ground.clone().add(0, 0.2, 0), r.radius * 0.7, (int) (r.radius * 4), -t * 0.12, AkaiFx.GOLD, 1.2f);
        for (int k = 0; k < 1 + (int) (f * 4); k++) { // red particles rising into the sky
            double ang = Math.random() * Math.PI * 2, rad = Math.sqrt(Math.random()) * r.radius;
            Location pt = Locs.ground(r.ground.clone().add(Math.cos(ang) * rad, 0, Math.sin(ang) * rad));
            v.column(a, pt, 8 + f * 8, 0.25, 9, AkaiFx.CRIM, 1.2f);
            AkaiFx.embers(plugin, pt.clone().add(0, 1, 0), 3, 0.3);
        }
        Location hand = r.anchor.clone().add(r.fwd.clone().multiply(0.9)).add(0, 1.3 + 2.3 * f, 0);
        if (r.katana != null && r.katana.isValid()) r.katana.teleport(hand);
        a.trans(hand.clone().add(0, 0.5, 0), 4, 0.8, AkaiFx.CRIM, AkaiFx.BLOOD, 1.4f);
        if (t == 10) for (int i = 0; i < 8; i++) { // royal dragon symbols around the battlefield
            double ang = i * Math.PI / 4;
            ItemDisplay g = v.display(r.id, r.ground.clone().add(Math.cos(ang) * r.radius * 0.85, 2.2, Math.sin(ang) * r.radius * 0.85), "akai:glyph", new Vector3f(2.4f, 2.4f, 2.4f), new Quaternionf(), true, 2);
            if (g != null) r.glyphs.add(g);
        }
        for (int i = 0; i < r.glyphs.size(); i++) {
            ItemDisplay g = r.glyphs.get(i);
            if (!g.isValid()) continue;
            double ang = i * Math.PI / 4 + t * 0.03;
            g.teleport(r.ground.clone().add(Math.cos(ang) * r.radius * 0.85, 2.2 + f * 1.5 + Math.sin(t * 0.2 + i) * 0.3, Math.sin(ang) * r.radius * 0.85));
            if (t % 5 == 0) v.animate(g, new Vector3f(2.4f, 2.4f, 2.4f), new Quaternionf().rotateY(t * 0.2f + i), 10);
        }
        if (t % 8 == 0) r.caster.swingMainHand();
        if (t == 6) AkaiFx.sound(plugin, r.anchor, "u_circle", 3.0f, 1.0f);
        if (t % 10 == 0) {
            int left = (int) Math.ceil((r.W - t) / 20.0);
            for (Player o : r.anchor.getWorld().getPlayers()) if (o.getLocation().distanceSquared(r.anchor) <= (r.radius + 20) * (r.radius + 20))
                o.sendActionBar(m.settings().mm("<red><bold>THE DOMAIN CLOSES IN " + left + "s</bold> <dark_red>- leave the " + (int) r.radius + " block circle"));
        }
    }

    // ---- Phase 2: Crimson Domain (capture)
    private void capture(Run r) {
        r.captured = true;
        AkaiSettings s = m.settings(); Player p = r.caster;
        boolean cameraMode = s.s("ultimate.cutscene-mode", "CAMERA").equalsIgnoreCase("CAMERA") && !s.list("ultimate.camera-disabled-worlds").contains(r.anchor.getWorld().getName());
        int max = s.i("ultimate.max-captured", 16);
        boolean mobs = s.b("ultimate.include-mobs", true), bosses = s.b("ultimate.include-bosses", false);
        boolean anyCam = false;
        for (LivingEntity e : plugin.damage().enemies(p, r.anchor.clone().add(0, 1, 0), r.radius)) {
            if (e instanceof Player pl) {
                if (r.players.size() >= max || pl.hasPermission("akai.immune") || plugin.cutscene().isCaptured(pl.getUniqueId())) continue;
                boolean cam = cameraMode && m.store().get(pl.getUniqueId()).cutsceneCamera;
                plugin.cutscene().capture(pl, r.id, cam);
                r.players.add(pl); anyCam |= cam;
                m.marks().forceDecree(p, pl);
                pl.showTitle(Title.title(s.mm("<red><bold>JUDGED</bold>"), s.mm("<dark_red>The Sovereign's authority marks you"), Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(1500), Duration.ofMillis(300))));
            } else if (mobs) {
                boolean boss = plugin.damage().isBoss(e);
                if (boss && !bosses) continue;
                if (e instanceof Mob mob && !boss) { r.ai.put(mob.getUniqueId(), mob.hasAI()); mob.setAI(false); }
                r.mobs.add(e); m.marks().forceDecree(p, e);
            }
        }
        if (anyCam) {
            r.cam = plugin.camera().spawn(r.id, r.anchor.clone().add(0, 5, 0));
            plugin.camera().apply(r.cam, pose(r, 0, 0));
            for (Player pl : r.players) {
                CutsceneManager.Captured c = plugin.cutscene().get(pl.getUniqueId());
                if (c != null && c.camera) {
                    plugin.tasks().later(r.id, 2, () -> plugin.cutscene().enterCamera(pl, r.cam));
                    plugin.tasks().later(r.id, 6, () -> { if (pl.getSpectatorTarget() != r.cam) plugin.cutscene().enterCamera(pl, r.cam); });
                }
            }
        }
        AkaiFx.sound(plugin, r.anchor, "u_domain", 3.5f, 1.0f);
        AkaiFx.sphereBurst(plugin, r.anchor.clone().add(0, 1.5, 0), 2.5);
    }

    // ---- camera (focuses on Rik)
    private Location pose(Run r, double lt, double shake) {
        double x, y, z, ly = 2.0;
        if (lt < 32) { double s = sm(lt / 32); x = lerp(-7, 5, s); y = lerp(1.0, 1.6, s); z = lerp(7.5, 6.5, s); ly = 1.5; }
        else if (lt < 72) { double s = (lt - 32) / 40, ang = lerp(-0.4, 2.7, sm(s)); x = Math.sin(ang) * 7; z = Math.cos(ang) * 7; y = lerp(1.8, 3.4, s); ly = 2.2 + s; }
        else if (lt < 104) { double s = sm((lt - 72) / 32); x = lerp(1.6, 0.8, s); y = lerp(2.2, 2.6, s); z = lerp(3.6, 2.6, s); ly = 2.6; }
        else if (lt < 122) { double s = sm((lt - 104) / 18); x = lerp(-3, -3, s); y = lerp(3.2, 3.2, s); z = lerp(13, 11, s); ly = 3.0; }
        else { double s = sm((lt - 122) / 38); x = -3; y = lerp(3.2, 7, s); z = lerp(11, 18, s); ly = 3.0; }
        Location tgt = r.anchor.clone().add(0, ly, 0);
        Location want = r.anchor.clone().add(r.right.clone().multiply(x)).add(r.fwd.clone().multiply(z)).add(0, y, 0);
        if (shake > 0) want.add((Math.random() - 0.5) * shake * 0.3, (Math.random() - 0.5) * shake * 0.3, (Math.random() - 0.5) * shake * 0.3);
        Vector toCam = want.toVector().subtract(tgt.toVector()); double dist = toCam.length();
        if (dist > 0.5) {
            RayTraceResult hit = r.anchor.getWorld().rayTraceBlocks(tgt, toCam.clone().normalize(), dist, FluidCollisionMode.NEVER, true);
            if (hit != null) want = hit.getHitPosition().toLocation(r.anchor.getWorld()).subtract(toCam.clone().normalize().multiply(0.35));
        }
        want.setDirection(tgt.toVector().subtract(want.toVector()));
        if (shake > 0) { want.setYaw(want.getYaw() + (float) ((Math.random() - 0.5) * shake * 2.4)); want.setPitch(want.getPitch() + (float) ((Math.random() - 0.5) * shake * 2.4)); }
        return want;
    }

    private static double sm(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double s) { return a + (b - a) * s; }

    // ---- Phases 3-5
    private void cinematic(Run r, int c) {
        Vfx v = plugin.vfx();
        double lt = c / r.sf;
        double shake = (lt >= 110 && lt < 138) ? Math.max(0, 1 - (lt - 110) / 28.0) * m.settings().d("ultimate.shake-intensity", 1.0) : 0;
        if (r.cam != null) plugin.camera().apply(r.cam, pose(r, lt, shake));
        for (Player pl : r.players) { // freeze-mode players keep looking at Rik
            CutsceneManager.Captured cp = plugin.cutscene().get(pl.getUniqueId());
            if (cp != null && !cp.camera && pl.isOnline()) { Location l = pl.getLocation(); l.setDirection(r.anchor.clone().add(0, 3, 0).toVector().subtract(pl.getEyeLocation().toVector())); pl.setRotation(l.getYaw(), l.getPitch()); }
        }
        Vfx.Audience a = v.at(r.ground);
        Location top = r.anchor.clone().add(r.fwd.clone().multiply(0.3)).add(0, 4.6, 0);
        // crimson domain wall + mark rings on the judged
        if (!r.collapsed) {
            for (int k = 0; k < 5; k++) { double ang = Math.random() * Math.PI * 2; v.column(a, r.ground.clone().add(Math.cos(ang) * r.radius, 0, Math.sin(ang) * r.radius), 8, 0.2, 7, AkaiFx.BLOOD, 1.4f); }
            if (c % 2 == 0) for (Player pl : r.players) if (pl.isOnline()) v.ring(v.at(pl.getLocation()), pl.getLocation().add(0, 0.1, 0), 1.0, 10, c * 0.3, AkaiFx.CRIM, 1.2f);
        }
        if (!r.impacted) {
            if (r.katana != null && r.katana.isValid()) {
                r.katana.teleport(top);
                if (c % 8 == 0) { float sc = (float) (2.6 + 4.4 * sm((lt - 30) / 80)); v.animate(r.katana, new Vector3f(sc, sc, sc), new Quaternionf().rotateY((float) (lt * 0.1)), 8); }
            }
            if (c % 8 == 0) r.caster.swingMainHand();
            if (lt >= 40 && lt < 110) { double f = (lt - 40) / 70.0; for (int k = 0; k < 6; k++) { Vector d = new Vector(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize().multiply(5 * (1 - f) + 0.6); a.dust(top.clone().add(d), 1, 0, k % 2 == 0 ? AkaiFx.CRIM : AkaiFx.GOLD, 1.3f); } }
            if (lt >= 36) dragonStep(r, lt, top);
            if (c == (int) Math.round(36 * r.sf)) AkaiFx.sound(plugin, r.anchor, "u_dragon", 4.0f, 1.0f);
            if (c == (int) Math.round(60 * r.sf)) AkaiFx.sound(plugin, r.anchor, "u_charge", 4.0f, 1.0f);
        }
        if (!r.impacted && lt >= 110) impact(r);
        if (r.impacted && lt >= 110 && lt < 126) dragonStep(r, lt, top);
        if (r.impacted && !r.exploded && lt >= 116) explode(r);
        if (r.exploded && !r.dissolved && lt >= 128) { r.dissolved = true; if (r.dragon != null) r.dragon.dissolve(true); AkaiFx.sound(plugin, r.anchor, "u_embers", 3.0f, 1.0f); }
        if (r.exploded && lt >= 128 && lt < 150) AkaiFx.embers(plugin, r.ground.clone().add((Math.random() - 0.5) * r.radius * 1.5, 2 + Math.random() * 6, (Math.random() - 0.5) * r.radius * 1.5), 8, 0.6);
        if (!r.collapsed && lt >= 134) { // domain collapse
            r.collapsed = true;
            if (r.circle != null && r.circle.isValid()) v.animate(r.circle, new Vector3f(0.3f, 1f, 0.3f), new Quaternionf().rotateY(5f), 16);
            for (ItemDisplay g : r.glyphs) if (g.isValid()) g.teleport(r.anchor.clone().add(0, 2.5, 0));
            AkaiFx.sound(plugin, r.anchor, "a7_collapse", 3.0f, 0.8f);
            for (int i = 0; i < 2; i++) v.ring(a, r.ground.clone().add(0, 0.3, 0), r.radius * (0.9 - 0.3 * i), 60, 0, AkaiFx.GOLD, 1.6f);
        }
        if (!r.t1 && lt >= 112) { r.t1 = true; titleAll(r, "<red><bold>THE FINAL DECREE</bold>", "<dark_red>AKAI NO \u014c", 1800); }
        if (!r.t2 && lt >= 128) { r.t2 = true; AkaiFx.sound(plugin, r.anchor, "u_decree", 3.0f, 1.0f); }
        if (!r.t3 && lt >= 140) { r.t3 = true; titleAll(r, "<red><bold>THE SOVEREIGN REMAINS</bold>", "<dark_red>RIK IS THE SOVEREIGN. THE BLADE IS HIS DECREE.", 2200); }
    }

    private void dragonStep(Run r, double lt, Location top) {
        if (r.dragon == null) {
            double ang = Math.PI;
            r.dragonPos = r.anchor.clone().add(-Math.cos(0) * 7, 3, 0).add(r.fwd.clone().multiply(-3));
            r.dragon = new AkaiDragon(plugin, r.id, r.dragonPos, new Vector(0, 0.5, 1), m.settings().i("ultimate.dragon-segments", 16), (float) m.settings().d("ultimate.dragon-scale", 5.0));
        }
        if (!r.dragon.valid()) return;
        if (!r.impacted) {
            double ang = Math.PI + (lt - 36) * 0.075, rad = 7 + (lt - 36) * 0.02, h = 3 + Math.min(7, (lt - 36) * 0.1);
            Location cen = r.anchor.clone().add(r.fwd.clone().multiply(-2));
            r.dragonPos = cen.clone().add(Math.cos(ang) * rad, h, Math.sin(ang) * rad);
        } else {
            Location dest = r.anchor.clone().add(r.fwd.clone().multiply(r.radius * 1.25)).add(0, 1.2, 0); // dives with the final slash
            r.dragonPos.add(dest.toVector().subtract(r.dragonPos.toVector()).multiply(0.28));
        }
        r.dragon.move(r.dragonPos);
        Vfx.Audience a = plugin.vfx().at(r.dragonPos);
        a.dust(r.dragonPos, 6, 1.4, AkaiFx.CRIM, 1.5f);
        if ((int) lt % 3 == 0) AkaiFx.lightning(plugin, a, r.dragonPos.clone().add(0, 3, 0), r.anchor.clone().add(0, 4.6, 0));
    }

    private void titleAll(Run r, String main, String sub, int stay) {
        Title t = Title.title(m.settings().mm(main), m.settings().mm(sub), Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(stay), Duration.ofMillis(400)));
        for (Player pl : r.players) if (pl.isOnline()) pl.showTitle(t);
        double range = r.radius + m.settings().d("ultimate.announce-extra-radius", 30);
        for (Player o : r.anchor.getWorld().getPlayers()) if (!r.players.contains(o) && o.getLocation().distanceSquared(r.anchor) <= range * range) o.sendActionBar(m.settings().mm(main));
    }

    // ---- Phase 4: Final Decree (damage applied HERE, at the impact moment)
    private void impact(Run r) {
        r.impacted = true;
        Player p = r.caster;
        p.swingMainHand();
        AkaiFx.sound(plugin, r.anchor, "u_slash", 4.5f, 1.0f);
        if (r.katana != null && r.katana.isValid()) plugin.vfx().animate(r.katana, new Vector3f(9f, 9f, 9f), new Quaternionf().rotateX(1.3f), 4);
        final Vector dir = r.fwd.clone();
        final Location start = r.anchor.clone().add(0, 1.8, 0).add(dir.clone().multiply(1.5));
        final ItemDisplay slash = plugin.vfx().display(r.id, start, "akai:slash", new Vector3f(18f, 18f, 18f), Vfx.orient(dir, new Vector(0, 1, 0)), true, 1);
        final Location pos = start.clone();
        plugin.tasks().timer(r.id, 1, 1, 10, k -> {
            pos.add(dir.clone().multiply(r.radius * 1.6 / 9.0));
            if (slash != null && slash.isValid()) slash.teleport(pos);
            Vfx.Audience a = plugin.vfx().at(pos);
            plugin.vfx().arcCrescent(a, pos, dir, 7.0, false, AkaiFx.CRIM, AkaiFx.GOLD, 1.7f);
            plugin.vfx().crack(a, pos.clone().add(0, 5, 0), pos.clone().subtract(0, 1.4, 0), 1.0, AkaiFx.CRIM, 1.7f);
            return true;
        }, () -> plugin.tasks().release(r.id, slash));
        double raw = r.ctx.cfg("damage", 60);
        double pvp = r.ctx.cfg("pvp-scale", 1.0), pve = r.ctx.cfg("pve-scale", 1.0);
        for (Player pl : new ArrayList<>(r.players)) {
            if (!pl.isOnline() || pl.isDead()) continue;
            CutsceneManager.Captured cp = plugin.cutscene().get(pl.getUniqueId());
            boolean cam = cp != null && cp.camera;
            Location where = pl.getLocation().add(0, 1, 0);
            if (cam) plugin.cutscene().exitCamera(pl);
            try { if (r.ctx.hit(pl, raw, true, pvp)) execution(where); }
            finally {
                if (cam && pl.isOnline() && !pl.isDead()) {
                    plugin.cutscene().enterCamera(pl, r.cam);
                    plugin.tasks().later(r.id, 2, () -> plugin.cutscene().enterCamera(pl, r.cam));
                }
            }
        }
        for (LivingEntity mob : new ArrayList<>(r.mobs)) if (mob.isValid() && !mob.isDead()) { Location w = mob.getLocation().add(0, 1, 0); if (r.ctx.hit(mob, raw, true, pve)) execution(w); }
    }

    private void execution(Location at) {
        AkaiFx.executionBurst(plugin, at);
        AkaiFx.cross(plugin, at, new Vector(1, 0, 0), 2.2);
    }

    private void explode(Run r) {
        r.exploded = true;
        Vfx v = plugin.vfx();
        AkaiFx.sound(plugin, r.anchor, "u_explode", 5.0f, 1.0f);
        Location mid = r.ground.clone().add(0, 1.5, 0);
        AkaiFx.sphereBurst(plugin, mid, 5.5);
        AkaiFx.sphereBurst(plugin, mid.clone().add(r.fwd.clone().multiply(r.radius * 0.6)), 4.5);
        for (int i = 0; i < 3; i++) {
            final double rad = r.radius * (1.0 + i * 0.3);
            plugin.tasks().later(r.id, i * 4L, () -> { v.ring(v.at(r.ground), r.ground.clone().add(0, 0.2, 0), rad, 64, 0, AkaiFx.CRIM, 1.9f); AkaiFx.sound(plugin, r.ground, "a4_impact", 2.0f, 0.6f); });
            float target = (float) (rad * 2.13);
            ItemDisplay d = v.display(r.id, r.ground.clone().add(0, 0.15, 0), "akai:ring", new Vector3f(0.5f, 1.5f, 0.5f), new Quaternionf(), false, 0);
            if (d != null) { plugin.tasks().later(r.id, 1, () -> v.animate(d, new Vector3f(target, 1.5f, target), new Quaternionf(), 12 + i * 2)); plugin.tasks().later(r.id, 16 + i * 2L, () -> plugin.tasks().release(r.id, d)); }
        }
        for (Player o : r.anchor.getWorld().getPlayers()) if (!r.players.contains(o) && o.getLocation().distanceSquared(r.anchor) < (r.radius + 40) * (r.radius + 40))
            o.sendActionBar(m.settings().mm("<red><bold>THE CRIMSON SOVEREIGN HAS PASSED JUDGEMENT</bold>"));
    }

    // ---- Phase 5 + safety: release everything, restore everyone
    private void finish(Run r, boolean aborted) {
        if (r.finished) return;
        r.finished = true; runs.remove(r.id);
        for (Player pl : r.players) {
            if (!pl.isOnline()) continue;
            plugin.cutscene().release(pl, true);
            if (!aborted && m.settings().b("ultimate.post-knockback", true)) {
                Vector out = pl.getLocation().toVector().subtract(r.anchor.toVector()).setY(0);
                if (out.lengthSquared() > 1e-4) pl.setVelocity(out.normalize().multiply(0.7).setY(0.3));
            }
        }
        for (Map.Entry<UUID, Boolean> e : r.ai.entrySet()) { var en = Bukkit.getEntity(e.getKey()); if (en instanceof Mob mob) mob.setAI(e.getValue()); }
        if (r.dragon != null) r.dragon.remove();
        plugin.tasks().release(r.id, r.cam); plugin.tasks().release(r.id, r.katana); plugin.tasks().release(r.id, r.circle);
        for (ItemDisplay g : r.glyphs) plugin.tasks().release(r.id, g);
        Player p = r.caster;
        if (p.isOnline()) {
            p.removePotionEffect(PotionEffectType.SLOWNESS); p.removePotionEffect(PotionEffectType.JUMP_BOOST);
            if (!aborted) m.store().get(p.getUniqueId()).ultimates++;
            m.mastery().recheck(p, 0);
        }
        m.state(r.id).busy = false;
    }

    public void abort(UUID caster) { Run r = runs.get(caster); if (r != null) finish(r, true); }
    public void abortAll() { for (Run r : new ArrayList<>(runs.values())) finish(r, true); }
}

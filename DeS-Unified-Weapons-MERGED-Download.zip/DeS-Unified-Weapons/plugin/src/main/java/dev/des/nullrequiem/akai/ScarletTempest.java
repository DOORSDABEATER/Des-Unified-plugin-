package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** 05 - rapid sequence of individually-detected katana slashes (rotating planes) ending in one heavy strike. */
final class ScarletTempest extends AkaiBase {
    ScarletTempest(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.SCARLET_TEMPEST); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player;
        final int strikes = cfgI("strikes", 7), gap = Math.max(2, cfgI("strike-interval-ticks", 3));
        ctx.maxHits = strikes + 2;
        snd(p.getLocation(), "a5_cut", 1.0f, 0.9f);
        plugin.tasks().timer(p.getUniqueId(), 0, 1, strikes * gap + 8, t -> {
            if (!alive(p)) return false;
            Location eye = p.getEyeLocation();
            Vector dir = eye.getDirection().normalize();
            Vfx.Audience a = vfx().at(p.getLocation());
            if (t < strikes * gap && t % gap == 0) {
                int i = t / gap;
                Vector hint = UP.clone().rotateAroundAxis(dir, Math.toRadians(i * 34.0 + 15));
                p.swingMainHand();
                snd(p.getLocation(), "a5_cut", 0.9f, 0.9f + i * 0.06f);
                Location start = eye.clone().add(dir.clone().multiply(1.2)).subtract(0, 0.2, 0);
                slash(ctx, start, dir, 7.0, 1.6, 1.9, 0, cfg("damage", 3.5), 2.8f, hint, false, "a1_hit", null);
                vfx().ring(a, p.getLocation().add(0, 0.1 + 0.2 * i, 0), 1.2 + 0.1 * i, 12, i, AkaiFx.CRIM, 1.0f);
                a.dust(p.getLocation().add(0, 1, 0), 8, 0.5, AkaiFx.BLOOD, 1.2f);
            }
            if (t == strikes * gap + 3) {
                p.swingMainHand();
                snd(p.getLocation(), "a5_final", 1.3f, 1.0f);
                Location start = eye.clone().add(dir.clone().multiply(1.5)).subtract(0, 0.2, 0);
                slash(ctx, start, dir, 10.0, 1.5, 2.6, 0, cfg("final-damage", 10), 5.2f, dir.clone().crossProduct(UP).normalize(), true, "a5_final",
                    end -> { AkaiFx.cross(plugin, end, dir.clone().crossProduct(UP), 2.2); AkaiFx.sphereBurst(plugin, end, 1.4); });
            }
            return t < strikes * gap + 4;
        }, null);
        return true;
    }
}

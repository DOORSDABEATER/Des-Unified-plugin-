package dev.des.nullrequiem.cutscene;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.Settings;
import dev.des.nullrequiem.abilities.CastContext;
import dev.des.nullrequiem.sounds.Snd;
import dev.des.nullrequiem.util.Locs;
import dev.des.nullrequiem.vfx.Vfx;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 404: WORLD CORRUPTED. Phase 1 SYSTEM FAILURE (warning + magic circle) -> Phase 2 AOE CAPTURE -> Phase 3 THE EXECUTION
 * (shared camera, scythe raise, rift) -> impact (damage applied exactly here) -> Phase 4 WORLD CORRUPTED (explosion, titles).
 * One timer drives everything, so every captured player sees the same timeline.
 */
public final class UltimateManager {
    private static final class Run {
        Player caster; UUID id; CastContext ctx; Location anchor, ground; Vector fwd, right;
        double radius; int W, C; double sf;
        final List<Player> players = new ArrayList<>();
        final List<LivingEntity> mobs = new ArrayList<>();
        final Map<UUID, Boolean> ai = new HashMap<>();
        ArmorStand cam; ItemDisplay scythe, circle, rift;
        final List<ItemDisplay> frags = new ArrayList<>();
        final List<Vector> fragDir = new ArrayList<>();
        boolean captured, impacted, exploded, title1, title2, fragsSpawned, riftSpawned, finished;
        int explodeLt;
    }

    private final NullRequiemPlugin plugin;
    private final Map<UUID, Run> runs = new HashMap<>();

    public UltimateManager(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public boolean isRunning(UUID caster) { return runs.containsKey(caster); }

    // ------------------------------------------------------------------ start
    public boolean start(CastContext ctx) {
        final Player p = ctx.player;
        final UUID id = p.getUniqueId();
        if (runs.containsKey(id)) return false;
        final Run r = new Run();
        r.caster = p; r.id = id; r.ctx = ctx;
        r.anchor = p.getLocation().clone();
        r.ground = Locs.ground(r.anchor);
        r.fwd = Locs.flat(p.getLocation().getDirection());
        r.right = r.fwd.clone().crossProduct(new Vector(0, 1, 0)).normalize();
        r.radius = ctx.cfg("radius", 12);
        r.W = (int) Math.max(20, ctx.cfg("warning-ticks", 40));
        r.C = (int) Math.max(100, ctx.cfg("cinematic-ticks", 160));
        r.sf = r.C / 160.0;
        ctx.maxHitsPerTarget = 1;
        ctx.state.busy = true;
        runs.put(id, r);

        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, r.W + r.C + 40, 6, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, r.W + r.C + 40, 128, false, false, false));
        p.swingMainHand();
        announce(r);

        r.circle = plugin.vfx().display(id, r.ground.clone().add(0, 0.1, 0), "circle", new Vector3f(0.5f, 1f, 0.5f), new Quaternionf(), false, 0);
        final float full = (float) (r.radius * 2.05);
        plugin.tasks().later(id, 1, () -> plugin.vfx().animate(r.circle, new Vector3f(full, 1f, full), new Quaternionf().rotateY(1.6f), 30));
        r.scythe = plugin.vfx().display(id, r.anchor.clone().add(r.fwd.clone().multiply(0.9)).add(0, 1.3, 0), "nullrequiem", new Vector3f(2.6f, 2.6f, 2.6f), new Quaternionf(), true, 2);
        plugin.tasks().timer(id, 0, 1, r.W + r.C + 14, t -> tick(r, t), () -> finish(r, false));
        return true;
    }

    private void announce(Run r) {
        Settings s = plugin.settings();
        String name = r.caster.getName().toUpperCase();
        double range = r.radius + s.d("ultimate.announce-extra-radius", 30);
        Title ti = Title.title(s.raw("<green><bold>[" + name + "] HAS BREACHED REALITY.</bold>"), s.raw("<dark_green>REALITY BREACH IMMINENT - LEAVE THE CIRCLE"),
            Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1800), Duration.ofMillis(400)));
        for (Player o : r.anchor.getWorld().getPlayers()) {
            if (o.getLocation().distanceSquared(r.anchor) <= range * range) {
                o.showTitle(ti);
                o.sendMessage(s.raw("<dark_green>[" + name + "] <green>HAS INITIATED WORLD CORRUPTION."));
            }
        }
        plugin.sfx().play(r.anchor, Snd.U_ACTIVATE, 4.0f, 1.0f);
    }

    // ------------------------------------------------------------------ main timeline
    private boolean tick(Run r, int t) {
        Player p = r.caster;
        if (!p.isOnline() || p.isDead() || r.finished) return false;
        if (p.getWorld() != r.anchor.getWorld()) return false;
        if (p.getLocation().distanceSquared(r.anchor) > 0.5) { // keep ERROR in place
            Location back = r.anchor.clone(); back.setYaw(p.getLocation().getYaw()); back.setPitch(p.getLocation().getPitch());
            p.teleport(back);
        }
        if (t < r.W) phase1(r, t);
        else {
            if (!r.captured) capture(r);
            cinematic(r, t - r.W);
        }
        return t < r.W + r.C;
    }

    private void phase1(Run r, int t) {
        Vfx v = plugin.vfx();
        double f = t / (double) r.W;
        Vfx.Audience a = v.at(r.ground);
        v.ring(a, r.ground.clone().add(0, 0.15, 0), r.radius, (int) (r.radius * 7), t * 0.1, Vfx.NEON, 1.5f);
        if (t % 2 == 0) v.ring(a, r.ground.clone().add(0, 0.2, 0), r.radius * 0.7, (int) (r.radius * 4), -t * 0.12, Vfx.EMERALD, 1.2f);
        for (int k = 0; k < 1 + (int) (f * 5); k++) { // corrupted symbols across the battlefield
            double ang = Math.random() * Math.PI * 2, rad = Math.sqrt(Math.random()) * r.radius;
            Location pt = Locs.ground(r.ground.clone().add(Math.cos(ang) * rad, 0, Math.sin(ang) * rad));
            v.glitch(a, pt);
            a.block(pt.clone().add(0, 0.3, 0), 2, 0.2, Math.random() < 0.5 ? Material.EMERALD_BLOCK : Material.BLACK_CONCRETE);
            if (Math.random() < 0.3) v.column(a, pt, 2.0, 0.3, 5, Vfx.NEON, 1.1f);
        }
        Location hand = r.anchor.clone().add(r.fwd.clone().multiply(0.9)).add(0, 1.3 + 2.3 * f, 0);
        if (r.scythe != null && r.scythe.isValid()) r.scythe.teleport(hand);
        a.trans(hand.clone().add(0, 0.5, 0), 4, 0.8, Vfx.NEON, Vfx.DEEP, 1.4f);
        a.ink(r.anchor.clone().add(0, 1, 0), 2, r.radius * 0.5);
        if (t % 8 == 0) p(r).swingMainHand();
        if (t == 6) plugin.sfx().play(r.anchor, Snd.U_CIRCLE, 3.0f, 1.0f);
        if (t % 10 == 0) {
            int left = (int) Math.ceil((r.W - t) / 20.0);
            for (Player o : r.anchor.getWorld().getPlayers())
                if (o.getLocation().distanceSquared(r.anchor) <= (r.radius + 20) * (r.radius + 20))
                    o.sendActionBar(plugin.settings().raw("<green><bold>REALITY BREACH IN " + left + "s</bold> <dark_green>- leave the " + (int) r.radius + " block circle"));
        }
    }

    private Player p(Run r) { return r.caster; }

    private void capture(Run r) {
        r.captured = true;
        Settings s = plugin.settings();
        Player p = r.caster;
        boolean cameraMode = s.s("ultimate.cutscene-mode", "CAMERA").equalsIgnoreCase("CAMERA")
            && !s.list("ultimate.camera-disabled-worlds").contains(r.anchor.getWorld().getName());
        int max = s.i("ultimate.max-captured", 16);
        boolean mobs = s.b("ultimate.include-mobs", true), bosses = s.b("ultimate.include-bosses", false);
        boolean anyCam = false;
        for (LivingEntity e : plugin.damage().enemies(p, r.anchor.clone().add(0, 1, 0), r.radius)) {
            if (e instanceof Player pl) {
                if (r.players.size() >= max || pl.hasPermission("nullrequiem.immune") || plugin.cutscene().isCaptured(pl.getUniqueId())) continue;
                boolean cam = cameraMode && plugin.data().get(pl.getUniqueId()).cutsceneCamera;
                plugin.cutscene().capture(pl, r.id, cam);
                r.players.add(pl);
                anyCam |= cam;
                pl.showTitle(Title.title(s.raw("<green><bold>[404] REALITY NOT FOUND.</bold>"), s.raw("<dark_green>You were caught in the breach"),
                    Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(1500), Duration.ofMillis(300))));
            } else if (mobs) {
                boolean boss = plugin.damage().isBoss(e);
                if (boss && !bosses) continue;
                if (e instanceof Mob m && !boss) { r.ai.put(m.getUniqueId(), m.hasAI()); m.setAI(false); }
                r.mobs.add(e);
            }
        }
        if (anyCam) {
            r.cam = plugin.camera().spawn(r.id, r.anchor.clone().add(0, 5, 0));
            plugin.camera().apply(r.cam, plugin.camera().pose(r.anchor, r.fwd, r.right, 0, 0));
            for (Player pl : r.players) {
                CutsceneManager.Captured c = plugin.cutscene().get(pl.getUniqueId());
                if (c != null && c.camera) {
                    plugin.tasks().later(r.id, 2, () -> plugin.cutscene().enterCamera(pl, r.cam));
                    plugin.tasks().later(r.id, 6, () -> { if (pl.getSpectatorTarget() != r.cam) plugin.cutscene().enterCamera(pl, r.cam); });
                }
            }
        }
        plugin.sfx().play(r.anchor, Snd.U_CAPTURE, 3.0f, 1.0f);
        vfxCapture(r);
    }

    private void vfxCapture(Run r) {
        Vfx v = plugin.vfx();
        for (Player pl : r.players) v.glitch(v.at(pl.getLocation()), pl.getLocation());
        v.sphereBurst(r.anchor.clone().add(0, 1.5, 0), 2.0);
    }

    private void cinematic(Run r, int c) {
        Vfx v = plugin.vfx();
        double lt = c / r.sf;
        double impactLt = 110;
        double shake = (lt >= impactLt && lt < impactLt + 28) ? Math.max(0, 1 - (lt - impactLt) / 28.0) * plugin.settings().d("ultimate.shake-intensity", 1.0) : 0;
        if (r.cam != null) plugin.camera().apply(r.cam, plugin.camera().pose(r.anchor, r.fwd, r.right, lt, shake));
        // non-camera (freeze) players keep looking at ERROR
        for (Player pl : r.players) {
            CutsceneManager.Captured cp = plugin.cutscene().get(pl.getUniqueId());
            if (cp != null && !cp.camera && pl.isOnline()) {
                Vector d = r.anchor.clone().add(0, 3, 0).toVector().subtract(pl.getEyeLocation().toVector());
                Location l = pl.getLocation(); l.setDirection(d);
                pl.setRotation(l.getYaw(), l.getPitch());
            }
        }
        Vfx.Audience a = v.at(r.ground);
        Location top = r.anchor.clone().add(r.fwd.clone().multiply(0.3)).add(0, 3.8, 0);
        // ERROR: scythe raise + energy leak
        if (!r.impacted) {
            if (r.scythe != null && r.scythe.isValid()) {
                r.scythe.teleport(top);
                if (c % 10 == 0) {
                    float sc = (float) (2.6 + 1.6 * Math.min(1.0, Math.max(0, (lt - 30) / 70)));
                    v.animate(r.scythe, new Vector3f(sc, sc, sc), new Quaternionf().rotateY((float) (lt * 0.12)), 10);
                }
            }
            if (c % 8 == 0) r.caster.swingMainHand();
            if (lt >= 20) for (int k = 0; k < 4; k++) {
                double ang = Math.random() * Math.PI * 2, rad = Math.sqrt(Math.random()) * r.radius;
                a.block(Locs.ground(r.ground.clone().add(Math.cos(ang) * rad, 0, Math.sin(ang) * rad)).add(0, 0.2, 0), 1, 0.1, Math.random() < 0.5 ? Material.EMERALD_BLOCK : Material.BLACK_CONCRETE);
            }
            if (lt >= 40 && lt < 110) { // energy converges into the blade
                double f = (lt - 40) / 70.0;
                for (int k = 0; k < 6; k++) {
                    Vector d = new Vector(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).normalize().multiply(4.5 * (1 - f) + 0.6);
                    a.dust(top.clone().add(d), 1, 0, k % 2 == 0 ? Vfx.NEON : Vfx.PALE, 1.3f);
                }
                v.tiltedRing(a, top, new Vector(0, 1, 0), 1.2 + f * 2.2, 18, lt * 0.3, Vfx.NEON, 1.3f);
                if (c % 6 == 0) v.glitch(a, top);
            }
            if (lt >= 50 && !r.fragsSpawned) spawnFragments(r, top);
            if (r.fragsSpawned) orbitFragments(r, top, lt);
            if (lt >= 60 && !r.riftSpawned) spawnRift(r);
            if (r.riftSpawned && r.rift != null && r.rift.isValid()) {
                Location rl = r.anchor.clone().add(r.fwd.clone().multiply(r.radius * 0.55)).add(0, 3.4, 0);
                v.crack(a, rl.clone().add(0, 3, 0), rl.clone().subtract(0, 1.5, 0), 0.8, Vfx.NEON, 1.4f);
                v.sphere(a, rl, 2.2 + Math.sin(lt) * 0.3, 14, Vfx.VOID, 1.8f);
            }
            if (c == (int) Math.round(36 * r.sf)) plugin.sfx().play(r.anchor, Snd.U_CHARGE, 4.0f, 1.0f);
            if (c == (int) Math.round(68 * r.sf)) plugin.sfx().play(r.anchor, Snd.U_RIFT, 4.0f, 1.0f);
        }
        if (!r.impacted && lt >= impactLt) impact(r);
        if (r.impacted && !r.exploded && lt >= impactLt + 4) explode(r, lt);
        if (r.exploded) aftermath(r, lt);
        if (!r.title1 && lt >= impactLt + 12) {
            r.title1 = true;
            titleAll(r, "<green><bold>404</bold>", "<dark_green>WORLD CORRUPTED", 2200);
            plugin.sfx().play(r.anchor, Snd.U_404, 3.0f, 1.0f);
        }
        if (!r.title2 && lt >= impactLt + 38) {
            r.title2 = true;
            titleAll(r, "<green><bold>REALITY HAS FAILED TO RESPOND.</bold>", "<dark_green>[404] REALITY NOT FOUND.", 1800);
        }
    }

    private void titleAll(Run r, String main, String sub, int stayMs) {
        Title t = Title.title(plugin.settings().raw(main), plugin.settings().raw(sub), Title.Times.times(Duration.ofMillis(100), Duration.ofMillis(stayMs), Duration.ofMillis(400)));
        for (Player pl : r.players) if (pl.isOnline()) pl.showTitle(t);
        double range = r.radius + plugin.settings().d("ultimate.announce-extra-radius", 30);
        for (Player o : r.anchor.getWorld().getPlayers())
            if (!r.players.contains(o) && o.getLocation().distanceSquared(r.anchor) <= range * range) o.sendActionBar(plugin.settings().raw(main));
    }

    private void spawnFragments(Run r, Location top) {
        r.fragsSpawned = true;
        for (int i = 0; i < 8; i++) {
            ItemDisplay d = plugin.vfx().display(r.id, top.clone(), "shard", new Vector3f(2.0f, 2.0f, 2.0f), new Quaternionf(), true, 2);
            if (d != null) r.frags.add(d);
        }
    }

    private void orbitFragments(Run r, Location top, double lt) {
        double f = Math.min(1.0, Math.max(0, (lt - 50) / 60));
        for (int i = 0; i < r.frags.size(); i++) {
            ItemDisplay d = r.frags.get(i);
            if (!d.isValid()) continue;
            double ang = lt * 0.18 + i * Math.PI * 2 / r.frags.size();
            double rad = 1.0 + f * 3.0;
            d.teleport(top.clone().add(Math.cos(ang) * rad, Math.sin(lt * 0.1 + i) * 0.8, Math.sin(ang) * rad));
        }
    }

    private void spawnRift(Run r) {
        r.riftSpawned = true;
        Location rl = r.anchor.clone().add(r.fwd.clone().multiply(r.radius * 0.55)).add(0, 3.4, 0);
        r.rift = plugin.vfx().display(r.id, rl, "rift", new Vector3f(0.5f, 0.5f, 0.5f), Vfx.orient(new Vector(0, 1, 0), r.fwd.clone().multiply(-1)), false, 0);
        plugin.tasks().later(r.id, 1, () -> plugin.vfx().animate(r.rift, new Vector3f(9f, 9f, 9f), Vfx.orient(new Vector(0, 1, 0), r.fwd.clone().multiply(-1)), 30));
        plugin.sfx().play(rl, Snd.U_RIFT, 3.0f, 0.8f);
    }

    // ------------------------------------------------------------------ impact: damage is applied HERE
    private void impact(Run r) {
        r.impacted = true;
        Player p = r.caster;
        Settings s = plugin.settings();
        p.swingMainHand();
        plugin.sfx().play(r.anchor, Snd.U_SWING, 4.0f, 1.0f);
        if (r.scythe != null && r.scythe.isValid())
            plugin.vfx().animate(r.scythe, new Vector3f(4.2f, 4.2f, 4.2f), new Quaternionf().rotateX(1.3f), 4);
        // giant slash sweeping across the battlefield
        final Vector dir = r.fwd.clone();
        final Location start = r.anchor.clone().add(0, 1.6, 0).add(dir.clone().multiply(1.5));
        final ItemDisplay slash = plugin.vfx().display(r.id, start, "slash", new Vector3f(15f, 15f, 15f), Vfx.orient(dir, new Vector(0, 1, 0)), true, 1);
        final Location pos = start.clone();
        plugin.tasks().timer(r.id, 1, 1, 9, k -> {
            pos.add(dir.clone().multiply(r.radius * 1.5 / 8.0));
            if (slash != null && slash.isValid()) slash.teleport(pos);
            Vfx.Audience a = plugin.vfx().at(pos);
            plugin.vfx().arcCrescent(a, pos, dir, 6.0, false, Vfx.NEON, 1.6f);
            plugin.vfx().crack(a, pos.clone().add(0, 4, 0), pos.clone().subtract(0, 1.4, 0), 0.9, Vfx.NEON, 1.6f);
            return true;
        }, () -> plugin.tasks().release(r.id, slash));
        double raw = r.ctx.cfg("damage", 40);
        double pvp = r.ctx.cfg("pvp-scale", 1.0), pve = r.ctx.cfg("pve-scale", 1.0);
        for (Player pl : new ArrayList<>(r.players)) {
            if (!pl.isOnline() || pl.isDead()) continue;
            CutsceneManager.Captured cp = plugin.cutscene().get(pl.getUniqueId());
            boolean cam = cp != null && cp.camera;
            if (cam) plugin.cutscene().exitCamera(pl);
            try { r.ctx.hit(pl, raw, true, pvp); }
            finally {
                if (cam && pl.isOnline() && !pl.isDead()) {
                    plugin.cutscene().enterCamera(pl, r.cam);
                    plugin.tasks().later(r.id, 2, () -> plugin.cutscene().enterCamera(pl, r.cam));
                }
            }
        }
        for (LivingEntity m : new ArrayList<>(r.mobs)) if (m.isValid() && !m.isDead()) r.ctx.hit(m, raw, true, pve);
    }

    // ------------------------------------------------------------------ phase 4
    private void explode(Run r, double lt) {
        r.exploded = true;
        r.explodeLt = (int) lt;
        Vfx v = plugin.vfx();
        plugin.sfx().play(r.anchor, Snd.U_EXPLODE, 5.0f, 1.0f);
        Location mid = r.ground.clone().add(0, 1.5, 0);
        v.sphereBurst(mid, 5.0);
        v.sphereBurst(mid.clone().add(r.fwd.clone().multiply(r.radius * 0.5)), 4.0);
        for (int i = 0; i < 3; i++) {
            final double rad = r.radius * (1.0 + i * 0.3);
            plugin.tasks().later(r.id, i * 4L, () -> {
                Location g = r.ground.clone();
                plugin.vfx().ring(plugin.vfx().at(g), g.clone().add(0, 0.2, 0), rad, 60, 0, Vfx.NEON, 1.8f);
                plugin.sfx().play(g, Snd.A4_SHOCK, 2.0f, 0.6f + 0.2f * (float) Math.random());
            });
            shockDisplay(r, rad, 12 + i * 2);
        }
        for (int i = 0; i < r.frags.size(); i++) {
            double ang = i * Math.PI * 2 / Math.max(1, r.frags.size());
            r.fragDir.add(new Vector(Math.cos(ang), 0.55 + Math.random() * 0.4, Math.sin(ang)).normalize());
        }
        for (Player o : r.anchor.getWorld().getPlayers())
            if (!r.players.contains(o) && o.getLocation().distanceSquared(r.anchor) < (r.radius + 40) * (r.radius + 40))
                o.sendActionBar(plugin.settings().raw("<green><bold>[404] WORLD CORRUPTED</bold>"));
        if (r.rift != null) plugin.vfx().animate(r.rift, new Vector3f(0.1f, 0.1f, 0.1f), new Quaternionf(), 6);
    }

    private void shockDisplay(Run r, double radius, int ticks) {
        float target = (float) (radius * 2.13);
        ItemDisplay d = plugin.vfx().display(r.id, r.ground.clone().add(0, 0.15, 0), "ring", new Vector3f(0.5f, 1.5f, 0.5f), new Quaternionf(), false, 0);
        if (d == null) return;
        plugin.tasks().later(r.id, 1, () -> plugin.vfx().animate(d, new Vector3f(target, 1.5f, target), new Quaternionf(), ticks));
        plugin.tasks().later(r.id, ticks + 2L, () -> plugin.tasks().release(r.id, d));
    }

    private void aftermath(Run r, double lt) {
        Vfx v = plugin.vfx();
        double age = lt - r.explodeLt;
        Vfx.Audience a = v.at(r.ground);
        Location mid = r.ground.clone().add(0, 1.5, 0);
        if (age < 30) {
            for (int k = 0; k < 3; k++) {
                double ang = Math.random() * Math.PI * 2, rad = Math.sqrt(Math.random()) * r.radius;
                Location pt = Locs.ground(r.ground.clone().add(Math.cos(ang) * rad, 0, Math.sin(ang) * rad));
                v.column(a, pt, 3.0 + Math.random() * 3, 0.4, 8, Vfx.NEON, 1.4f);
                a.block(pt.clone().add(0, 0.5, 0), 6, 0.4, Material.EMERALD_BLOCK);
            }
            v.ring(a, r.ground.clone().add(0, 0.3, 0), Math.min(r.radius * 1.6, 2 + age * 0.6), 50, age, Vfx.NEON, 1.5f);
            if ((int) age % 3 == 0) v.glitch(a, mid.clone().add((Math.random() - 0.5) * r.radius, 0, (Math.random() - 0.5) * r.radius));
            a.ink(mid, 6, r.radius * 0.4);
        }
        for (int i = 0; i < r.frags.size() && i < r.fragDir.size(); i++) { // floating corrupted fragments flung outward
            ItemDisplay d = r.frags.get(i);
            if (!d.isValid()) continue;
            Vector dir = r.fragDir.get(i);
            d.teleport(d.getLocation().add(dir.clone().multiply(Math.max(0.05, 0.6 - age * 0.02))).add(0, -age * 0.004, 0));
            a.dust(d.getLocation(), 1, 0.05, Vfx.PALE, 1.1f);
        }
    }

    // ------------------------------------------------------------------ cleanup
    private void finish(Run r, boolean aborted) {
        if (r.finished) return;
        r.finished = true;
        runs.remove(r.id);
        for (Player pl : r.players) {
            if (!pl.isOnline()) continue;
            plugin.cutscene().release(pl, true);
            if (!aborted && plugin.settings().b("ultimate.post-knockback", true)) {
                Vector out = pl.getLocation().toVector().subtract(r.anchor.toVector()).setY(0);
                if (out.lengthSquared() > 1e-4) pl.setVelocity(out.normalize().multiply(0.7).setY(0.3));
            }
        }
        for (Map.Entry<UUID, Boolean> e : r.ai.entrySet()) {
            org.bukkit.entity.Entity en = Bukkit.getEntity(e.getKey());
            if (en instanceof Mob m) m.setAI(e.getValue());
        }
        plugin.tasks().release(r.id, r.cam);
        plugin.tasks().release(r.id, r.scythe);
        plugin.tasks().release(r.id, r.circle);
        plugin.tasks().release(r.id, r.rift);
        for (ItemDisplay d : r.frags) plugin.tasks().release(r.id, d);
        Player p = r.caster;
        if (p.isOnline()) {
            p.removePotionEffect(PotionEffectType.SLOWNESS);
            p.removePotionEffect(PotionEffectType.JUMP_BOOST);
            plugin.states().get(p).busy = false;
            if (!aborted) plugin.data().get(p.getUniqueId()).ultimates++;
        }
        plugin.states().get(r.id).busy = false;
    }

    public void abort(UUID caster, String reason) {
        Run r = runs.get(caster);
        if (r != null) finish(r, true);
    }

    public void abortAll() { for (Run r : new ArrayList<>(runs.values())) finish(r, true); }
}

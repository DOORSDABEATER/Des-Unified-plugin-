package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.Vector;

import java.util.UUID;

/**
 * 09 - brief defensive stance. The first ELIGIBLE incoming hit (melee/projectile/explosion) inside the window is reduced and
 * answered by an explosive counter slash; correct timing is rewarded (energy refund + short cooldown). Missing costs a failure cooldown.
 * Never invulnerable: damage is only reduced.
 */
final class CrimsonReversal extends AkaiBase {
    CrimsonReversal(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.CRIMSON_REVERSAL); }

    @Override public boolean selfManagedCooldown() { return true; }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        final AkaiState st = ctx.state;
        int ticks = cfgI("stance-ticks", 24);
        st.stanceUntil = System.currentTimeMillis() + ticks * 50L;
        st.stanceCtx = ctx; st.stanceResolved = false;
        ctx.maxHits = 1;
        m.setCooldown(p, type, 30);   // placeholder; replaced on resolution
        p.swingMainHand();
        snd(p.getLocation(), "a9_stance", 1.2f, 1.0f);
        plugin.tasks().timer(id, 0, 1, ticks + 2, t -> {
            if (!alive(p) || st.stanceResolved) return false;
            Location l = p.getLocation();
            Vfx.Audience a = vfx().at(l);
            vfx().ring(a, l.clone().add(0, 0.2, 0), 1.3, 14, t * 0.4, AkaiFx.CRIM, 1.2f);
            vfx().tiltedRing(a, l.clone().add(0, 1.2, 0), new Vector(0, 1, 0), 0.9, 10, -t * 0.5, AkaiFx.GOLD, 1.0f);
            return System.currentTimeMillis() < st.stanceUntil;
        }, () -> {
            if (!st.stanceResolved && st.stanceCtx == ctx) {
                st.stanceResolved = true; st.stanceUntil = 0;
                m.setCooldown(p, type, cfg("fail-cooldown", 6));
                snd(p.getLocation(), "a9_fail", 1.0f, 1.0f);
                if (p.isOnline()) actionbar(p, "<dark_red>CRIMSON REVERSAL <gray>- failed (" + (int) cfg("fail-cooldown", 6) + "s)");
            }
        });
        return true;
    }

    /** Called from the damage listener. Returns true when the counter was triggered. */
    boolean onHurt(Player victim, EntityDamageEvent e, LivingEntity attacker) {
        AkaiState st = m.state(victim);
        if (st.stanceResolved || System.currentTimeMillis() > st.stanceUntil || st.stanceCtx == null) return false;
        switch (e.getCause()) {
            case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK, PROJECTILE, ENTITY_EXPLOSION, MAGIC, THORNS -> { }
            default -> { return false; }
        }
        final AkaiCtx ctx = st.stanceCtx;
        st.stanceResolved = true; st.stanceUntil = 0;
        e.setDamage(e.getDamage() * (1.0 - Math.max(0, Math.min(0.9, cfg("damage-reduction", 0.6)))));
        m.setCooldown(victim, type, cfg("success-cooldown", 14));
        m.energy().add(victim, cfg("energy-refund", 15));
        plugin.tasks().later(victim.getUniqueId(), 1, () -> counter(ctx, attacker));
        return true;
    }

    private void counter(AkaiCtx ctx, LivingEntity attacker) {
        Player p = ctx.player;
        if (!alive(p)) return;
        Location c = p.getLocation();
        double r = cfg("counter-radius", 6.0);
        snd(c, "a9_counter", 1.6f, 1.0f);
        shockRing(p.getUniqueId(), c, r, 8);
        AkaiFx.sphereBurst(plugin, c.clone().add(0, 1.2, 0), 2.4);
        AkaiFx.cross(plugin, c.clone().add(0, 1.2, 0), p.getLocation().getDirection().crossProduct(new Vector(0, 1, 0)), 2.5);
        p.swingMainHand();
        for (LivingEntity e : enemies(p, c, r)) {
            if (ctx.hit(e, cfg("counter-damage", 14), true)) {
                Vector out = e.getLocation().toVector().subtract(c.toVector()).setY(0);
                if (out.lengthSquared() > 1e-4) plugin.damage().push(p, e, out.normalize().multiply(1.1).setY(0.4), ctx.castId);
            }
        }
        p.sendActionBar(m.settings().mm("<dark_red>[AKAI NO \u014c] <red><bold>CRIMSON REVERSAL</bold> <gray>- perfect timing"));
    }
}

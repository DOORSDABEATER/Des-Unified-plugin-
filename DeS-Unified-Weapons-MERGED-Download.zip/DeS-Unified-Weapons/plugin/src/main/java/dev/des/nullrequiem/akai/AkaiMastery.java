package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

import java.time.Duration;

/**
 * ROYAL HEIR -> CRIMSON EMPEROR -> ABSOLUTE SOVEREIGN. A stage needs ALL configured objectives (xp, hits, kills, ultimates,
 * decree kills), so it cannot be bought with a single farmed number. Rewards are cosmetic plus a small configurable cooldown reduction.
 */
public final class AkaiMastery {
    public static final String[] NAMES = {"ROYAL HEIR", "CRIMSON EMPEROR", "ABSOLUTE SOVEREIGN"};
    private final NullRequiemPlugin plugin;
    private final AkaiModule m;
    public AkaiMastery(NullRequiemPlugin plugin, AkaiModule m) { this.plugin = plugin; this.m = m; }

    private double req(int stage, String k, double def) { return m.settings().d("mastery.stage" + stage + "." + k, def); }

    public boolean meets(AkaiData d, int stage) {
        return d.xp >= req(stage, "xp", stage == 2 ? 1500 : 6000) && d.hits >= req(stage, "hits", stage == 2 ? 250 : 1200)
            && d.kills >= req(stage, "kills", stage == 2 ? 12 : 60) && d.ultimates >= req(stage, "ultimates", stage == 2 ? 0 : 3)
            && d.decreeKills >= req(stage, "decree-kills", stage == 2 ? 0 : 8);
    }

    public int stage(AkaiData d) { return meets(d, 3) && meets(d, 2) ? 3 : meets(d, 2) ? 2 : 1; }
    public int stage(Player p) { return stage(m.store().get(p.getUniqueId())); }
    public String name(int s) { return NAMES[Math.max(1, Math.min(3, s)) - 1]; }
    public double cooldownFactor(Player p) { int s = stage(p); return s >= 3 ? 1 - m.settings().d("mastery.cooldown-reduction.stage3", 0.10) : s == 2 ? 1 - m.settings().d("mastery.cooldown-reduction.stage2", 0.05) : 1.0; }

    public void recheck(Player p, int before) {
        int after = stage(p);
        if (after > before) {
            AkaiSettings s = m.settings();
            p.showTitle(Title.title(s.mm("<red><bold>STAGE " + after + "</bold>"), s.mm("<dark_red>" + name(after)), Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2400), Duration.ofMillis(600))));
            p.sendMessage(s.mm(s.prefix() + "<red>MASTERY ADVANCED: <white>" + name(after)));
            AkaiFx.sound(plugin, p.getLocation(), "mastery", 1.0f, 1.0f);
            AkaiFx.executionBurst(plugin, p.getLocation().add(0, 1, 0));
            if (after >= 3 && s.b("mastery.broadcast-final-stage", true))
                Bukkit.broadcast(s.mm("<dark_red>[AKAI NO \u014c] <red>" + p.getName() + " <gray>has become the <red><bold>ABSOLUTE SOVEREIGN</bold>"));
        }
    }

    public void addXp(Player p, long amount) {
        if (amount <= 0) return;
        AkaiData d = m.store().get(p.getUniqueId());
        int before = stage(d);
        d.xp += amount;
        recheck(p, before);
    }

    private boolean isDummy(LivingEntity t) {
        if (t instanceof ArmorStand) return true;
        if (t.getScoreboardTags().contains("akai_dummy") || t.getScoreboardTags().contains("dummy")) return true;
        if (t instanceof Mob mob && !mob.hasAI()) return true;
        if (t.customName() != null) {
            String n = PlainTextComponentSerializer.plainText().serialize(t.customName()).toLowerCase();
            for (String k : m.settings().list("mastery.dummy-name-contains")) if (!k.isEmpty() && n.contains(k.toLowerCase())) return true;
        }
        return false;
    }

    public void registerHit(Player p, AkaiType type, LivingEntity t) {
        AkaiSettings s = m.settings();
        if (isDummy(t)) return;
        AkaiState st = m.state(p); long now = System.currentTimeMillis();
        if (now - st.lastActiveMs > s.d("mastery.afk-seconds", 90) * 1000) return;
        boolean pl = t instanceof Player;
        long cd = (long) ((pl ? s.d("mastery.xp.player-target-cooldown-seconds", 45) : s.d("mastery.xp.mob-target-cooldown-seconds", 8)) * 1000);
        Long last = st.xpRepeat.get(t.getUniqueId());
        if (last != null && now - last < cd) return;
        st.xpRepeat.put(t.getUniqueId(), now);
        if (now - st.xpWindowStart > 3_600_000L) { st.xpWindowStart = now; st.xpWindow = 0; }
        double xp = pl ? s.d("mastery.xp.player-hit", 12) : t instanceof Monster ? s.d("mastery.xp.monster-hit", 4) : s.d("mastery.xp.other-hit", 1);
        if (type.isUltimate()) xp *= 2;
        int give = (int) Math.min(xp, Math.max(0, s.i("mastery.xp.hourly-cap", 700) - st.xpWindow));
        if (give <= 0) return;
        st.xpWindow += give;
        addXp(p, give);
    }

    public void registerKill(Player p, LivingEntity victim, boolean decreed) {
        AkaiSettings s = m.settings();
        if (isDummy(victim)) return;
        AkaiState st = m.state(p); long now = System.currentTimeMillis();
        Long last = st.killRepeat.get(victim.getUniqueId());
        st.killRepeat.put(victim.getUniqueId(), now);
        if (last != null && now - last < s.d("mastery.xp.same-victim-kill-cooldown-seconds", 600) * 1000) return;
        if (now - st.lastActiveMs > s.d("mastery.afk-seconds", 90) * 1000) return;
        AkaiData d = m.store().get(p.getUniqueId());
        int before = stage(d);
        d.kills++;
        if (decreed) d.decreeKills++;
        d.xp += (long) (victim instanceof Player ? s.d("mastery.xp.player-kill", 40) : s.d("mastery.xp.mob-kill", 5)) + (decreed ? 10 : 0);
        recheck(p, before);
    }
}

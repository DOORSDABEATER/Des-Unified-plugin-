package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent AKAI progression + Imperial Energy (survives relog and restart). */
public final class AkaiStore {
    private final NullRequiemPlugin plugin;
    private final File dir;
    private final Map<UUID, AkaiData> cache = new ConcurrentHashMap<>();

    public AkaiStore(NullRequiemPlugin plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "akai-data");
        if (!dir.exists() && !dir.mkdirs()) plugin.getLogger().warning("Could not create akai-data directory");
    }

    public AkaiData get(UUID id) { return cache.computeIfAbsent(id, this::load); }
    private File file(UUID id) { return new File(dir, id + ".yml"); }

    private AkaiData load(UUID id) {
        AkaiData d = new AkaiData(id);
        File f = file(id);
        if (!f.exists()) return d;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        d.name = y.getString("name", ""); d.owned = y.getBoolean("owned"); d.energy = Math.max(0, Math.min(100, y.getDouble("energy")));
        d.xp = y.getLong("xp"); d.hits = y.getInt("hits"); d.kills = y.getInt("kills"); d.decreeKills = y.getInt("decree-kills");
        d.casts = y.getInt("casts"); d.ultimates = y.getInt("ultimates"); d.cutsceneCamera = y.getBoolean("cutscene-camera", true);
        d.ultimateCooldownUntil = y.getLong("ultimate-cooldown-until");
        ConfigurationSection u = y.getConfigurationSection("uses");
        if (u != null) for (String k : u.getKeys(false)) d.uses.put(k, u.getInt(k));
        return d;
    }

    private YamlConfiguration snap(AkaiData d) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("name", d.name); y.set("owned", d.owned); y.set("energy", d.energy); y.set("xp", d.xp); y.set("hits", d.hits);
        y.set("kills", d.kills); y.set("decree-kills", d.decreeKills); y.set("casts", d.casts); y.set("ultimates", d.ultimates);
        y.set("cutscene-camera", d.cutsceneCamera); y.set("ultimate-cooldown-until", d.ultimateCooldownUntil);
        for (Map.Entry<String, Integer> e : d.uses.entrySet()) y.set("uses." + e.getKey(), e.getValue());
        return y;
    }

    public void saveSync(UUID id) {
        AkaiData d = cache.get(id);
        if (d == null) return;
        try { snap(d).save(file(id)); } catch (IOException e) { plugin.getLogger().warning("AKAI save failed for " + id + ": " + e.getMessage()); }
    }

    public void saveAllAsync() {
        for (AkaiData d : cache.values()) {
            YamlConfiguration y = snap(d); File f = file(d.uuid);
            Bukkit.getScheduler().runTaskAsynchronously(plugin.java(), () -> { try { y.save(f); } catch (IOException ignored) { } });
        }
    }

    public void saveAllSync() { for (UUID id : cache.keySet()) saveSync(id); }
    public void unload(UUID id) { cache.remove(id); }
    public void reset(UUID id) { cache.put(id, new AkaiData(id)); saveSync(id); }
}

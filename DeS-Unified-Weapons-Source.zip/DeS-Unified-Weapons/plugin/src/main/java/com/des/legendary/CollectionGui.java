package com.des.legendary;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Read-only collection screen: ownership, rarity, description, mastery progress and statistics for both weapons. */
public final class CollectionGui implements Listener {
    private static final class Holder implements InventoryHolder {
        Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }
    private final LegendaryPlugin pl;
    public CollectionGui(LegendaryPlugin pl) { this.pl = pl; }

    private static Component mm(String s) { return MiniMessage.miniMessage().deserialize(s).decoration(TextDecoration.ITALIC, false); }

    static String bar(double frac, int len, String on, String off) {
        int f = (int) Math.round(Math.max(0, Math.min(1, frac)) * len);
        return "<" + on + ">" + "\u258C".repeat(f) + "<" + off + ">" + "\u258C".repeat(len - f);
    }

    public void open(Player viewer, Player target) {
        Holder h = new Holder();
        Inventory inv = Bukkit.createInventory(h, 27, mm(pl.cfg().s("gui.title", "<gradient:#A855F7:#7DD3FC><bold>Legendary Collection</bold></gradient>")));
        h.inv = inv;
        PlayerData d = pl.data().get(target.getUniqueId());
        ItemStack pane = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta pm = pane.getItemMeta(); pm.displayName(Component.text(" ")); pane.setItemMeta(pm);
        for (int i = 0; i < 27; i++) inv.setItem(i, pane);
        inv.setItem(11, icon(Weapon.NOISEFORM, d));
        inv.setItem(15, icon(Weapon.NEBULUX, d));
        int owned = 0, uses = 0; for (Weapon w : Weapon.values()) { if (d.of(w).owned) owned++; uses += d.of(w).uses; }
        ItemStack info = new ItemStack(Material.BOOK); ItemMeta im = info.getItemMeta();
        im.displayName(mm("<gold><bold>" + target.getName() + "'s Collection"));
        im.lore(List.of(mm("<gray>Weapons owned: <white>" + owned + "/2"), mm("<gray>Total ability casts: <white>" + uses), Component.empty(), mm("<dark_gray>Dragon Empire SMP")));
        info.setItemMeta(im); inv.setItem(13, info);
        ItemStack close = new ItemStack(Material.BARRIER); ItemMeta cm = close.getItemMeta(); cm.displayName(mm("<red>Close")); close.setItemMeta(cm);
        inv.setItem(22, close);
        viewer.openInventory(inv);
    }

    private ItemStack icon(Weapon w, PlayerData d) {
        ItemStack it = pl.items().weapon(w);
        ItemMeta m = it.getItemMeta();
        PlayerData.WD x = d.of(w);
        int lv = pl.mastery().level(d, w);
        List<Double> th = pl.mastery().thresholds();
        double cur = th.get(lv - 1), next = lv >= 6 ? cur : th.get(lv);
        double frac = lv >= 6 ? 1.0 : (x.xp - cur) / Math.max(1.0, next - cur);
        String c = w.color.asHexString();
        List<Component> lore = new ArrayList<>();
        lore.add(mm("<gold>" + w.rarity + " <dark_gray>| <gray>" + w.style));
        lore.add(x.owned ? mm("<green>\u2714 In your collection") : mm("<red>\u2718 Not obtained yet"));
        lore.add(Component.empty());
        for (String line : pl.getConfig().getStringList("weapons." + w.key + ".lore")) lore.add(mm(line));
        lore.add(Component.empty());
        lore.add(mm("<" + c + "><bold>Mastery " + lv + "/6 <white>" + pl.mastery().levelName(lv) + (lv >= 6 ? " <gold>" + pl.mastery().title(w, lv) : "")));
        lore.add(mm(bar(frac, 24, c, "dark_gray") + " <gray>" + (lv >= 6 ? "MAX" : (int) x.xp + "/" + (int) next + " XP")));
        lore.add(Component.empty());
        lore.add(mm("<gray>Abilities cast: <white>" + x.uses + "  <gray>Hits: <white>" + x.hits + "  <gray>Kills: <white>" + x.kills));
        for (AbilityId a : w.abilities()) lore.add(mm("<" + c + ">\u25B8 " + a.display + " <dark_gray>(" + x.abilityUses.getOrDefault(a.key(), 0) + "x)"));
        lore.add(mm("<gold>\u2605 " + w.ultimate().display + " <dark_gray>(" + x.abilityUses.getOrDefault(w.ultimate().key(), 0) + "x)"));
        lore.add(Component.empty());
        lore.add(mm("<gray>" + w.energyName + ": <white>" + (int) x.energy + "/100"));
        m.lore(lore);
        it.setItemMeta(m);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder)) return;
        e.setCancelled(true);
        if (e.getRawSlot() == 22 && e.getWhoClicked() instanceof Player p) p.closeInventory();
    }
    @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true); }
}

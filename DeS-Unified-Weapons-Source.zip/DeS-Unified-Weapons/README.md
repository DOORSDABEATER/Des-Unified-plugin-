# DeS Unified Weapons — Dragon Empire SMP

A single Paper plugin JAR containing the three existing DeS legendary weapons:

- **NOISEFORM** — original DeS Legendary implementation, preserved in `com.des.legendary`.
- **NEBULUX** — original DeS Legendary implementation, preserved in `com.des.legendary`.
- **NULL//REQUIEM** — original scythe implementation, hosted as an internal subsystem in `dev.des.nullrequiem`.

The two weapon codebases are integrated under one Bukkit plugin lifecycle and one plugin descriptor. The NULL//REQUIEM subsystem has its own configuration and data directory so it does not overwrite the NOISEFORM/NEBULUX configuration or player data.

## Target

- Minecraft/Paper target configured for **26.2**
- Java toolchain **25**
- Paper API version property: `26.2.build.+` (pin this to the exact production Paper build if your repository/server uses a different coordinate)

## Build

From `plugin/` with JDK 25 and Gradle installed:

```bash
gradle clean build --no-daemon
```

Output:

`plugin/build/libs/DeS-Unified-Weapons-2.0.0.jar`

A GitHub Actions workflow is included at `.github/workflows/build.yml` and builds the JAR with Java 25.

## Install

1. Back up your server and existing plugin/player-data folders.
2. Remove the old `DeSLegendary` and `NullRequiem` JARs before starting the unified JAR. Do not run both old weapon plugins alongside this one; their listeners and commands would duplicate.
3. Put `DeS-Unified-Weapons-2.0.0.jar` in `plugins/`.
4. Install the **single merged resource pack** from `DeS-Complete-Weapon-ResourcePack.zip` (at the project root) using your existing resource-pack hosting method.
5. Start the server and inspect the console before allowing players to join.
6. Configure `plugins/DeSLegendary/config.yml` for NOISEFORM/NEBULUX and `plugins/DeSLegendary/nullrequiem/config.yml` for NULL//REQUIEM.

## Commands

- `/noiseform ...` — NOISEFORM administration
- `/nebulux ...` — NEBULUX administration
- `/weapon ...` — shared NOISEFORM/NEBULUX mastery, collection and ability commands
- `/nullrequiem ...` — NULL//REQUIEM administration, mastery, fragments, collection, abilities and ultimate controls

See `documentation/` for the original weapon command and ability references.

## Resource pack layout

The one resource pack preserves both namespaces:

- `assets/des/` — NOISEFORM + NEBULUX models, textures, item definitions, sounds and VFX assets.
- `assets/nullrequiem/` — NULL//REQUIEM models, textures, item definitions, language entries and sounds.

The dimension has **not** been implemented yet. When the separate Secret Realm plugin is developed, its assets can be added under its own namespace in this same resource pack. Its world generation, portals, boss AI and mechanics will remain in that separate plugin JAR.

## Integration notes / safety

- Original NOISEFORM and NEBULUX Java sources are retained; their entry point remains the only Bukkit `JavaPlugin` main class.
- NULL//REQUIEM's former `JavaPlugin` entry point was converted into an internal subsystem facade. Its listeners and tasks are registered/scheduled under the unified host plugin.
- NULL//REQUIEM config and player data are isolated under `plugins/DeSLegendary/nullrequiem/`.
- This is a source integration package, not a claim of in-game verification. Build it with the exact Paper 26.2 API and test on a staging server before production deployment. The supplied environment did not have JDK 25 or Gradle available, so a compiled JAR is not included.
- Keep backups of existing player data. The two projects use separate player-data formats and are intentionally kept separate rather than destructively merging player records.

package dev.des.nullrequiem.combat;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class PlayerStateManager {
    private final Map<UUID, PlayerState> states = new HashMap<>();
    public PlayerState get(Player p) { return states.computeIfAbsent(p.getUniqueId(), k -> new PlayerState()); }
    public PlayerState get(UUID id) { return states.computeIfAbsent(id, k -> new PlayerState()); }
    public void remove(UUID id) { states.remove(id); }
}

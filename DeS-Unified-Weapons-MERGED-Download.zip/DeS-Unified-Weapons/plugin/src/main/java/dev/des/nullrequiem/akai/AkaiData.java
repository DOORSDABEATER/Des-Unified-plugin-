package dev.des.nullrequiem.akai;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class AkaiData {
    public final UUID uuid;
    public String name = "";
    public boolean owned;
    public double energy;
    public long xp;
    public int hits, kills, decreeKills, casts, ultimates;
    public boolean cutsceneCamera = true;
    public long ultimateCooldownUntil;
    public final Map<String, Integer> uses = new HashMap<>();
    public AkaiData(UUID uuid) { this.uuid = uuid; }
}

package dev.des.nullrequiem.storage;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Persistent per-player progression for NULL//REQUIEM. */
public final class PlayerData {
    public final UUID uuid;
    public String name = "";
    public boolean owned;
    public long obtainedAt;
    public long xp;
    public int kills, exposedKills, hits, casts, ultimates;
    public long ultimateCooldownUntil;
    public boolean cutsceneCamera = true;
    public final Map<String, Integer> uses = new HashMap<>();

    public PlayerData(UUID uuid) { this.uuid = uuid; }
}

package dev.des.nullrequiem.abilities;

import dev.des.nullrequiem.NullRequiemPlugin;

/** 404: WORLD CORRUPTED entry point - delegates to UltimateManager (cinematic AOE). */
public final class UltimateAbility extends AbilityBase {
    public UltimateAbility(NullRequiemPlugin plugin) { super(plugin, AbilityType.ULTIMATE); }

    @Override
    public boolean execute(CastContext ctx) { return plugin.ultimate().start(ctx); }
}

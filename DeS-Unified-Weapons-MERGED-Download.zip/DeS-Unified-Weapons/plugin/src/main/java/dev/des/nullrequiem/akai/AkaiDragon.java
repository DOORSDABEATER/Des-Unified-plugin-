package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import dev.des.nullrequiem.vfx.Vfx;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.util.Vector;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Custom serpentine dragon built from ItemDisplay entities (head + body segments + tail, all pack models - not a vanilla mob).
 * Segments follow the head's recorded path. Bounded entity count; everything is released by dissolve()/remove() and by TaskTracker.
 */
public final class AkaiDragon {
    private final NullRequiemPlugin plugin;
    private final UUID owner;
    private final World world;
    private final List<ItemDisplay> parts = new ArrayList<>();
    private final ArrayList<Vector> trail = new ArrayList<>();
    private final float scale;
    private final double spacing;
    private Vector fwd;
    private Location head;
    private boolean removed;

    public AkaiDragon(NullRequiemPlugin plugin, UUID owner, Location start, Vector forward, int segs, float scale) {
        this.plugin = plugin; this.owner = owner; this.world = start.getWorld(); this.scale = scale;
        this.spacing = 0.625 * scale * 0.9;
        this.fwd = forward.clone().normalize();
        this.head = start.clone();
        for (int i = 0; i < 400; i++) trail.add(start.toVector().subtract(fwd.clone().multiply(i * 0.12)));
        for (int i = 0; i < segs; i++) {
            String model = i == 0 ? "akai:dragon_head" : i == segs - 1 ? "akai:dragon_tail" : "akai:dragon_body";
            Location at = start.clone().subtract(fwd.clone().multiply(i * spacing));
            parts.add(plugin.vfx().display(owner, at, model, new Vector3f(scale, scale, scale), Vfx.orient(fwd, new Vector(0, 1, 0)), false, 2));
        }
    }

    public Location head() { return head.clone(); }
    public boolean valid() { return !removed && !parts.isEmpty() && parts.get(0) != null && parts.get(0).isValid(); }
    public Vector forward() { return fwd.clone(); }

    public void move(Location newHead) {
        if (removed) return;
        Vector nh = newHead.toVector();
        Vector d = nh.clone().subtract(trail.get(0));
        if (d.lengthSquared() > 1e-6) fwd = d.clone().normalize();
        if (d.length() > 0.12) trail.add(0, nh.clone()); else trail.set(0, nh.clone());
        double need = parts.size() * spacing + 3;
        double acc = 0; int keep = trail.size();
        for (int i = 1; i < trail.size(); i++) { acc += trail.get(i).distance(trail.get(i - 1)); if (acc > need) { keep = i + 1; break; } }
        while (trail.size() > keep) trail.remove(trail.size() - 1);
        head = newHead.clone();
        Vector[] pos = new Vector[parts.size()];
        int idx = 0; double walked = 0;
        for (int i = 0; i < parts.size(); i++) {
            double target = i * spacing;
            while (idx < trail.size() - 1 && walked + trail.get(idx).distance(trail.get(idx + 1)) < target) { walked += trail.get(idx).distance(trail.get(idx + 1)); idx++; }
            if (idx >= trail.size() - 1) { pos[i] = trail.get(trail.size() - 1).clone(); continue; }
            double seg = trail.get(idx).distance(trail.get(idx + 1));
            double f = seg < 1e-6 ? 0 : (target - walked) / seg;
            pos[i] = trail.get(idx).clone().add(trail.get(idx + 1).clone().subtract(trail.get(idx)).multiply(f));
        }
        for (int i = 0; i < parts.size(); i++) {
            ItemDisplay p = parts.get(i);
            if (p == null || !p.isValid()) continue;
            Vector dir = i == 0 ? fwd : pos[i - 1].clone().subtract(pos[i]);
            if (dir.lengthSquared() < 1e-6) dir = fwd; else dir.normalize();
            p.teleport(pos[i].toLocation(world));
            plugin.vfx().animate(p, new Vector3f(scale, scale, scale), Vfx.orient(dir, new Vector(0, 1, 0)), 2);
        }
    }

    /** Dragon dissolves into crimson embers segment by segment. */
    public void dissolve(boolean embers) {
        if (removed) return;
        for (ItemDisplay p : parts) {
            if (p != null && p.isValid()) { if (embers) AkaiFx.embers(plugin, p.getLocation(), 14, scale * 0.35); plugin.tasks().release(owner, p); }
        }
        removed = true; parts.clear();
    }

    public void remove() { dissolve(false); }
}

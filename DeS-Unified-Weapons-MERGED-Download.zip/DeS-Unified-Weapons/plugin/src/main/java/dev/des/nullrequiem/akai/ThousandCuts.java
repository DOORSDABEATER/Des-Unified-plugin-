package dev.des.nullrequiem.akai;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.Location;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.joml.Vector3f;

import java.util.UUID;

/** 08 - phantom katana slashes from several directions in synchronized waves, then one concentrated strike. */
final class ThousandCuts extends AkaiBase {
    ThousandCuts(NullRequiemPlugin p, AkaiModule m) { super(p, m, AkaiType.THOUSAND_CUTS); }

    @Override public boolean execute(AkaiCtx ctx) {
        final Player p = ctx.player; final UUID id = p.getUniqueId();
        final LivingEntity target = aimTarget(p, cfg("range", 24), cfg("cone-degrees", 30), true);
        if (target == null) { actionbar(p, "<red>THOUSAND CUTS <gray>- no target in sight"); return false; }
        ctx.maxHits = 14;
        p.swingMainHand();
        final int waves = 3, perWave = 4;
        snd(target.getLocation(), "a8_phantom", 1.2f, 1.0f);
        for (int w = 0; w < waves; w++) {
            final int wave = w;
            plugin.tasks().later(id, 2 + w * cfgI("wave-gap-ticks", 14), () -> {
                if (!alive(p) || !target.isValid() || target.isDead()) return;
                Location center = target.getLocation().add(0, target.getHeight() / 2, 0);
                snd(center, "a8_phantom", 1.0f, 1.0f + wave * 0.12f);
                double base = Math.random() * Math.PI * 2;
                for (int k = 0; k < perWave; k++) {
                    double ang = base + k * Math.PI / 2 + wave * 0.39;
                    Location from = center.clone().add(Math.cos(ang) * 4.5, (k % 2 == 0 ? 0.8 : -0.2) + wave * 0.5, Math.sin(ang) * 4.5);
                    Vector dir = center.toVector().subtract(from.toVector()).normalize();
                    Vector hint = UP.clone().rotateAroundAxis(dir, Math.toRadians(k * 45 + wave * 20));
                    ItemDisplay ghost = vfx().display(id, from, "akai:katana", new Vector3f(1.6f, 1.6f, 1.6f), dev.des.nullrequiem.vfx.Vfx.orient(dir, hint), true, 0);
                    if (ghost != null) plugin.tasks().later(id, 8, () -> plugin.tasks().release(id, ghost));
                    slash(ctx, from, dir, 6.5, 1.7, 1.5, 0, cfg("damage", 3.0), 2.8f, hint, false, "a1_hit", null);
                }
            });
        }
        plugin.tasks().later(id, 2 + waves * cfgI("wave-gap-ticks", 14) + 6, () -> {
            if (!alive(p) || !target.isValid() || target.isDead()) return;
            Location tl = target.getLocation();
            snd(tl, "a8_final", 1.5f, 1.0f);
            Vector right = p.getLocation().getDirection().crossProduct(UP).normalize();
            slash(ctx, tl.clone().add(0, 3.6, 0), new Vector(0, -1, 0), 4.8, 1.5, 2.0, 0, cfg("final-damage", 12), 4.6f, right, true, "a8_final",
                end -> { AkaiFx.cross(plugin, end.clone().add(0, 1, 0), right, 2.4); AkaiFx.sphereBurst(plugin, end, 1.6); shockRing(id, end, 4, 6); });
        });
        return true;
    }
}

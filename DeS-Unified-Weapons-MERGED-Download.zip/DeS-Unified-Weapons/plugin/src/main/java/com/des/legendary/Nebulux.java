package com.des.legendary;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.EnumMap;
import java.util.concurrent.ThreadLocalRandom;

/** NEBULUX - cosmic domination. Six abilities + Supernova. High-skill kit: every ability can be dodged, aimed or timed. */
final class Nebulux {
    private Nebulux() {}

    static void register(LegendaryPlugin pl, EnumMap<AbilityId, Abilities.Handler> r) {
        r.put(AbilityId.PRISMATIC_CLEAVE, c -> cleave(pl, c));
        r.put(AbilityId.STARFALL, c -> starfall(pl, c));
        r.put(AbilityId.GRAVITY_WELL, c -> gravity(pl, c));
        r.put(AbilityId.ASTRAL_FRACTURE, c -> fracture(pl, c));
        r.put(AbilityId.CHROMATIC_REFRACTION, c -> refraction(pl, c));
        r.put(AbilityId.CELESTIAL_PIERCE, c -> pierce(pl, c));
        r.put(AbilityId.SUPERNOVA, c -> supernova(pl, c));
    }

    private static Location mid(LivingEntity e) { return e.getBoundingBox().getCenter().toLocation(e.getWorld()); }
    private static final Color GREEN = Color.fromRGB(120, 255, 160);

    // ------------------------------------------------------------------ 1. PRISMATIC CLEAVE
    private static void cleave(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        double[] dmg = {cfg.x(c.id, "slash1-damage", 3), cfg.x(c.id, "slash2-damage", 3), cfg.x(c.id, "slash3-damage", 6)};
        double range = cfg.x(c.id, "range", 12), speed = cfg.x(c.id, "speed", 1.4);
        int gap = (int) cfg.x(c.id, "slash-gap-ticks", 8);
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 6);
        String[] model = {"crescent_ember", "crescent_aqua", "crescent_nova"};
        Color[][] col = {{Pal.EMBER, Pal.GOLD}, {Pal.CYAN, GREEN}, {Pal.VIOLET, Pal.WHITE}};
        double[] startYaw = {-24, 24, 0}, endYaw = {12, -12, 0};                // each slash travels a different arc
        float[] size = {2.8f, 2.8f, 5.2f};
        double[] rad = {1.2, 1.2, 1.9};
        double grow = c.empowered ? 1.25 : 1.0;
        Location[] pos = new Location[3]; Vector[] base = new Vector[3]; ItemDisplay[] disp = new ItemDisplay[3];
        double[] trav = new double[3]; int[] st = new int[3];
        pl.casts().start(c, age -> {
            int open = 0;
            for (int i = 0; i < 3; i++) {
                if (st[i] == 2) continue;
                open++;
                final int k = i;
                if (st[i] == 0) {
                    if (age < i * gap) continue;
                    p.swingMainHand();                                          // launch uses the player's CURRENT aim -> tracking is rewarded
                    base[i] = p.getEyeLocation().getDirection().normalize();
                    pos[i] = p.getEyeLocation().add(base[i].clone().multiply(1.2)).add(0, -0.3, 0);
                    disp[i] = c.track(fx.facing(pos[i], model[i], (float) (size[i] * grow), (float) (size[i] * grow), base[i], (float) Math.toRadians(i == 1 ? 25 : -25), (int) (range / speed) + 8));
                    pl.sfx().play(p.getLocation(), "nebulux.cleave_slash" + (i + 1), i == 2 ? 1.5f : 1f, 1f);
                    if (c.tier >= 2) fx.ring(p.getLocation().add(0, 0.1, 0), 1.0 + i * 0.3, 14, col[i][0], col[i][1], 1.0f);
                    st[i] = 1;
                }
                double f = trav[i] / range;
                Vector dir = base[i].clone().rotateAroundY(Math.toRadians(startYaw[i] + (endYaw[i] - startYaw[i]) * f));
                boolean blocked = Proj.advance(pl, c, pos[i], dir, speed, rad[i] * grow, e -> {
                    if (c.hit(e, "s" + k, dmg[k])) {
                        Location l = mid(e);
                        pl.sfx().play(l, "nebulux.cleave_hit", 1f, 1f + 0.15f * k);
                        fx.burst(l, col[k][0], col[k][1], 26 + k * 14, 1.0 + k * 0.4);
                        if (k == 2) {                                           // third slash: heavier impact
                            pl.cc().velocity(e, dir.clone().multiply(0.8).setY(0.3), c.ccMult(e));
                            if (c.empowered) pl.cc().slow(e, 20, 2, c.ccMult(e));
                            if (c.tier >= 4) fx.ring(l, 1.8, 28, Pal.rainbow(0.0), Pal.rainbow(0.5), 1.5f);
                        }
                    }
                });
                trav[i] += speed;
                fx.move(disp[i], pos[i]);
                fx.dust2(pos[i], col[i][0], col[i][1], 1.7f, 6, 0.35);
                fx.dust(pos[i], Pal.rainbow(age * 0.05 + i * 0.3), 1.2f, 3, 0.4);
                fx.part(Particle.END_ROD, pos[i], 1, 0.3, 0.02);
                if (blocked || trav[i] >= range) {
                    fx.burst(pos[i], col[i][0], col[i][1], i == 2 ? 50 : 24, i == 2 ? 1.6 : 0.9);
                    st[i] = 2; fx.remove(disp[i]);
                }
            }
            return open == 0;
        }, null);
    }

    // ------------------------------------------------------------------ 2. STARFALL
    private static void starfall(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        double range = cfg.x(c.id, "range", 18), dmg = cfg.dmg(c.id), r = cfg.x(c.id, "radius", 3.0);
        int warn = (int) cfg.x(c.id, "warning-ticks", 28), gap = (int) cfg.x(c.id, "meteor-gap-ticks", 14), fall = 10;
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 8);
        Location center = Util.aimPoint(pl, p, range);
        if (center.distanceSquared(p.getLocation()) > (range + 4) * (range + 4)) { c.fail("Target too far"); return; }
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        Location[] imp = new Location[3];
        imp[0] = center.clone();
        for (int i = 1; i < 3; i++) imp[i] = Util.ground(center.clone().add(rnd.nextDouble(-2.5, 2.5), 1.5, rnd.nextDouble(-2.5, 2.5)));
        int[] land = {warn, warn + gap, warn + 2 * gap};
        ItemDisplay[] mk = new ItemDisplay[3], met = new ItemDisplay[3];
        mk[0] = c.track(fx.flat(imp[0].clone().add(0, 0.12, 0), "marker_star", (float) (r * 2.2), 0f, land[2] + 40));
        mk[1] = c.track(fx.flat(imp[1].clone().add(0, 0.12, 0), "marker_warn", (float) (r * 1.5), 0f, land[2] + 40));
        mk[2] = c.track(fx.flat(imp[2].clone().add(0, 0.12, 0), "marker_warn", (float) (r * 1.8), 0f, land[2] + 40));
        pl.sfx().play(center, "nebulux.starfall_mark", 1.3f, 1f);
        p.swingMainHand();
        int linger = c.empowered ? 40 : 0;
        pl.casts().start(c, age -> {
            if (age % 6 == 0) for (int i = 0; i < 3; i++) fx.spin(mk[i], 6, 0.7f);
            if (age < land[2] && age % 2 == 0) for (int i = 0; i < 3; i++) if (age < land[i]) fx.ring(imp[i].clone().add(0, 0.2, 0), i == 2 ? r + 0.8 : r, 26, Pal.rainbow(age * 0.04 + i * 0.3), Pal.WHITE, 1.2f);
            for (int i = 0; i < 3; i++) {
                int t0 = land[i] - fall;
                if (age == t0) {
                    met[i] = c.track(fx.billboard(imp[i].clone().add(0, 14, 0), "orb_prism", i == 2 ? 3.4f : 2.3f, fall + 6));
                    pl.sfx().play(imp[i], "nebulux.starfall_fall", 1.2f, 1f);
                }
                if (age > t0 && age < land[i]) {
                    double f = (age - t0) / (double) fall;
                    Location mp = imp[i].clone().add(0, 14 * (1 - f), 0);
                    fx.move(met[i], mp);
                    for (int k = 0; k < 6; k++) fx.dust(mp.clone().add(0, k * 0.6, 0), Pal.rainbow(age * 0.05 + k * 0.15), 1.9f, 2, 0.25);   // rainbow meteor trail
                    fx.part(Particle.END_ROD, mp, 2, 0.3, 0.02);
                }
                if (age == land[i]) {
                    double rr = i == 2 ? r + 0.8 : r;
                    fx.remove(met[i]); fx.remove(mk[i]);
                    for (LivingEntity e : Targets.sphere(pl, p, imp[i].clone().add(0, 0.6, 0), rr)) {
                        if (c.hit(e, "m" + i, dmg)) {
                            Vector out = mid(e).toVector().subtract(imp[i].toVector()).setY(0);
                            out = out.lengthSquared() < 1e-4 ? new Vector() : out.normalize().multiply(0.5);
                            pl.cc().velocity(e, out.setY(0.45), c.ccMult(e));
                        }
                    }
                    pl.sfx().play(imp[i], "nebulux.starfall_impact", i == 2 ? 2.4f : 1.6f, i == 2 ? 0.8f : 1f);
                    fx.explosion(imp[i].clone().add(0, 0.5, 0), rr * (i == 2 ? 0.9 : 0.6), Pal.rainbow(0.05 + i * 0.3), Pal.rainbow(0.55 + i * 0.1));
                    fx.debris(imp[i], 30, rr * 0.4);
                    ItemDisplay ring = c.track(fx.flat(imp[i].clone().add(0, 0.15, 0), "ring_prism", 1f, 0f, 14));
                    fx.resize(ring, 7, (float) (rr * 2.4), (float) (rr * 2.4));
                }
            }
            if (linger > 0 && age > land[2] && age <= land[2] + linger) {       // empowered: lingering prism fields slow enemies
                for (int i = 0; i < 3; i++) {
                    if (age % 5 == 0) fx.ring(imp[i].clone().add(0, 0.2, 0), r, 20, Pal.rainbow(age * 0.05), Pal.WHITE, 1.0f);
                    for (LivingEntity e : Targets.sphere(pl, p, imp[i].clone().add(0, 0.6, 0), r)) pl.cc().slow(e, 10, 1, c.ccMult(e));
                }
            }
            return age >= land[2] + linger;
        }, null);
    }

    // ------------------------------------------------------------------ 3. GRAVITY WELL
    private static void gravity(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        double range = cfg.x(c.id, "range", 24), speed = cfg.x(c.id, "speed", 1.2), radius = cfg.x(c.id, "radius", 5) + (c.empowered ? 1 : 0), dmg = cfg.dmg(c.id);
        int pull = cfg.ticks(c.id, "pull-time", 2.0) + (c.empowered ? 10 : 0);
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 10);
        Vector dir = c.dir();
        Location pos = c.eye().add(dir.clone().multiply(1.2));
        ItemDisplay orb = c.track(fx.billboard(pos, "orb_prism", 1.4f, 300));
        pl.sfx().play(p.getLocation(), "nebulux.gravity_launch", 1.2f, 1f);
        p.swingMainHand();
        boolean[] landed = {false}; boolean[] touched = {false}; int[] t0 = {0}; double[] trav = {0}; Location[] core = new Location[1]; ItemDisplay[] ring = new ItemDisplay[1];
        pl.casts().start(c, age -> {
            if (!landed[0]) {
                boolean blocked = Proj.advance(pl, c, pos, dir, speed, 1.0, e -> touched[0] = true);
                trav[0] += speed;
                fx.move(orb, pos);
                for (int k = 0; k < 3; k++) fx.dust(pos.clone().add(Math.cos(age * 0.8 + k * 2.1) * 0.5, Math.sin(age * 0.8 + k * 2.1) * 0.5, 0), Pal.rainbow(age * 0.06 + k * 0.33), 1.5f, 1, 0.05);
                fx.part(Particle.REVERSE_PORTAL, pos, 4, 0.4, 0.05);
                if (blocked || touched[0] || trav[0] >= range) {
                    landed[0] = true; t0[0] = age;
                    core[0] = pos.clone().subtract(dir.clone().multiply(blocked ? 0.4 : 0.0));
                    ring[0] = c.track(fx.flat(Util.ground(core[0]).add(0, 0.12, 0), "ring_prism", (float) (radius * 2.0), 0f, pull + 30));
                    fx.resize(orb, 6, 2.6f, 2.6f);
                    pl.sfx().play(core[0], "nebulux.gravity_pull", 1.5f, 1f);
                }
                return false;
            }
            int a = age - t0[0];
            Location cc = core[0];
            if (a % 8 == 0) fx.spin(ring[0], 8, 0.9f);
            for (int ringI = 0; ringI < 2; ringI++) for (int j = 0; j < 18; j++) {           // rotating rainbow rings
                double ang = a * 0.35 * (ringI == 0 ? 1 : -1) + j * Math.PI * 2 / 18, rr = radius * (1.0 - 0.35 * Math.min(1.0, a / (double) pull)) * (ringI == 0 ? 0.9 : 0.6);
                double tilt = ringI == 0 ? 0.35 : -0.5;
                fx.dust(cc.clone().add(Math.cos(ang) * rr, Math.sin(ang) * rr * tilt, Math.sin(ang) * rr), Pal.rainbow(j / 18.0 + a * 0.03), 1.3f, 1, 0.0);
            }
            fx.part(Particle.REVERSE_PORTAL, cc, 8, radius * 0.5, 0.25);                       // gravitational distortion
            if (a < pull) {
                for (LivingEntity e : Targets.sphere(pl, p, cc, radius)) {
                    double m = c.ccMult(e); if (m <= 0) continue;
                    Vector v = cc.toVector().subtract(mid(e).toVector());
                    v = v.length() < 0.9 ? new Vector(0, 0.02, 0) : v.normalize().multiply(0.3);
                    v.setY(Math.max(-0.15, Math.min(0.3, v.getY())));
                    pl.cc().velocity(e, v, m);
                }
                return false;
            }
            for (LivingEntity e : Targets.sphere(pl, p, cc, radius)) {                         // implosion
                if (c.hit(e, "implode", dmg)) {
                    Vector in = cc.toVector().subtract(mid(e).toVector()).multiply(0.18);
                    pl.cc().velocity(e, in.setY(Math.max(0.25, in.getY())), c.ccMult(e));
                }
            }
            fx.resize(orb, 3, 0.2f, 0.2f);
            pl.sfx().play(cc, "nebulux.gravity_implode", 1.8f, 1f);
            fx.explosion(cc, radius * 0.55, Pal.rainbow(0.7), Pal.WHITE);
            fx.sphere(cc, radius * 0.9, 50, Pal.rainbow(0.1), Pal.rainbow(0.6), 1.5f);
            return true;
        }, null);
    }

    // ------------------------------------------------------------------ 4. ASTRAL FRACTURE (+ recall)
    private static void fracture(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx(); PlayerData d = pl.data().get(p.getUniqueId());
        double dist = cfg.x(c.id, "distance", 8);
        Location start = p.getLocation().clone();
        Vector dir = p.getEyeLocation().getDirection();
        dir.setY(Math.max(-0.5, Math.min(0.5, dir.getY()))).normalize();
        Location dest = SafeMove.teleportSpot(start, dir, dist);                       // respects blocks, border, lava/void
        if (dest == null || dest.distanceSquared(start) < 1.0) { c.fail("No safe landing spot"); return; }
        int window = cfg.ticks(c.id, "return-window", 2.0) + (c.tier >= 3 ? 10 : 0) + (c.empowered ? 20 : 0);   // mastery 3: +0.5s
        PlayerData.Fracture f = new PlayerData.Fracture();
        f.origin = start.clone(); f.endTick = pl.casts().now() + window; f.tier = c.tier;
        f.rift = c.track(fx.facing(start.clone().add(0, 1.4, 0), "rift", 1.6f, 3.2f, Util.flatDir(p), 0f, window + 10));
        d.fracture = f;
        pl.sfx().play(start, "nebulux.astral_out", 1.3f, 1f);
        fx.burst(start.clone().add(0, 1, 0), Pal.rainbow(0.1), Pal.WHITE, 40, 1.2);
        fx.ring(start.clone().add(0, 0.2, 0), 1.4, 24, Pal.rainbow(0.6), Pal.WHITE, 1.4f);
        p.swingMainHand();
        boolean[] arrived = {false};
        pl.casts().start(c, age -> {
            if (age == 2 && !arrived[0]) {                                              // two-stage teleport: depart flash, then arrive
                arrived[0] = true;
                fx.line(start.clone().add(0, 1, 0), dest.clone().add(0, 1, 0), 0.25, Pal.rainbow(0.0), Pal.rainbow(0.7), 1.5f);
                p.teleport(dest); p.setFallDistance(0f);
                fx.burst(dest.clone().add(0, 1, 0), Pal.rainbow(0.55), Pal.WHITE, 40, 1.2);
                pl.sfx().play(dest, "nebulux.astral_out", 1.0f, 1.3f);
            }
            if (d.fracture != f) return true;                                           // recalled or cancelled
            if (age % 2 == 0) for (int k = 0; k < 6; k++) fx.dust(f.origin.clone().add(Fx.rnd(-0.5, 0.5), 0.4 + k * 0.5, Fx.rnd(-0.5, 0.5)), Pal.rainbow(age * 0.05 + k * 0.17), 1.4f, 1, 0.05);
            fx.part(Particle.REVERSE_PORTAL, f.origin.clone().add(0, 1.4, 0), 4, 0.35, 0.1);
            if (pl.casts().now() >= f.endTick) {                                       // window over: rift collapses
                d.fracture = null;
                fx.burst(f.origin.clone().add(0, 1.4, 0), Pal.rainbow(0.2), Pal.WHITE, 24, 1.0);
                return true;
            }
            return false;
        }, () -> { if (d.fracture == f) d.fracture = null; });
    }

    /** Second activation inside the window: snap back to the rift and release a small energy slash. */
    static void recall(LegendaryPlugin pl, Player p, PlayerData d) {
        PlayerData.Fracture f = d.fracture; d.fracture = null;
        if (f == null) return;
        Fx fx = pl.fx(); Cfg cfg = pl.cfg();
        Location from = p.getLocation().clone();
        Location target = f.origin.getWorld() != null && f.origin.getWorld().equals(from.getWorld()) ? SafeMove.nearestFit(f.origin, 2) : null;
        if (f.rift != null) fx.remove(f.rift);
        if (target == null) { p.sendActionBar(MiniMessage.miniMessage().deserialize("<red>The rift collapsed")); return; }
        target.setYaw(from.getYaw()); target.setPitch(from.getPitch());
        fx.line(from.clone().add(0, 1, 0), target.clone().add(0, 1, 0), 0.25, Pal.rainbow(0.7), Pal.rainbow(0.1), 1.5f);
        fx.burst(from.clone().add(0, 1, 0), Pal.rainbow(0.3), Pal.WHITE, 30, 1.0);
        p.teleport(target); p.setFallDistance(0f);
        fx.burst(target.clone().add(0, 1, 0), Pal.rainbow(0.0), Pal.WHITE, 40, 1.2);
        pl.sfx().play(target, "nebulux.astral_return", 1.3f, 1f);
        p.swingMainHand();

        Ctx c = new Ctx(pl, p, Weapon.NEBULUX, AbilityId.ASTRAL_FRACTURE, false, f.tier);
        c.maxTargets = 6;
        double dmg = cfg.x(AbilityId.ASTRAL_FRACTURE, "return-damage", cfg.dmg(AbilityId.ASTRAL_FRACTURE));
        Vector dir = c.dir(); Location pos = c.eye().add(dir.clone().multiply(1.0)).add(0, -0.3, 0);
        ItemDisplay d2 = c.track(fx.facing(pos, "crescent_aqua", 3.2f, 3.2f, dir, 0.4f, 16));
        double[] trav = {0};
        pl.casts().start(c, age -> {
            boolean blocked = Proj.advance(pl, c, pos, dir, 1.5, 1.7, e -> {
                if (c.hit(e, "return", dmg)) { Location l = mid(e); pl.sfx().play(l, "nebulux.cleave_hit", 1f, 0.9f); fx.burst(l, Pal.CYAN, Pal.WHITE, 30, 1.0); }
            });
            trav[0] += 1.5;
            fx.move(d2, pos);
            fx.dust2(pos, Pal.CYAN, GREEN, 1.6f, 5, 0.3);
            fx.dust(pos, Pal.rainbow(age * 0.08), 1.2f, 3, 0.35);
            return blocked || trav[0] >= 7.5;
        }, null);
    }

    // ------------------------------------------------------------------ 5. CHROMATIC REFRACTION
    private static void refraction(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx(); PlayerData d = pl.data().get(p.getUniqueId());
        int dur = cfg.ticks(c.id, "duration", 2.5), perfect = cfg.ticks(c.id, "perfect-window", 1.0) + (c.empowered ? 8 : 0);
        double counterDmg = cfg.dmg(c.id);
        c.maxTargets = 4;
        PlayerData.Guard g = new PlayerData.Guard();
        g.w = Weapon.NEBULUX; g.reduction = cfg.x(c.id, "reduction", 0.35);
        g.endTick = pl.casts().now() + dur; g.perfectEnd = pl.casts().now() + perfect;
        g.perfect = attacker -> counter(pl, c, attacker, counterDmg);
        d.guard = g;
        pl.sfx().play(p.getLocation(), "nebulux.refraction_start", 1.2f, 1f);
        p.swingMainHand();
        fx.burst(p.getLocation().add(0, 1, 0), Pal.rainbow(0.1), Pal.WHITE, 30, 1.3);
        ItemDisplay shield = c.track(fx.billboard(p.getLocation().add(0, 1, 0), "shield_prism", 0.5f, dur + 10));
        fx.resize(shield, 5, 3.3f, 3.3f);
        pl.casts().start(c, age -> {
            if (d.guard != g) return true;
            Location chest = p.getLocation().add(0, 1.0, 0);
            fx.move(shield, chest);
            boolean window = pl.casts().now() <= g.perfectEnd && !g.counterUsed;
            if (age % 2 == 0) for (int j = 0; j < 14; j++) {                                  // crystalline distortion shell
                double ang = age * 0.25 + j * Math.PI * 2 / 14, rr = 1.5;
                fx.dust(chest.clone().add(Math.cos(ang) * rr, Math.sin(ang * 2 + age * 0.1) * 0.8, Math.sin(ang) * rr), window ? Pal.WHITE : Pal.rainbow(j / 14.0 + age * 0.04), window ? 1.5f : 1.1f, 1, 0.0);
            }
            if (pl.casts().now() == g.perfectEnd + 1 && !g.counterUsed) pl.sfx().play(chest, "nebulux.refraction_hit", 0.5f, 0.7f);   // window closed cue
            if (age >= dur) {
                d.guard = null;
                fx.burst(chest, Pal.rainbow(0.4), Pal.WHITE, 26, 1.2);
                return true;
            }
            return false;
        }, () -> { if (d.guard == g) d.guard = null; });
    }

    /** Perfect refraction: a focused rainbow bolt homes on the attacker. */
    static void counter(LegendaryPlugin pl, Ctx c, LivingEntity attacker, double dmg) {
        Player p = c.p; Fx fx = pl.fx();
        if (!attacker.isValid() || attacker.isDead()) return;
        Location chest = p.getLocation().add(0, 1.2, 0);
        pl.sfx().play(chest, "nebulux.refraction_counter", 1.6f, 1f);
        fx.burst(chest, Pal.WHITE, Pal.rainbow(0.3), 50, 1.7);
        fx.ring(chest, 1.8, 32, Pal.rainbow(0.0), Pal.rainbow(0.6), 1.6f);
        p.sendActionBar(MiniMessage.miniMessage().deserialize("<gold><bold>\u2726 PERFECT REFRACTION \u2726"));
        pl.energy().gain(p, Weapon.NEBULUX, pl.cfg().x(AbilityId.CHROMATIC_REFRACTION, "perfect-energy", 10));
        Location pos = chest.clone();
        ItemDisplay bolt = c.track(fx.billboard(pos, "flare_prism", 1.8f, 40));
        double speed = 2.4;
        pl.casts().start(c, age -> {
            if (!attacker.isValid() || attacker.isDead() || age > 24) { fx.remove(bolt); return true; }
            Vector to = mid(attacker).toVector().subtract(pos.toVector());
            double dist = to.length();
            if (dist <= speed + 0.9) {
                if (c.hit(attacker, "counter", dmg)) {
                    Location l = mid(attacker);
                    pl.sfx().play(l, "nebulux.pierce_hit", 1.2f, 1f);
                    fx.burst(l, Pal.WHITE, Pal.rainbow(0.2), 45, 1.4);
                }
                fx.remove(bolt); return true;
            }
            Location from = pos.clone();
            pos.add(to.normalize().multiply(speed));
            fx.move(bolt, pos);
            fx.line(from, pos, 0.25, Pal.rainbow(age * 0.1), Pal.WHITE, 1.4f);
            return false;
        }, null);
    }

    // ------------------------------------------------------------------ 6. CELESTIAL PIERCE
    private static void pierce(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx();
        int charge = cfg.ticks(c.id, "charge-time", 1.0), lock = charge / 2;
        double range = cfg.x(c.id, "range", 16), dmg = cfg.dmg(c.id), width = cfg.x(c.id, "width", 1.0) + (c.empowered ? 0.4 : 0), bspeed = 4.0;
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 6) + (c.empowered ? 1 : 0);
        c.requireHeld = true;
        Location e0 = p.getEyeLocation();
        ItemDisplay crystal = c.track(fx.billboard(e0.clone().add(e0.getDirection().multiply(1.8)), "flare_prism", 0.3f, charge + 10));
        fx.resize(crystal, charge, 2.2f, 2.2f);
        pl.sfx().play(p.getLocation(), "nebulux.pierce_charge", 1.3f, 1f);
        Vector[] dir = new Vector[1]; Location[] org = new Location[1]; double[] len = {range}, trav = {0};
        pl.casts().start(c, age -> {
            if (age < charge) {
                Location eye = p.getEyeLocation();
                if (age < lock || dir[0] == null) dir[0] = eye.getDirection().normalize();                    // aim tracks until the lock tick, then it is fixed
                org[0] = eye.clone();
                var rt = eye.getWorld().rayTraceBlocks(eye, dir[0], range, org.bukkit.FluidCollisionMode.NEVER, true);
                len[0] = rt != null ? eye.toVector().distance(rt.getHitPosition()) : range;
                Location cr = eye.clone().add(dir[0].clone().multiply(1.8));
                fx.move(crystal, cr);
                if (age % 5 == 0) p.swingMainHand();
                double prog = age / (double) charge, rr = 2.0 * (1 - prog) + 0.3;
                for (int k = 0; k < 4; k++) {                                                               // rainbow energy concentrating into the crystal
                    double a = age * 0.6 + k * 1.57;
                    fx.line(cr.clone().add(Math.cos(a) * rr, Math.sin(a) * rr, Math.cos(a * 0.5) * rr * 0.5), cr, 0.5, Pal.rainbow(a * 0.2), Pal.WHITE, 1.0f);
                }
                boolean locked = age >= lock;
                double step = locked ? 0.35 : 1.0;                                                          // visible warning: dashed while aiming, solid once locked
                for (double s = 2.5; s < len[0]; s += step) fx.dust(eye.clone().add(dir[0].clone().multiply(s)), locked ? Pal.WHITE : Pal.rainbow(s * 0.08), locked ? 0.9f : 0.6f, 1, 0.0);
                if (age == lock) pl.sfx().play(eye, "nebulux.refraction_hit", 0.8f, 1.8f);
                return false;
            }
            if (age == charge) {
                c.requireHeld = false;
                fx.remove(crystal);
                pl.sfx().play(p.getLocation(), "nebulux.pierce_fire", 2.0f, 1f);
                p.swingMainHand();
                fx.burst(org[0].clone().add(dir[0].clone().multiply(1.6)), Pal.WHITE, Pal.rainbow(0.3), 40, 1.2);
            }
            double from = trav[0], to = Math.min(len[0], from + bspeed);                                    // the beam travels - enemies can still step out
            for (double s = from; s <= to; s += 0.5) {
                Location q = org[0].clone().add(dir[0].clone().multiply(s));
                fx.dust(q, Pal.rainbow(s * 0.1 + age * 0.05), 2.1f, 3, 0.12);
                fx.part(Particle.END_ROD, q, 1, 0.05, 0.0);
            }
            for (double s = from; s <= to; s += 1.0) {
                Location q = org[0].clone().add(dir[0].clone().multiply(s));
                for (LivingEntity e : Targets.sphere(pl, p, q, width)) {
                    if (c.hit(e, "beam", dmg)) {
                        Location l = mid(e);
                        pl.sfx().play(l, "nebulux.pierce_hit", 1f, 1f);
                        fx.burst(l, Pal.WHITE, Pal.rainbow(s * 0.1), 36, 1.2);
                    }
                }
            }
            trav[0] = to;
            if (to >= len[0]) { fx.burst(org[0].clone().add(dir[0].clone().multiply(len[0])), Pal.WHITE, Pal.rainbow(0.5), 30, 1.1); return true; }
            return false;
        }, () -> { if (c.cancelled && trav[0] == 0) pl.data().get(p.getUniqueId()).cooldowns.remove(c.id.key()); });
    }

    // ------------------------------------------------------------------ ULTIMATE: SUPERNOVA
    private static void supernova(LegendaryPlugin pl, Ctx c) {
        Player p = c.p; Cfg cfg = pl.cfg(); Fx fx = pl.fx(); PlayerData d = pl.data().get(p.getUniqueId());
        int charge = cfg.ticks(c.id, "charge-time", 2.0), expand = 8;
        double radius = cfg.x(c.id, "radius", 8), dmg = cfg.dmg(c.id);
        int distort = (int) cfg.x(c.id, "distortion-ticks", 50);
        c.maxTargets = (int) cfg.x(c.id, "max-targets", 12);
        c.requireHeld = true;
        Location base = p.getLocation().clone();
        p.setGravity(false);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, charge + 6, 5, false, false, false));
        ItemDisplay sphere = c.track(fx.billboard(base.clone().add(0, 3.8, 0), "orb_prism", 1.0f, charge + expand + 20));
        fx.resize(sphere, charge, (float) (radius * 0.9), (float) (radius * 0.9));
        ItemDisplay danger = c.track(fx.flat(Util.ground(base.clone()).add(0, 0.12, 0), "ring_prism", (float) (radius * 2.0), 0f, charge + expand + 10));
        ItemDisplay marker = c.track(fx.flat(Util.ground(base.clone()).add(0, 0.14, 0), "marker_star", (float) (radius * 1.6), 0f, charge + expand + 10));
        pl.sfx().play(base, "nebulux.supernova_charge", 2.6f, 1f);
        p.swingMainHand();
        Location[] ctr = new Location[1]; boolean[] released = {false};
        pl.casts().start(c, age -> {
            Location floor = Util.ground(base.clone());
            if (age < charge) {
                p.setVelocity(new Vector(0, age < 20 ? 0.09 : 0.0, 0));                                    // rises slightly, then hovers
                p.setFallDistance(0f);
                Location orb = p.getLocation().add(0, 2.8, 0);
                fx.move(sphere, orb);
                if (age % 6 == 0) { fx.spin(danger, 6, 0.8f); fx.spin(marker, 6, -0.6f); p.swingMainHand(); }
                double prog = age / (double) charge;
                for (int j = 0; j < 36; j++) {                                                              // danger zone edge: players must be able to see and leave it
                    double ang = j * Math.PI * 2 / 36 + age * 0.05;
                    fx.dust(floor.clone().add(Math.cos(ang) * radius, 0.2, Math.sin(ang) * radius), (age / 3) % 2 == 0 ? Pal.EMBER : Pal.WHITE, 1.6f, 1, 0.0);
                }
                for (int ringI = 0; ringI < 3; ringI++) for (int j = 0; j < 16; j++) {                       // rainbow energy rotating around the blade / sphere
                    double ang = age * 0.3 * (ringI % 2 == 0 ? 1 : -1) + j * Math.PI * 2 / 16, rr = (0.8 + ringI * 0.5 + prog * radius * 0.35);
                    fx.dust(orb.clone().add(Math.cos(ang) * rr, (ringI - 1) * 0.45, Math.sin(ang) * rr), Pal.rainbow(j / 16.0 + age * 0.03), 1.4f, 1, 0.0);
                }
                for (int k = 0; k < 3; k++) {
                    double a = age * 0.4 + k * 2.09, rr = 5 * (1 - prog) + 1;
                    fx.line(orb.clone().add(Math.cos(a) * rr, Math.sin(a * 1.2) * rr * 0.5, Math.sin(a) * rr), orb, 0.7, Pal.rainbow(a * 0.2), Pal.WHITE, 1.1f);
                }
                fx.part(Particle.REVERSE_PORTAL, orb, 6, radius * 0.3, 0.2);
                fx.debris(floor.clone().add(Fx.rnd(-radius, radius) * 0.5, 0.1, Fx.rnd(-radius, radius) * 0.5), 2, 0.3);
                return false;
            }
            if (age == charge) {                                                                           // detonation
                released[0] = true; c.requireHeld = false;
                p.setGravity(true); p.setVelocity(new Vector(0, -0.1, 0)); p.setFallDistance(0f);
                p.removePotionEffect(PotionEffectType.SLOWNESS);
                ctr[0] = p.getLocation().add(0, 1, 0);
                pl.sfx().play(ctr[0], "nebulux.supernova_explode", 4.0f, 1f);
                fx.resize(sphere, expand, (float) (radius * 2.4), (float) (radius * 2.4));
                ItemDisplay ring = c.track(fx.flat(floor.clone().add(0, 0.15, 0), "ring_prism", 1f, 0f, expand + 10));
                fx.resize(ring, expand, (float) (radius * 2.2), (float) (radius * 2.2));
                fx.explosion(ctr[0], 3.5, Pal.rainbow(0.0), Pal.WHITE);
                p.swingMainHand();
            }
            int a = age - charge;
            double r = Math.min(radius, (a + 1) * radius / expand);
            fx.sphere(ctr[0], r, 70, Pal.rainbow(a * 0.1), Pal.rainbow(a * 0.1 + 0.5), 1.8f);               // expanding prismatic shockwave
            fx.ring(floor.clone().add(0, 0.2, 0), r, 56, Pal.rainbow(a * 0.12), Pal.WHITE, 1.9f);
            fx.part(Particle.REVERSE_PORTAL, ctr[0], 30, r * 0.5, 0.6);
            fx.part(Particle.FIREWORK, ctr[0], 14, r * 0.4, 0.3);
            for (LivingEntity e : Targets.sphere(pl, p, ctr[0], r)) {
                if (c.hit(e, "nova", dmg)) {
                    double m = c.ccMult(e);
                    Vector out = mid(e).toVector().subtract(ctr[0].toVector()).setY(0);
                    out = out.lengthSquared() < 1e-4 ? Util.flatDir(p) : out.normalize();
                    pl.cc().velocity(e, out.multiply(2.0).setY(0.6), m);                                  // massive knockback (capped by cc.max-velocity)
                    if (e instanceof Player && distort > 0) e.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, (int) (distort * Math.max(m, 0.3)), 0, false, false, false));
                    fx.burst(mid(e), Pal.WHITE, Pal.rainbow(0.2), 40, 1.5);
                }
            }
            if (a >= expand) { fx.remove(sphere); return true; }
            return false;
        }, () -> {
            p.setGravity(true); p.removePotionEffect(PotionEffectType.SLOWNESS);
            if (c.cancelled && !released[0]) d.cooldowns.remove(c.id.key());
        });
    }
}

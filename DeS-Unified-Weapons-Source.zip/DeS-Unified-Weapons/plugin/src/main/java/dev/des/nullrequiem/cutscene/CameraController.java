package dev.des.nullrequiem.cutscene;

import dev.des.nullrequiem.NullRequiemPlugin;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.Random;
import java.util.UUID;

/**
 * Cinematic camera. ONE shared camera entity (invisible armor stand) is spectated by every captured player, which is what
 * keeps the cutscene perfectly synchronized. Poses are computed from a fixed rig relative to the caster, with block collision.
 * Pure Paper API (GameMode.SPECTATOR + setSpectatorTarget) - no ProtocolLib or client mod.
 */
public final class CameraController {
    private final NullRequiemPlugin plugin;
    private final Random rnd = new Random();

    public CameraController(NullRequiemPlugin plugin) { this.plugin = plugin; }

    public double eyeOffset() { return plugin.settings().d("ultimate.camera-eye-offset", 1.7775); }

    public ArmorStand spawn(UUID owner, Location at) {
        ArmorStand a = at.getWorld().spawn(at, ArmorStand.class, e -> {
            e.setInvisible(true);
            e.setGravity(false);
            e.setInvulnerable(true);
            e.setSilent(true);
            e.setBasePlate(false);
            e.setArms(false);
            e.setCollidable(false);
            e.setPersistent(false);
            e.setCanPickupItems(false);
        });
        plugin.tasks().track(owner, a);
        return a;
    }

    private static double smooth(double x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
    private static double lerp(double a, double b, double s) { return a + (b - a) * s; }

    /**
     * Camera pose (eye position + yaw/pitch) at logical cinematic tick lt (0..160). Rig is local to the caster:
     * x = caster's right, y = up, z = caster's forward.
     */
    public Location pose(Location anchor, Vector fwd, Vector right, double lt, double shake) {
        double x, y, z, lx = 0, ly = 1.4, lz = 0;
        if (lt < 30) {
            double s = smooth(lt / 30);
            x = lerp(6, -5, s); y = lerp(1.2, 1.8, s); z = lerp(8, 6, s);
        } else if (lt < 70) {
            double s = (lt - 30) / 40, ang = lerp(-0.6, 2.4, smooth(s));
            x = Math.sin(ang) * 6.5; z = Math.cos(ang) * 6.5; y = lerp(1.6, 3.2, s);
            ly = 1.4 + s * 1.2;
        } else if (lt < 100) {
            double s = smooth((lt - 70) / 30);
            x = lerp(2.8, 1.3, s); y = lerp(3.0, 3.9, s); z = lerp(3.2, 1.9, s);
            lx = 0; ly = 4.2; lz = 0;
        } else if (lt < 118) {
            double s = smooth((lt - 100) / 18);
            x = lerp(0, 0, s); y = lerp(2.4, 2.6, s); z = lerp(13, 11, s);
            ly = 2.0;
        } else {
            double s = smooth((lt - 118) / 42);
            x = 0; y = lerp(2.6, 5.5, s); z = lerp(11, 17, s);
            ly = 2.0;
        }
        Location target = anchor.clone().add(right.clone().multiply(lx)).add(fwd.clone().multiply(lz)).add(0, ly, 0);
        Location desired = anchor.clone().add(right.clone().multiply(x)).add(fwd.clone().multiply(z)).add(0, y, 0);
        if (shake > 0) desired.add((rnd.nextDouble() - 0.5) * shake * 0.25, (rnd.nextDouble() - 0.5) * shake * 0.25, (rnd.nextDouble() - 0.5) * shake * 0.25);
        // collision: pull the camera toward the look target if a block is in the way
        Vector toCam = desired.toVector().subtract(target.toVector());
        double dist = toCam.length();
        if (dist > 0.5) {
            RayTraceResult r = anchor.getWorld().rayTraceBlocks(target, toCam.clone().normalize(), dist, FluidCollisionMode.NEVER, true);
            if (r != null) desired = r.getHitPosition().toLocation(anchor.getWorld()).subtract(toCam.clone().normalize().multiply(0.35));
        }
        Vector look = target.toVector().subtract(desired.toVector());
        desired.setDirection(look);
        if (shake > 0) {
            desired.setYaw(desired.getYaw() + (float) ((rnd.nextDouble() - 0.5) * shake * 2.4));
            desired.setPitch(desired.getPitch() + (float) ((rnd.nextDouble() - 0.5) * shake * 2.4));
        }
        return desired;
    }

    /** Moves the camera entity so the viewer's eyes are exactly at pose. */
    public void apply(ArmorStand cam, Location pose) {
        if (cam == null || !cam.isValid()) return;
        Location at = pose.clone().subtract(0, eyeOffset(), 0);
        cam.teleport(at);
    }
}

# NULL//REQUIEM - ability guide  (cost in Reality Fragments / cooldown; all values in config.yml)
Resource: **Reality Fragments 0-100**. Gain: +3 per ability hit (+2 per extra target, max 10 per cast), +2 melee, +8 per combo link from the 3rd, +10 kill, +25 exposed kill. Repeat hits on the same target within 8 s pay 30 %.

**Passive - FRACTURED EXISTENCE**: every hit adds a Reality Fracture stack (max 5, 12 s). +6 % NULL//REQUIEM damage per stack. 5 stacks = REALITY EXPOSED (extra damage from flagged abilities; exposed kills restore fragments). Visuals escalate: sparks -> cracks -> orbiting particles -> distortion -> full exposed aura.

| # | Ability | Cost / CD | What it does |
|---|---|---|---|
| 1 | RIFT CLEAVER | 0 / 6s | Giant crescent (3D display entity) pierces up to 5 enemies, applies Fracture, leaves a dimensional tear |
| 2 | ZERO-POINT EXECUTION | 10 / 14s | Teleports behind the target (exposed first; collision/floor/border checked), 7-tick windup (dodgeable), vertical execution slash, +60 % vs exposed |
| 3 | BROKEN COORDINATES | 10 / 22s | 6-block zone, 8 s: enemies slowed + periodically shoved/view-jittered, ERROR gets Speed II, floating fragments + corrupted ground |
| 4 | NULL GRAVITY | 15 / 26s | Scythe driven into ground; 7-block vortex pulls for 4 s, 4 damage pulses, final shockwave |
| 5 | FALSE REALITY | 15 / 24s | 2 translucent phantom displays dash and slash from other angles; they echo ERROR's next abilities |
| 6 | WORLD//BREAK | 20 / 30s | 6 fractures spread 12 blocks, eruptions along them, final knockback eruption. No block damage |
| 7 | CORRUPTION CASCADE | 10 / 18s | Mark a target; chain jumps up to 5 enemies (8 blocks), +fragments per link |
| 8 | FRACTURE STORM | 15 / 22s | 6 orbiting shards seek different targets; leftovers converge into a final strike |
| 9 | TIME//DESYNC | 10 / 20s | Speed V burst, afterimages, -40 % damage for 3 s, one counter-slash if hit in 1.5 s |
| 10 | DEATH'S RETURN | 10 / 16s | Seal stores 35 % of damage dealt to the target (cap 30); recast to detonate with splash |
| 11 | ABSOLUTE NULLIFICATION | 60 / 45s | 10-block black void: pull, Slowness+Weakness, collapse (16 vs exposed, 5 otherwise) |
| 12 | FINAL VARIABLE | 25 / 28s | Hold to charge up to 3 s; release = giant slash, 8 -> 26 damage by charge |
| U | 404: WORLD CORRUPTED | 100 / 180s | See below |

## 404: WORLD CORRUPTED
1. **System failure (2 s)** - circle + symbols, title "[ERROR] HAS BREACHED REALITY.", countdown on action bar; everyone can leave the 12-block circle.
2. **Capture** - eligible enemy players inside the radius (+mobs, bosses only if enabled) are captured; ERROR is never captured; `nullrequiem.immune` is exempt.
   All captured players spectate the SAME camera entity -> one shared timeline.
3. **Execution** - orbit/close-up/wide shots, scythe rises, fragments detach, rift opens.
4. **Impact (tick 110/160)** - damage is applied here (captured players are briefly returned to their body to be damageable).
5. **World corrupted** - explosion, rings, flung fragments, camera shake, titles "404 / WORLD CORRUPTED / REALITY HAS FAILED TO RESPOND."
6. **Restore** - game mode, speed, flight, exact location; temporary entities removed. Safety nets: quit/death/world-change/shutdown handlers + `pending-restore.yml` crash recovery.
`ultimate.cutscene-mode: FREEZE` or `/nullrequiem camera off` gives a no-spectator fallback.

## Mastery (cosmetic only)
STAGE I UNSTABLE (0 XP) -> II CORRUPTED (1500) -> III ABSOLUTE ERROR (6000, title "The Last Error in Reality"). XP only from real hits/kills; AFK, dummies/AI-less mobs/armor stands, same-target and hourly-cap farming are blocked.

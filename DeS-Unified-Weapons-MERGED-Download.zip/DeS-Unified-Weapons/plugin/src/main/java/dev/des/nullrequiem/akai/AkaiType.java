package dev.des.nullrequiem.akai;

import java.util.Locale;

public enum AkaiType {
    CRIMSON_DRAW("crimson_draw", "CRIMSON DRAW", 0, 5),
    DRAGONSTEP("dragonstep", "DRAGONSTEP", 10, 12),
    BLOOD_MARK("blood_mark", "BLOOD MARK", 10, 14),
    IMPERIAL_CROSS("imperial_cross", "IMPERIAL CROSS", 20, 20),
    SCARLET_TEMPEST("scarlet_tempest", "SCARLET TEMPEST", 20, 18),
    DRAGONS_ROAR("dragons_roar", "DRAGON'S ROAR", 25, 24),
    KINGS_DOMAIN("kings_domain", "KING'S DOMAIN", 30, 40),
    THOUSAND_CUTS("thousand_cuts", "THOUSAND CUTS", 30, 28),
    CRIMSON_REVERSAL("crimson_reversal", "CRIMSON REVERSAL", 15, 14),
    SOVEREIGNS_JUDGEMENT("sovereigns_judgement", "SOVEREIGN'S JUDGEMENT", 40, 30),
    HEAVEN_SPLITTER("heaven_splitter", "HEAVEN SPLITTER", 40, 36),
    DRAGON_ASCENSION("dragon_ascension", "DRAGON ASCENSION", 50, 60),
    ULTIMATE("throne_of_blood", "THRONE OF BLOOD", 100, 240);

    public static final AkaiType[] ACTIVES = {
        CRIMSON_DRAW, DRAGONSTEP, BLOOD_MARK, IMPERIAL_CROSS, SCARLET_TEMPEST, DRAGONS_ROAR,
        KINGS_DOMAIN, THOUSAND_CUTS, CRIMSON_REVERSAL, SOVEREIGNS_JUDGEMENT, HEAVEN_SPLITTER, DRAGON_ASCENSION
    };

    private final String key, display; private final double cost, cd;
    AkaiType(String key, String display, double cost, double cd) { this.key = key; this.display = display; this.cost = cost; this.cd = cd; }
    public String key() { return key; }
    public String display() { return display; }
    public double defaultCost() { return cost; }
    public double defaultCooldown() { return cd; }
    public boolean isUltimate() { return this == ULTIMATE; }

    public static AkaiType parse(String s) {
        if (s == null) return null;
        String k = s.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_').replace("'", "");
        try { int n = Integer.parseInt(k); if (n >= 1 && n <= 12) return ACTIVES[n - 1]; if (n == 13) return ULTIMATE; } catch (NumberFormatException ignored) { }
        if (k.equals("ultimate") || k.equals("throne")) return ULTIMATE;
        for (AkaiType t : values()) if (t.key.equals(k) || t.name().equalsIgnoreCase(k)) return t;
        return null;
    }
}
